/**
 * AI provider selection — decoupled from any single vendor.
 *
 * Order of preference:
 *  1. Own OpenAI-compatible gateway (AI_BASE_URL + AI_API_KEY + AI_MODEL) —
 *     e.g. OpenAI, Google AI Studio (OpenAI-compat endpoint), OpenRouter,
 *     Groq, or a self-hosted proxy. This is the post-Lovable path.
 *  2. Lovable AI Gateway (LOVABLE_API_KEY) — kept as a fallback so the app
 *     keeps working if it is ever run inside Lovable Cloud again.
 *
 * chat.ts consumes this via getChatModel(request) and finalize(response),
 * so the route code has no vendor-specific logic in it.
 */
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import {
  createLovableAiGatewayProvider,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "@/lib/ai-gateway.server";

export interface ChatModelHandle {
  /** LanguageModel to pass to streamText/generateText */
  model: ReturnType<ReturnType<typeof createOpenAICompatible>>;
  /** Post-processes the outgoing Response (vendor headers etc.). */
  finalize: (response: Response) => Promise<Response> | Response;
  /** Which path was selected — useful for logging/metrics. */
  provider: "own-gateway" | "lovable";
}

export function getChatModel(request: Request): ChatModelHandle {
  const baseURL = process.env["AI_BASE_URL"];
  const apiKey = process.env["AI_API_KEY"];
  const modelId = process.env["AI_MODEL"];

  if (baseURL && apiKey && modelId) {
    const provider = createOpenAICompatible({
      name: "ayara-ai",
      baseURL,
      apiKey,
    });
    return {
      model: provider(modelId),
      finalize: (response) => response,
      provider: "own-gateway",
    };
  }

  const lovableKey = process.env["LOVABLE_API_KEY"];
  if (!lovableKey) {
    throw new Error(
      "No AI provider configured. Set AI_BASE_URL, AI_API_KEY and AI_MODEL (preferred) or LOVABLE_API_KEY.",
    );
  }

  const initialRunId = getLovableAiGatewayRunId(request);
  const gateway = createLovableAiGatewayProvider(lovableKey, initialRunId);
  return {
    model: gateway(process.env["AI_MODEL"] ?? "google/gemini-3.6-flash"),
    finalize: (response) => withLovableAiGatewayRunIdHeader(response, gateway),
    provider: "lovable",
  };
}

/**
 * Optional cheaper model for moderation judging. Falls back to the main model
 * config; returns null when no provider is configured at all (moderation then
 * runs regex-only).
 */
export function getModerationModel(request: Request): ChatModelHandle | null {
  const baseURL = process.env["AI_BASE_URL"];
  const apiKey = process.env["AI_API_KEY"];
  const modelId = process.env["MODERATION_MODEL"] ?? process.env["AI_MODEL"];
  if (baseURL && apiKey && modelId) {
    const provider = createOpenAICompatible({ name: "ayara-moderation", baseURL, apiKey });
    return { model: provider(modelId), finalize: (r) => r, provider: "own-gateway" };
  }
  try {
    return getChatModel(request);
  } catch {
    return null;
  }
}
