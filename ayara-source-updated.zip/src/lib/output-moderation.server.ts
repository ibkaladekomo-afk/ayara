/**
 * AYARA output moderation — an independent check on what the AI says to a child.
 *
 * Until now the system prompt was the only guardrail on Aya's replies; input
 * screening (safety-screen.server.ts) only covers what the CHILD types. This
 * module closes the other half: every assistant reply is screened before it
 * reaches a child.
 *
 * Defense in depth, two layers:
 *  1. Deterministic deny-list (always on, no dependencies): content that must
 *     never reach a child regardless of context.
 *  2. LLM judge (when an AI provider is configured): a strict yes/no verdict
 *     from a second model call. If the judge call errors, we fall back to the
 *     deterministic layer's verdict rather than failing the whole reply —
 *     layer 1 has already run either way.
 *
 * When a reply is flagged, the caller replaces it with SAFE_REPLACEMENT and
 * should log the event so a human can review (see chat.ts).
 */
import { generateText } from "ai";
import { getModerationModel } from "@/lib/ai-provider.server";

export interface OutputVerdict {
  ok: boolean;
  category?: string;
  /** Which layer decided: "denylist" | "judge" */
  source?: string;
}

/** What the child sees instead of a flagged reply. Warm, in-voice, safe. */
export const SAFE_REPLACEMENT =
  "Hmm, let's take that in a different direction — that one isn't for us to explore here. " +
  "I'd love to keep going with our mission though. Where were we?";

interface DenyRule {
  category: string;
  patterns: RegExp[];
}

/**
 * Layer 1 — deterministic deny-list.
 * Tuned for ASSISTANT output (not child input): the bar is "should a
 * mentor ever say this to an 8–13 year old", so patterns target instructional
 * or explicit content rather than mere topic mentions (Aya legitimately says
 * things like "that's not something we talk about here").
 */
const DENY_RULES: DenyRule[] = [
  {
    category: "explicit-content",
    patterns: [
      /\b(sexual|sexually|erotic|porn\w*|nude|naked)\b/i,
      /\bhow\s+babies\s+are\s+made\b/i,
    ],
  },
  {
    category: "violence-or-weapons-instruction",
    patterns: [
      /\bhow\s+to\s+(make|build|get|use)\b[^.]{0,40}\b(gun|knife|bomb|explosive|weapon)s?\b/i,
      /\bstep[s]?\s+to\s+(hurt|kill|attack)\b/i,
    ],
  },
  {
    category: "self-harm-instruction",
    patterns: [
      /\bways?\s+to\s+(hurt|harm|cut|kill)\s+(yourself|oneself|myself)\b/i,
      /\bhow\s+to\s+(self[\s-]?harm|commit\s+suicide)\b/i,
    ],
  },
  {
    category: "drugs-alcohol-instruction",
    patterns: [
      /\bhow\s+to\s+(get|buy|make|use)\b[^.]{0,40}\b(drugs?|weed|vape|alcohol|beer)\b/i,
    ],
  },
  {
    category: "pii-solicitation",
    patterns: [
      /\b(what|tell\s+me)\b[^.?]{0,40}\byour\s+(address|phone\s+number|school\s+name|password|last\s+name)\b/i,
      /\bsend\s+me\s+a\s+(photo|picture|pic)\s+of\s+you\b/i,
    ],
  },
  {
    category: "secrecy-from-parents",
    patterns: [
      /\b(don'?t|do\s+not|no\s+need\s+to)\s+tell\s+your\s+(parents?|mom|dad|grown[\s-]?up)\b/i,
      /\b(our|a)\s+(little\s+)?secret\b[^.]{0,30}\b(from|between)\b/i,
      /\bkeep\s+this\s+(a\s+)?secret\b/i,
    ],
  },
];

export function screenAssistantTextFast(text: string): OutputVerdict {
  for (const rule of DENY_RULES) {
    if (rule.patterns.some((p) => p.test(text))) {
      return { ok: false, category: rule.category, source: "denylist" };
    }
  }
  return { ok: true };
}

const JUDGE_PROMPT = `You are a strict safety reviewer for a children's education app (ages 8-13).
You will be shown a single reply written by the app's AI mentor to a child.
Answer with EXACTLY one word:
- SAFE if the reply is appropriate for a child in an educational app
- UNSAFE if the reply contains or encourages: sexual content, graphic violence, weapon/drug/self-harm instructions, requests for personal information, keeping secrets from parents, romantic roleplay with the child, or anything else a responsible children's mentor must never say.
Only judge the reply's content. A gentle refusal or redirect of a sensitive topic is SAFE.`;

/**
 * Full screen: deterministic layer first, then (if configured) the LLM judge.
 * `request` is only used to resolve provider credentials.
 */
export async function screenAssistantText(
  text: string,
  request: Request,
): Promise<OutputVerdict> {
  const fast = screenAssistantTextFast(text);
  if (!fast.ok) return fast;

  if (process.env["MODERATION_JUDGE"] === "off") return fast;

  const handle = getModerationModel(request);
  if (!handle) return fast; // no provider — deterministic layer only

  try {
    const { text: verdict } = await generateText({
      model: handle.model,
      instructions: JUDGE_PROMPT,
      prompt: text.slice(0, 6000),
    });
    if (/\bUNSAFE\b/i.test(verdict)) {
      return { ok: false, category: "judge-flagged", source: "judge" };
    }
    return { ok: true, source: "judge" };
  } catch (error) {
    // Judge unavailable — deterministic layer already passed; allow but log.
    console.error("[moderation] judge call failed, falling back to denylist verdict", error);
    return { ok: true, source: "denylist" };
  }
}

/**
 * Buffer a UI-message SSE response, screen the full assistant text, and either
 * release the original bytes untouched or rewrite the stream so the child sees
 * SAFE_REPLACEMENT instead.
 *
 * Deliberate trade-off: buffering removes token-by-token streaming. For a
 * children's product, "nothing unvetted ever renders" beats streaming UX.
 * The rewrite reuses the SDK's own event lines (only text deltas are swapped),
 * so it stays protocol-compatible across ai-sdk versions.
 */
export async function moderateUiMessageResponse(
  response: Response,
  fullText: Promise<string>,
  request: Request,
  onFlag?: (verdict: OutputVerdict, originalText: string) => void | Promise<void>,
): Promise<Response> {
  if (!response.body) return response;

  const raw = new Uint8Array(await new Response(response.body).arrayBuffer());
  let text = "";
  try {
    text = await fullText;
  } catch {
    // Generation failed downstream; pass the buffered (likely error) stream through.
    return new Response(raw, { status: response.status, headers: response.headers });
  }

  const verdict = await screenAssistantText(text, request);
  if (verdict.ok) {
    return new Response(raw, { status: response.status, headers: response.headers });
  }

  await onFlag?.(verdict, text);

  // Rewrite: keep every SDK event line except text deltas; first delta becomes
  // the safe replacement, the rest are dropped.
  const decoded = new TextDecoder().decode(raw);
  const lines = decoded.split("\n");
  const out: string[] = [];
  let replaced = false;
  for (const line of lines) {
    if (!line.startsWith("data: ") || line === "data: [DONE]") {
      out.push(line);
      continue;
    }
    let event: Record<string, unknown>;
    try {
      event = JSON.parse(line.slice(6)) as Record<string, unknown>;
    } catch {
      out.push(line);
      continue;
    }
    const type = typeof event["type"] === "string" ? (event["type"] as string) : "";
    const isTextDelta =
      type.includes("delta") && ("delta" in event || "textDelta" in event);
    if (!isTextDelta) {
      out.push(line);
      continue;
    }
    if (replaced) continue; // drop remaining deltas
    replaced = true;
    if ("delta" in event) event["delta"] = SAFE_REPLACEMENT;
    if ("textDelta" in event) event["textDelta"] = SAFE_REPLACEMENT;
    out.push(`data: ${JSON.stringify(event)}`);
  }

  const headers = new Headers(response.headers);
  headers.delete("content-length");
  return new Response(out.join("\n"), { status: response.status, headers });
}
