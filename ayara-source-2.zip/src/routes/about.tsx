import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Target, Telescope } from "lucide-react";
import appIcon from "@/assets/ayara-app-icon.png.asset.json";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — AYARA" },
      { name: "description", content: "Learn about AYARA's vision, mission, and why we are building a child-safe AI learning platform." },
      { property: "og:title", content: "About — AYARA" },
      { property: "og:description", content: "Learn about AYARA's vision, mission, and why we are building a child-safe AI learning platform." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="flex flex-col">
      <section className="bg-gradient-to-b from-ayara-lavender/20 to-background px-4 py-16 md:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <img
            src={appIcon.url}
            alt="AYARA app icon"
            className="mb-4 inline-block h-14 w-14"
          />

          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-5xl">About AYARA</h1>
          <p className="mt-4 text-lg text-muted-foreground">
            We believe every child should grow up confident, creative, and prepared to thrive in an AI-powered world.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-16">
        <div className="grid gap-8 md:grid-cols-2">
          <Card className="border-border/50 bg-card">
            <CardContent className="p-6">
              <Telescope className="h-8 w-8 text-ayara-lavender" />
              <h2 className="mt-4 text-2xl font-semibold text-foreground">Vision</h2>
              <p className="mt-3 text-muted-foreground">
                To ensure every child grows up confident, creative, and prepared to thrive in an AI-powered world.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card">
            <CardContent className="p-6">
              <Target className="h-8 w-8 text-ayara-coral" />
              <h2 className="mt-4 text-2xl font-semibold text-foreground">Mission</h2>
              <p className="mt-3 text-muted-foreground">
                To raise the first generation of children who confidently, safely, and creatively use artificial
                intelligence to learn, create, and solve real-world problems.
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50 bg-card md:col-span-2">
            <CardContent className="p-6">
              <Heart className="h-8 w-8 text-ayara-sunshine" />
              <h2 className="mt-4 text-2xl font-semibold text-foreground">Why we exist</h2>
              <p className="mt-3 text-muted-foreground">
                Most AI tools were designed for adults. Children are growing up in an AI-powered world, but the
                platforms they encounter were never built for their developmental needs, curiosity, or safety.
                AYARA bridges this gap with a protected environment where children learn to think critically,
                create boldly, and use AI responsibly — while parents stay informed and in control.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-semibold text-foreground">Our approach</h2>
          <ul className="mt-6 space-y-4 text-muted-foreground">
            <li className="flex items-start gap-3">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-primary" />
              <span>
                <strong className="text-foreground">Child-first design:</strong> Every lesson, character, and
                conversation is built around how children actually learn and play.
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-primary" />
              <span>
                <strong className="text-foreground">Safety by default:</strong> AI responses are filtered,
                age-adapted, and designed to encourage help-seeking when topics are sensitive.
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-primary" />
              <span>
                <strong className="text-foreground">Guided creation:</strong> We teach children to use AI as a
                collaborator, not a replacement for thinking.
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="mt-1.5 h-2 w-2 rounded-full bg-primary" />
              <span>
                <strong className="text-foreground">Parent partnership:</strong> Parents set preferences, review
                progress, and receive weekly summaries without removing the child's independence.
              </span>
            </li>
          </ul>
        </div>
      </section>
    </div>
  );
}
