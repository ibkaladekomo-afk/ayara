import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Lock, Eye, UserCheck, MessageCircleWarning } from "lucide-react";

export const Route = createFileRoute("/safety")({
  head: () => ({
    meta: [
      { title: "Safety — AYARA" },
      { name: "description", content: "AYARA's child-first safety and moderation architecture keeps children safe while they learn with AI." },
      { property: "og:title", content: "Safety — AYARA" },
      { property: "og:description", content: "AYARA's child-first safety and moderation architecture keeps children safe while they learn with AI." },
    ],
  }),
  component: SafetyPage,
});

function SafetyPage() {
  return (
    <div className="flex flex-col">
      <section className="bg-gradient-to-b from-ayara-sage/20 to-background px-4 py-16 md:py-24">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
            <Shield className="h-6 w-6" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-5xl">Safety first</h1>
          <p className="mt-4 text-lg text-muted-foreground">
            AYARA is designed from the ground up to protect children while nurturing curiosity.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-16">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[
            {
              icon: Lock,
              title: "Filtered conversations",
              desc: "Every AI response is shaped by a child-safety system prompt and blocked from answering unsafe, inappropriate, or adult topics.",
            },
            {
              icon: UserCheck,
              title: "Age adaptation",
              desc: "Content, vocabulary, and interaction style adjust to each child's registered age and grade level.",
            },
            {
              icon: Eye,
              title: "Parent visibility",
              desc: "Parents can review conversation history, learning progress, and receive weekly activity summaries.",
            },
            {
              icon: MessageCircleWarning,
              title: "Help-seeking prompts",
              desc: "When a child raises sensitive topics, AYARA encourages them to talk to a trusted adult rather than providing unsupervised advice.",
            },
            {
              icon: Shield,
              title: "No ads to children",
              desc: "AYARA does not rely on third-party advertising or monetize children's attention.",
            },
            {
              icon: Lock,
              title: "Data minimization",
              desc: "We collect only what is needed to personalize learning and keep profiles secure.",
            },
          ].map((item) => (
            <Card key={item.title} className="border-border/50 bg-card">
              <CardContent className="p-6">
                <item.icon className="h-8 w-8 text-ayara-sage" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">{item.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 rounded-2xl border border-border/50 bg-muted/30 p-8">
          <h2 className="text-2xl font-semibold text-foreground">Safety is a process, not a feature</h2>
          <p className="mt-4 text-muted-foreground">
            We combine automated filtering, age-aware prompting, human review workflows, and parent controls to
            continuously improve AYARA's safety posture. Our goal is to earn parent trust every single day.
          </p>
        </div>
      </section>
    </div>
  );
}
