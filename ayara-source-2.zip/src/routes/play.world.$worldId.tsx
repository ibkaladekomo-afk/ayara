import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, ArrowLeft, Sparkles, Volume2, Trophy, FolderOpen, Gem, Lock, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getWorld } from "@/lib/worlds";
import { useChildSession } from "@/lib/child-session-context";
import { getAgeTier } from "@/lib/age-tiers";
import { useReadAloud } from "@/lib/use-voice";
import { useReducedMotion } from "@/lib/use-reduced-motion";
import { getBadge } from "@/lib/dashboard-content";
import { getMyWorld, enterWorld, exitWorld, recordDiscovery } from "@/lib/child-worlds.functions";
import { listMyCreations } from "@/lib/child-creations.functions";
import { creationKindMeta, crossoverInvite, type CreationRecord } from "@/lib/creations";

export const Route = createFileRoute("/play/world/$worldId")({
  head: () => ({
    meta: [
      { title: "Learning World — AYARA" },
      { name: "description", content: "Step into an AYARA Learning World: meet your mentor, follow the learning path and build your master project." },
      { property: "og:title", content: "Learning World — AYARA" },
      { property: "og:description", content: "Meet your mentor, follow the learning path and build your master project." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: WorldHome,
});

function WorldHome() {
  const { worldId } = Route.useParams();
  const navigate = useNavigate();
  const world = getWorld(worldId);
  const { child, isLoading } = useChildSession();
  const queryClient = useQueryClient();
  const [reduced] = useReducedMotion();
  const { speak, stop, speaking } = useReadAloud();

  const tier = child ? getAgeTier({ age: child.age, grade: child.grade }) : null;
  const isOlder = tier?.mascot === "minimal";

  const fetchWorld = useServerFn(getMyWorld);
  const enterFn = useServerFn(enterWorld);
  const exitFn = useServerFn(exitWorld);
  const discoverFn = useServerFn(recordDiscovery);

  const enteredRef = useRef(false);
  const openedAt = useRef(Date.now());
  const [welcomeDone, setWelcomeDone] = useState(reduced);
  const [reveal, setReveal] = useState<{ name: string; text: string; crystals: number } | null>(null);

  const fetchCreations = useServerFn(listMyCreations);
  const universe = useQuery({
    queryKey: ["child-universe", child?.id],
    enabled: Boolean(child && world),
    queryFn: () => fetchCreations({}),
  });
  const visitors = ((universe.data?.creations ?? []) as CreationRecord[]).filter(
    (c) => c.origin_world !== worldId && !c.worlds.includes(worldId),
  );

  const data = useQuery({
    queryKey: ["child-world", child?.id, worldId],
    enabled: Boolean(child && world),
    queryFn: () => fetchWorld({ data: { world_id: worldId } }),
  });

  useEffect(() => {
    if (!child || !world || enteredRef.current) return;
    enteredRef.current = true;
    void enterFn({ data: { world_id: world.id } }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [child?.id, worldId]);

  useEffect(() => {
    if (welcomeDone) return;
    const t = window.setTimeout(() => setWelcomeDone(true), 2600);
    return () => window.clearTimeout(t);
  }, [welcomeDone]);

  useEffect(() => {
    if (!isLoading && !child) navigate({ to: "/child-login", replace: true });
  }, [child, isLoading, navigate]);

  const leave = () => {
    stop();
    const seconds = Math.round((Date.now() - openedAt.current) / 1000);
    if (world) void exitFn({ data: { world_id: world.id, seconds } }).catch(() => {});
    void navigate({ to: "/play" });
  };

  const stages = world?.stages ?? [];
  const completed = data.data?.completedStages ?? [];
  const currentStage = useMemo(() => {
    if (!world) return null;
    return world.stages.find((s) => !completed.includes(s.id)) ?? world.stages[world.stages.length - 1]!;
  }, [world, completed]);

  if (!world) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <h1 className="font-display text-2xl text-foreground">That world isn't open yet</h1>
        <p className="mt-2 text-muted-foreground">It's still being built. Try one of the open worlds.</p>
        <Button asChild className="mt-6">
          <Link to="/play">Back to the Innovation Hub</Link>
        </Button>
      </div>
    );
  }

  if (isLoading || !child) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!welcomeDone) {
    return (
      <button
        type="button"
        onClick={() => setWelcomeDone(true)}
        className={`flex min-h-[100dvh] w-full flex-col items-center justify-center bg-gradient-to-br ${world.tile} px-6 text-center text-background`}
      >
        <span className="animate-scale-in text-7xl" aria-hidden>
          {world.emoji}
        </span>
        <h1 className="mt-6 animate-fade-in font-display text-4xl leading-tight">{world.name}</h1>
        <p className="mt-3 max-w-sm animate-fade-in text-background/90">{world.theme}</p>
        <p className="mt-6 max-w-sm animate-fade-in font-display text-lg">
          {world.character}: “{world.welcome}”
        </p>
        <span className="mt-8 text-sm text-background/80">Tap to continue</span>
      </button>
    );
  }

  const d = data.data;

  return (
    <div className="mx-auto max-w-3xl px-4 py-4 pb-16">
      {/* World header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" aria-label="Exit world" onClick={leave}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <span className={`flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br ${world.tile} text-2xl`}>
          {world.emoji}
        </span>
        <div className="min-w-0">
          <h1 className="truncate font-display text-lg leading-tight text-foreground">{world.name}</h1>
          <p className="truncate text-xs text-muted-foreground">
            {world.character} · {world.mentorTitle}
          </p>
        </div>
        {!isOlder && (
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto"
            aria-label={speaking ? "Stop reading" : "Read this to me"}
            onClick={() => (speaking ? stop() : speak(`${world.welcome} ${currentStage?.blurb ?? ""}`))}
          >
            <Volume2 className={`h-5 w-5 ${speaking ? "text-primary" : ""}`} />
          </Button>
        )}
      </div>

      {/* Mentor message + progress */}
      <section className={`mt-4 rounded-3xl bg-gradient-to-br ${world.tile} p-5 text-background shadow-lg`}>
        <div className="flex items-start gap-4">
          <ProgressRing percent={d?.completion ?? 0} />
          <div className="min-w-0">
            <p className="font-display text-lg leading-snug">“{world.welcome}”</p>
            <p className="mt-1 text-sm text-background/85">— {world.character}</p>
            <p className="mt-3 text-sm text-background/90">
              {d?.completion ?? 0}% of this world explored · {d?.crystals ?? 0} Curiosity Crystals
            </p>
          </div>
        </div>

        {currentStage && (
          <div className="mt-5 rounded-2xl bg-background/15 p-4">
            <p className="text-xs font-semibold uppercase tracking-wide text-background/80">
              {isOlder ? "Next up" : "Do this next"}
            </p>
            <p className="mt-1 font-display text-xl">{currentStage.label}</p>
            <p className="mt-1 text-sm text-background/90">{currentStage.blurb}</p>
            <Button asChild size="lg" variant="secondary" className="mt-4 h-12 w-full rounded-full text-base">
              <Link
                to="/play/$worldId"
                params={{ worldId: world.id }}
                search={{ mission: undefined, start: currentStage.prompt, stage: currentStage.id, creation: undefined }}
              >
                {isOlder ? "Open the workspace" : "Let's go!"}
              </Link>
            </Button>
          </div>
        )}
      </section>

      {/* Ayara Universe: bring a creation from another world */}
      {visitors.length > 0 && (
        <section className="mt-5 rounded-3xl border border-secondary/40 bg-secondary/10 p-4">
          <h2 className="font-display text-sm uppercase tracking-wide text-muted-foreground">
            Bring a creation
          </h2>
          <p className="mt-1 text-sm text-foreground">
            {crossoverInvite(
              world.id,
              visitors[0]!.kind,
              visitors[0]!.name,
              isOlder ? "forge" : "spark",
            )}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {visitors.slice(0, 4).map((c) => (
              <Button key={c.id} asChild size="sm" variant="outline" className="rounded-full bg-background">
                <Link
                  to="/play/$worldId"
                  params={{ worldId: world.id }}
                  search={{
                    mission: undefined,
                    start: currentStage?.prompt,
                    stage: currentStage?.id,
                    creation: c.id,
                  }}
                >
                  {c.emoji || creationKindMeta(c.kind).emoji} {c.name}
                </Link>
              </Button>
            ))}
          </div>
          <Button asChild variant="ghost" size="sm" className="mt-2 rounded-full">
            <Link to="/play/universe">See my universe</Link>
          </Button>
        </section>
      )}

      {data.isLoading && (
        <div className="flex justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      )}

      {/* Learning path */}
      <section className="mt-6">
        <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-muted-foreground">Learning path</h2>
        <ol className="space-y-2">
          {stages.map((stage, i) => {
            const done = completed.includes(stage.id);
            const isCurrent = currentStage?.id === stage.id;
            const locked = !done && !isCurrent && i > (d?.stageIndex ?? 0);
            return (
              <li key={stage.id}>
                <div
                  className={`flex items-center gap-3 rounded-2xl border p-3 ${
                    isCurrent ? "border-primary bg-primary/5" : "border-border bg-card"
                  } ${locked ? "opacity-60" : ""}`}
                >
                  <span
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-semibold ${
                      done ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {done ? <Check className="h-4 w-4" /> : locked ? <Lock className="h-3.5 w-3.5" /> : i + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-display text-base leading-tight text-foreground">{stage.label}</p>
                    <p className="truncate text-xs text-muted-foreground">{stage.blurb}</p>
                  </div>
                  {!locked && !done && (
                    <Button asChild size="sm" variant={isCurrent ? "default" : "ghost"} className="rounded-full">
                      <Link
                        to="/play/$worldId"
                        params={{ worldId: world.id }}
                        search={{ mission: undefined, start: stage.prompt, stage: stage.id, creation: undefined }}
                      >
                        Start
                      </Link>
                    </Button>
                  )}
                </div>
              </li>
            );
          })}
        </ol>
      </section>

      {/* Master project */}
      <section className="mt-6 rounded-3xl border border-border bg-card p-4">
        <h2 className="flex items-center gap-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
          <Sparkles className="h-4 w-4" /> Master Project
        </h2>
        <p className="mt-2 font-display text-xl text-foreground">{world.masterProject.title}</p>
        <p className="mt-1 text-sm text-muted-foreground">{world.masterProject.description}</p>
        <p className="mt-2 text-xs text-muted-foreground">
          +{world.masterProject.xp} XP · certificate: {world.masterProject.certificate}
        </p>
        {d?.masterProjectStatus === "completed" ? (
          <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-secondary/25 px-4 py-1.5 text-sm font-semibold text-foreground">
            🏅 {world.masterProject.certificate} earned
          </p>
        ) : (
          <Button asChild className="mt-4 rounded-full">
            <Link
              to="/play/$worldId"
              params={{ worldId: world.id }}
              search={{ mission: undefined, start: world.masterProject.prompt, stage: "master" }}
            >
              {d?.masterProjectStatus === "in_progress" ? "Keep building" : "Start the Master Project"}
            </Link>
          </Button>
        )}
      </section>

      {/* Hidden discoveries */}
      <section className="mt-6">
        <h2 className="mb-2 flex items-center gap-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
          <Gem className="h-4 w-4" /> Discoveries
        </h2>
        <div className="grid gap-2 sm:grid-cols-2">
          {world.discoveries.map((disc) => {
            const found = d?.discoveries.includes(disc.id) ?? false;
            return (
              <button
                key={disc.id}
                type="button"
                disabled={found}
                onClick={() => {
                  void discoverFn({ data: { world_id: world.id, discovery_id: disc.id } })
                    .then((res) => {
                      setReveal({ name: disc.name, text: res.reveal, crystals: res.crystals });
                      if (!isOlder) void speak(res.reveal);
                      void queryClient.invalidateQueries({ queryKey: ["child-world", child.id, worldId] });
                    })
                    .catch(() => {});
                }}
                className={`rounded-2xl border p-3 text-left transition-colors ${
                  found ? "border-secondary bg-secondary/15" : "border-dashed border-border hover:border-primary/50"
                }`}
              >
                <span className="text-xl" aria-hidden>
                  {found ? disc.emoji : "❔"}
                </span>
                <p className="mt-1 font-display text-sm text-foreground">{found ? disc.name : "Something hidden"}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">{found ? disc.reveal : disc.hint}</p>
              </button>
            );
          })}
        </div>
        {reveal && (
          <div className="mt-3 rounded-2xl border border-secondary/40 bg-secondary/10 p-4 text-center">
            <p className="font-display text-lg text-foreground">You found {reveal.name}!</p>
            <p className="mt-1 text-sm text-foreground">{reveal.text}</p>
            {reveal.crystals > 0 && (
              <p className="mt-2 text-sm font-semibold text-foreground">+{reveal.crystals} Curiosity Crystals</p>
            )}
          </div>
        )}
      </section>

      {/* Achievements + work made here */}
      <section className="mt-6 grid gap-3 sm:grid-cols-2">
        <div className="rounded-3xl border border-border bg-card p-4">
          <h2 className="flex items-center gap-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
            <Trophy className="h-4 w-4" /> Achievements
          </h2>
          {world.masterProject.badge && (
            <p className="mt-3 inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1.5 text-sm font-semibold text-foreground">
              <span aria-hidden>
                {d?.badges.includes(world.masterProject.badge) ? getBadge(world.masterProject.badge).emoji : "🔒"}
              </span>
              {getBadge(world.masterProject.badge).name}
            </p>
          )}
          <p className="mt-2 text-xs text-muted-foreground">
            {d?.discoveries.length ?? 0} of {world.discoveries.length} discoveries found
          </p>
        </div>

        <div className="rounded-3xl border border-border bg-card p-4">
          <h2 className="flex items-center gap-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
            <FolderOpen className="h-4 w-4" /> Made here
          </h2>
          {(d?.portfolio.length ?? 0) === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">Nothing yet — your first creation lands here.</p>
          ) : (
            <ul className="mt-2 space-y-1">
              {d?.portfolio.map((item: { id: string; title: string }) => (
                <li key={item.id} className="truncate text-sm text-foreground">
                  · {item.title}
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <div className="mt-8 text-center">
        <Button variant="ghost" size="sm" className="rounded-full text-muted-foreground" onClick={leave}>
          Exit {world.name}
        </Button>
      </div>
    </div>
  );
}

function ProgressRing({ percent }: { percent: number }) {
  const size = 68;
  const stroke = 7;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} className="shrink-0" role="img" aria-label={`${percent}% complete`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-background/30" />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        strokeWidth={stroke}
        strokeLinecap="round"
        className="stroke-background transition-all"
        strokeDasharray={c}
        strokeDashoffset={c - (c * percent) / 100}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <text x="50%" y="54%" textAnchor="middle" className="fill-background font-display text-sm">
        {percent}%
      </text>
    </svg>
  );
}
