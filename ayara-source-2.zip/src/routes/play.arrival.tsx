import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Aya } from "@/components/aya";
import { useChildSession } from "@/lib/child-session-context";
import { getAgeTier } from "@/lib/age-tiers";
import { completeArrival } from "@/lib/arrival";
import { StepShell } from "@/components/onboarding/journey-shell";
import {
  AvatarStep,
  CelebrationStep,
  InterestsStep,
  MentorsStep,
  QuestStep,
  WorldMapStep,
} from "@/components/onboarding/steps";
import { ConversationStep, CreationStep } from "@/components/onboarding/conversation-step";
import { useReducedMotion } from "@/lib/use-reduced-motion";
import { normalizeAvatarConfig, type AvatarConfig } from "@/lib/avatar-builder";
import {
  EVENTS,
  FIRST_BADGE,
  MENTORS,
  ONBOARDING_XP,
  QUEST_BEATS,
  STARTING_WORLD,
  STEP_TITLES,
  isJourneyStep,
  moreLine,
  nextStep,
  stepProgress,
  welcomeLine,
  type JourneyStep,
} from "@/lib/onboarding-journey";
import {
  awardMyBadge,
  completeMyOnboarding,
  getMyJourney,
  logMyEvent,
  saveMyAvatar,
  saveMyInterests,
  saveMyPortfolioItem,
  saveMyStep,
  unlockMyWorld,
} from "@/lib/child-onboarding.functions";

export const Route = createFileRoute("/play/arrival")({
  head: () => ({
    meta: [
      { title: "Welcome to AYARA" },
      {
        name: "description",
        content: "Step into AYARA — your character, your interests, your crew and your very first creation.",
      },
      { property: "og:title", content: "Welcome to AYARA" },
      {
        property: "og:description",
        content: "Step into AYARA — your character, your interests, your crew and your very first creation.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ArrivalPage,
});

const LOCAL_KEY = (id: string) => `ayara.journey.${id}`;

function ArrivalPage() {
  const { child, isLoading, refresh } = useChildSession();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!child) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center px-4 text-center">
        <div>
          <h1 className="font-display text-2xl text-foreground">Child login required</h1>
          <Button className="mt-6 min-h-11 rounded-full" onClick={() => void navigate({ to: "/child-login" })}>
            Go to child login
          </Button>
        </div>
      </div>
    );
  }

  return <Journey key={child.id} child={child} onRefreshChild={refresh} />;
}

function Journey({
  child,
  onRefreshChild,
}: {
  child: {
    id: string;
    name: string;
    age: number;
    grade: string | null;
    language: string;
    interests: string[] | null;
  };
  onRefreshChild: () => Promise<void>;
}) {
  const navigate = useNavigate();
  const tier = useMemo(() => getAgeTier({ age: child.age, grade: child.grade }), [child.age, child.grade]);
  const isSpark = tier.id === "spark";
  const [reducedMotion, setReducedMotion] = useReducedMotion();

  const [step, setStep] = useState<JourneyStep>("doorway");
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [offline, setOffline] = useState(false);
  const [avatar, setAvatar] = useState<AvatarConfig | null>(null);
  const [questBeat, setQuestBeat] = useState(0);
  const [questNarration, setQuestNarration] = useState<string>(QUEST_BEATS[0]!.sparkLine);
  const [welcomeMore, setWelcomeMore] = useState(false);

  const loadJourney = useServerFn(getMyJourney);
  const persistStep = useServerFn(saveMyStep);
  const persistAvatar = useServerFn(saveMyAvatar);
  const persistInterests = useServerFn(saveMyInterests);
  const persistItem = useServerFn(saveMyPortfolioItem);
  const persistBadge = useServerFn(awardMyBadge);
  const persistUnlock = useServerFn(unlockMyWorld);
  const persistEvent = useServerFn(logMyEvent);
  const finishOnboarding = useServerFn(completeMyOnboarding);

  /* Resume where the child left off — server first, local cache as fallback. */
  useEffect(() => {
    let cancelled = false;
    const local = (() => {
      try {
        return window.localStorage.getItem(LOCAL_KEY(child.id));
      } catch {
        return null;
      }
    })();

    loadJourney()
      .then((journey) => {
        if (cancelled) return;
        const saved = journey.onboarding?.current_step;
        if (saved === "done" || journey.onboarding?.completed_at) {
          // Server says the arrival is finished — mirror it locally so a new
          // device doesn't bounce between the hub and the intro.
          completeArrival(child.id);
          void navigate({ to: "/play", replace: true });
          return;
        }
        const resume = isJourneyStep(saved) ? saved : isJourneyStep(local) ? local : "doorway";
        setStep(resume);
        // Resume mid-quest instead of replaying fragments the child already found.
        const savedBeat = Number((journey.onboarding?.quest_state as { beat?: unknown } | null)?.beat ?? 0);
        if (resume === "quest" && Number.isFinite(savedBeat) && savedBeat > 0) {
          const beat = Math.min(savedBeat, QUEST_BEATS.length - 1);
          setQuestBeat(beat);
          setQuestNarration(QUEST_BEATS[beat]!.sparkLine);
        }
        setAvatar(normalizeAvatarConfig(journey.avatar_config));
        setReady(true);
      })
      .catch(() => {
        if (cancelled) return;
        if (isJourneyStep(local)) setStep(local);
        setReady(true);
      });

    return () => {
      cancelled = true;
    };
  }, [child.id, loadJourney, navigate]);

  useEffect(() => {
    const update = () => setOffline(!navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);

  const track = useCallback(
    (event: string, metadata: Record<string, unknown> = {}) => {
      void persistEvent({ data: { event, metadata } }).catch(() => {});
    },
    [persistEvent],
  );

  const goTo = useCallback(
    (next: JourneyStep) => {
      setStep(next);
      try {
        window.localStorage.setItem(LOCAL_KEY(child.id), next);
      } catch {
        /* storage blocked */
      }
      void persistStep({ data: { step: next } }).catch(() => {});
    },
    [child.id, persistStep],
  );

  const advance = useCallback(() => goTo(nextStep(step)), [goTo, step]);

  const titles = STEP_TITLES[step];
  const title = isSpark ? titles.spark : titles.forge;

  if (!ready) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  /* ------------------------------ Doorway ------------------------------- */
  if (step === "doorway") {
    return (
      <Doorway
        tier={tier.id}
        name={child.name}
        reducedMotion={reducedMotion}
        onEnter={() => {
          track(EVENTS.started);
          advance();
        }}
      />
    );
  }

  const shell = (
    narration: string,
    children: React.ReactNode,
    aside?: React.ReactNode,
    autoSpeak = true,
  ) => (
    <>
      {offline && <OfflineBanner />}
      <StepShell
        tier={tier.id}
        title={title}
        narration={narration}
        progress={stepProgress(step)}
        reducedMotion={reducedMotion}
        onToggleMotion={setReducedMotion}
        aside={aside}
        autoSpeak={autoSpeak}
      >
        {children}
      </StepShell>
    </>
  );

  /* ------------------------------ Welcome ------------------------------- */
  if (step === "welcome") {
    const line = welcomeMore ? moreLine(tier.id) : welcomeLine(tier.id, child.name);
    return shell(
      line,
      <div className="flex flex-col items-center gap-3">
        <Button className="min-h-14 rounded-full px-10 text-lg" onClick={advance}>
          {isSpark ? "I'm ready!" : "Let's set it up"}
        </Button>
        {!welcomeMore && (
          <Button variant="ghost" className="min-h-11 rounded-full" onClick={() => setWelcomeMore(true)}>
            {isSpark ? "Tell me more" : "What is Ayara?"}
          </Button>
        )}
      </div>,
      isSpark ? <Aya size="lg" mood="wave" /> : undefined,
    );
  }

  /* ------------------------------- Avatar -------------------------------- */
  if (step === "avatar") {
    return shell(
      isSpark
        ? "Let's make a character that looks like you — or like anyone you imagine!"
        : "Set up how you show up in Ayara. You can change this any time.",
      <AvatarStep
        initial={avatar}
        saving={saving}
        onDone={async (config) => {
          setSaving(true);
          setAvatar(config);
          try {
            await persistAvatar({ data: { avatar_config: config } });
            await onRefreshChild();
          } catch {
            /* keep going — the local choice still applies */
          }
          setSaving(false);
          advance();
        }}
      />,
    );
  }

  /* ------------------------------ Interests ------------------------------ */
  if (step === "interests") {
    return shell(
      isSpark ? "What do you love? Pick everything that makes you excited." : "Pick the areas you want to work in.",
      <InterestsStep
        initial={child.interests ?? []}
        saving={saving}
        onDone={async (interests) => {
          setSaving(true);
          try {
            await persistInterests({ data: { interests } });
            await onRefreshChild();
          } catch {
            /* non-blocking */
          }
          setSaving(false);
          advance();
        }}
      />,
    );
  }

  /* ------------------------------- Mentors ------------------------------- */
  if (step === "mentors") {
    return shell(
      isSpark ? "These are the friends who'll learn with you." : "This is the crew you'll be working with.",
      <MentorsStep
        tier={tier.id}
        onDone={() => {
          track(EVENTS.mentors, { count: MENTORS.length });
          advance();
        }}
      />,
    );
  }

  /* -------------------------------- Quest -------------------------------- */
  if (step === "quest") {
    return shell(
      questNarration,
      <QuestStep
        tier={tier.id}
        beatIndex={questBeat}
        onNarration={setQuestNarration}
        onBeatDone={(state) => {
          const done = questBeat + 1 >= QUEST_BEATS.length;
          if (done) {
            // Skip the "quest" write so it can't race past the next step's save.
            track(EVENTS.quest);
            advance();
          } else {
            void persistStep({
              data: { step: "quest", quest_state: { beat: questBeat + 1, ...state } },
            }).catch(() => {});
            setQuestBeat((b) => b + 1);
          }
        }}
      />,
    );
  }

  /* ---------------------------- Conversation ----------------------------- */
  if (step === "conversation") {
    const conversationNarration = isSpark
      ? "Now it's just you and me. Say it out loud or type it."
      : "Your turn. Answer however you like.";
    return shell(
      conversationNarration,
      <ConversationStep
        child={child}
        tier={tier}
        speakIntro={conversationNarration}
        onDone={() => {
          track(EVENTS.conversation);
          advance();
        }}
      />,
      undefined,
      false,
    );
  }

  /* ------------------------------ Creation ------------------------------- */
  if (step === "creation") {
    return shell(
      isSpark ? "Let's make your very first thing. Pick one!" : "First build. Pick one and ship it.",
      <CreationStep
        child={child}
        tier={tier}
        saving={saving}
        onSave={async ({ activity, text, drawing }) => {
          setSaving(true);
          try {
            await persistItem({
              data: {
                kind: activity.drawing ? "drawing" : "writing",
                title: activity.title,
                content: { prompt: activity.prompt, text, image: drawing },
                world_id: null,
              },
            });
          } catch {
            /* non-blocking */
          }
          setSaving(false);
          advance();
        }}
      />,
    );
  }

  /* ---------------------------- Celebration ------------------------------ */
  if (step === "celebration") {
    return shell(
      isSpark
        ? `Look at that, ${child.name}! You made your first creation and earned your first badge.`
        : `Logged, ${child.name}. First build saved to your portfolio.`,
      <CelebrationStep
        name={child.name}
        avatar={avatar}
        onDone={async () => {
          try {
            await persistBadge({ data: { badge_id: FIRST_BADGE.id, xp: ONBOARDING_XP } });
          } catch {
            /* non-blocking */
          }
          advance();
        }}
      />,
    );
  }

  /* ------------------------------ World map ------------------------------ */
  if (step === "worldmap") {
    return shell(
      isSpark
        ? "This is your map. One world is open now — more unlock as you learn."
        : "Your world map. One is live; the rest unlock as you progress.",
      <WorldMapStep
        onDone={async () => {
          try {
            await persistUnlock({ data: { world_id: STARTING_WORLD } });
            await finishOnboarding();
          } catch {
            /* non-blocking */
          }
          completeArrival(child.id);
          try {
            window.localStorage.removeItem(LOCAL_KEY(child.id));
          } catch {
            /* storage blocked */
          }
          void navigate({ to: "/play" });
        }}
      />,
    );
  }

  return null;
}

/* ------------------------------- Doorway --------------------------------- */

function Doorway({
  tier,
  name,
  reducedMotion,
  onEnter,
}: {
  tier: "spark" | "forge";
  name: string;
  reducedMotion: boolean;
  onEnter: () => void;
}) {
  const [opening, setOpening] = useState(false);

  const enter = () => {
    if (reducedMotion) return onEnter();
    setOpening(true);
    window.setTimeout(onEnter, 900);
  };

  if (tier === "forge") {
    return (
      <div className="flex min-h-[100dvh] flex-col items-center justify-center bg-foreground px-6 text-center">
        <p className="font-mono text-sm uppercase tracking-[0.3em] text-background/60">Ayara Studio</p>
        <h1 className="mt-4 font-display text-4xl text-background md:text-5xl">Welcome, {name}</h1>
        <p className="mt-3 max-w-md text-background/70">Your workspace is ready. Setup takes about five minutes.</p>
        <Button
          className="mt-10 min-h-14 rounded-full px-10 text-lg"
          variant="secondary"
          onClick={enter}
          disabled={opening}
        >
          {opening ? "Booting…" : "Enter studio"}
        </Button>
      </div>
    );
  }

  return (
    <div className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-primary/20 via-background to-secondary/20 px-6 text-center">
      <button
        type="button"
        onClick={enter}
        aria-label="Open the door to Ayara"
        className="group relative flex h-64 w-44 items-center justify-center rounded-t-full border-4 border-primary/60 bg-card shadow-lg transition-transform hover:scale-105"
      >
        <span aria-hidden className="text-6xl">
          ✨
        </span>
        <span
          className={`absolute inset-0 rounded-t-full bg-primary/90 ${
            opening && !reducedMotion ? "motion-safe:animate-fade-out" : "opacity-0"
          }`}
        />
      </button>
      <h1 className="mt-8 font-display text-3xl text-foreground md:text-4xl">Hi {name}, your door is here</h1>
      <p className="mt-2 text-lg text-muted-foreground">Tap the door when you're ready.</p>
    </div>
  );
}

function OfflineBanner() {
  return (
    <div
      role="status"
      className="flex items-center justify-center gap-2 bg-muted px-4 py-2 text-center text-sm text-foreground"
    >
      <WifiOff className="h-4 w-4" />
      We lost the internet for a second — your spot is saved. We'll pick right back up.
    </div>
  );
}
