import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Aya } from "@/components/aya";
import { useI18n } from "@/lib/i18n";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/auth")({
  validateSearch: (search: Record<string, unknown>) => ({
    mode: search["mode"] === "signup" ? ("signup" as const) : ("signin" as const),
  }),
  head: () => ({
    meta: [
      { title: "Parent Sign In — Ayara" },
      {
        name: "description",
        content: "Create your Ayara family account or sign in to manage your children's safe AI learning.",
      },
      { property: "og:title", content: "Parent Sign In — Ayara" },
      { property: "og:description", content: "Create your Ayara family account or sign in." },
    ],
  }),
  component: AuthPage,
});

const NAME_RE = /^[\p{L}\s'-]{2,40}$/u;

function passwordChecks(value: string) {
  return {
    length: value.length >= 10,
    upper: /[A-Z]/.test(value),
    lower: /[a-z]/.test(value),
    number: /\d/.test(value),
    special: /[^A-Za-z0-9]/.test(value),
  };
}

function StrengthMeter({ password }: { password: string }) {
  const checks = passwordChecks(password);
  const score = Object.values(checks).filter(Boolean).length;
  const labels = ["Too short", "Weak", "Getting there", "Good", "Strong", "Excellent"];
  const colors = ["bg-border", "bg-destructive", "bg-[--color-warning,theme(colors.amber.500)]", "bg-amber-400", "bg-emerald-500", "bg-emerald-600"];

  return (
    <div className="mt-2" aria-live="polite">
      <div className="flex gap-1">
        {[0, 1, 2, 3, 4].map((i) => (
          <span key={i} className={`h-1.5 flex-1 rounded-full ${i < score ? colors[score] : "bg-border"}`} />
        ))}
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        {labels[score]} — needs 10+ characters with an uppercase letter, a lowercase letter, a number and a symbol.
      </p>
    </div>
  );
}

const COUNTRIES = ["United States", "Canada", "Mexico", "Spain", "United Kingdom", "Colombia", "Argentina", "Other"];

function AuthPage() {
  const { mode } = Route.useSearch();
  const navigate = useNavigate();
  const { t, lang, setLang } = useI18n();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [country, setCountry] = useState("United States");
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptPrivacy, setAcceptPrivacy] = useState(false);
  const [marketing, setMarketing] = useState(false);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const isSignup = mode === "signup";

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) void navigate({ to: "/onboarding", replace: true });
    });
  }, [navigate]);

  const checks = useMemo(() => passwordChecks(password), [password]);

  function validate() {
    const next: Record<string, string> = {};
    if (isSignup) {
      if (!NAME_RE.test(firstName.trim())) next["firstName"] = "Please use 2–40 letters.";
      if (!NAME_RE.test(lastName.trim())) next["lastName"] = "Please use 2–40 letters.";
      if (!Object.values(checks).every(Boolean))
        next["password"] = "Please use 10+ characters with upper and lower case, a number and a symbol.";
      if (password !== confirm) next["confirm"] = "These passwords don't match yet.";
      if (!acceptTerms) next["terms"] = "Please accept the Terms to continue.";
      if (!acceptPrivacy) next["privacy"] = "Please accept the Privacy Policy to continue.";
    } else if (!password) {
      next["password"] = "Please enter your password.";
    }
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) next["email"] = "Please enter a valid email address.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError(null);
    if (!validate()) return;
    setPending(true);

    try {
      if (isSignup) {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/onboarding`,
            data: {
              first_name: firstName.trim(),
              last_name: lastName.trim(),
              full_name: `${firstName.trim()} ${lastName.trim()}`,
              country,
              language: lang,
              marketing_opt_in: marketing,
            },
          },
        });

        if (error) {
          setFormError(
            error.message.toLowerCase().includes("already")
              ? "That email already has an Ayara account. Try signing in instead."
              : "We couldn't create your account just yet. Please try again.",
          );
          return;
        }

        if (!data.session) {
          void navigate({ to: "/verify-email", search: { email: email.trim() } });
          return;
        }
        void navigate({ to: "/onboarding" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) {
          setFormError(t("err.signIn"));
          return;
        }
        void navigate({ to: "/onboarding" });
      }
    } catch {
      setFormError(t("err.offline"));
    } finally {
      setPending(false);
    }
  }

  async function handleOAuth(provider: "google" | "apple") {
    setFormError(null);
    setPending(true);
    const result = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin });
    if (result.error) {
      setFormError("We couldn't finish that sign-in. Please try again.");
      setPending(false);
      return;
    }
    if (result.redirected) return;
    void navigate({ to: "/onboarding" });
  }

  return (
    <div className="mx-auto w-full max-w-md px-4 py-10">
      <div className="flex flex-col items-center text-center">
        <Aya size="sm" mood="wave" />
        <h1 className="mt-3 font-display text-2xl font-bold text-foreground md:text-3xl">
          {isSignup ? t("auth.createTitle") : t("auth.signInTitle")}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {isSignup ? t("auth.createSubtitle") : t("auth.signInSubtitle")}
        </p>
      </div>

      <div className="mt-6 grid gap-2">
        <Button variant="outline" className="h-12 rounded-xl" onClick={() => void handleOAuth("google")} disabled={pending}>
          {t("auth.google")}
        </Button>
        <Button variant="outline" className="h-12 rounded-xl" onClick={() => void handleOAuth("apple")} disabled={pending}>
          {t("auth.apple")}
        </Button>
      </div>

      <div className="my-6 flex items-center gap-3 text-xs uppercase tracking-wide text-muted-foreground">
        <span className="h-px flex-1 bg-border" />
        {t("auth.or")}
        <span className="h-px flex-1 bg-border" />
      </div>

      <form onSubmit={handleSubmit} noValidate className="grid gap-4">
        {isSignup && (
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="firstName">{t("auth.firstName")}</Label>
              <Input id="firstName" value={firstName} onChange={(e) => setFirstName(e.target.value)} autoComplete="given-name" aria-invalid={!!errors["firstName"]} />
              {errors["firstName"] && <p className="mt-1 text-xs text-destructive">{errors["firstName"]}</p>}
            </div>
            <div>
              <Label htmlFor="lastName">{t("auth.lastName")}</Label>
              <Input id="lastName" value={lastName} onChange={(e) => setLastName(e.target.value)} autoComplete="family-name" aria-invalid={!!errors["lastName"]} />
              {errors["lastName"] && <p className="mt-1 text-xs text-destructive">{errors["lastName"]}</p>}
            </div>
          </div>
        )}

        <div>
          <Label htmlFor="email">{t("auth.email")}</Label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" aria-invalid={!!errors["email"]} />
          {errors["email"] && <p className="mt-1 text-xs text-destructive">{errors["email"]}</p>}
        </div>

        <div>
          <Label htmlFor="password">{t("auth.password")}</Label>
          <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={isSignup ? "new-password" : "current-password"} aria-invalid={!!errors["password"]} />
          {isSignup && <StrengthMeter password={password} />}
          {errors["password"] && <p className="mt-1 text-xs text-destructive">{errors["password"]}</p>}
        </div>

        {isSignup && (
          <>
            <div>
              <Label htmlFor="confirm">{t("auth.confirmPassword")}</Label>
              <Input id="confirm" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" aria-invalid={!!errors["confirm"]} />
              {errors["confirm"] && <p className="mt-1 text-xs text-destructive">{errors["confirm"]}</p>}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="country">{t("auth.country")}</Label>
                <select
                  id="country"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="mt-1 h-11 w-full rounded-md border border-input bg-background px-3 text-sm"
                >
                  {COUNTRIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="language">{t("auth.language")}</Label>
                <select
                  id="language"
                  value={lang}
                  onChange={(e) => setLang(e.target.value as "en" | "es")}
                  className="mt-1 h-11 w-full rounded-md border border-input bg-background px-3 text-sm"
                >
                  <option value="en">English</option>
                  <option value="es">Español</option>
                </select>
              </div>
            </div>

            <div className="grid gap-3 rounded-xl border border-border bg-card p-4">
              <label className="flex items-start gap-3 text-sm">
                <Checkbox checked={acceptTerms} onCheckedChange={(v) => setAcceptTerms(v === true)} aria-label={t("auth.acceptTerms")} />
                <span>
                  {t("auth.acceptTerms")}{" "}
                  <Link to="/terms" className="text-primary underline-offset-2 hover:underline">
                    ({t("common.terms")})
                  </Link>
                </span>
              </label>
              {errors["terms"] && <p className="text-xs text-destructive">{errors["terms"]}</p>}

              <label className="flex items-start gap-3 text-sm">
                <Checkbox checked={acceptPrivacy} onCheckedChange={(v) => setAcceptPrivacy(v === true)} aria-label={t("auth.acceptPrivacy")} />
                <span>
                  {t("auth.acceptPrivacy")}{" "}
                  <Link to="/privacy" className="text-primary underline-offset-2 hover:underline">
                    ({t("common.privacy")})
                  </Link>
                </span>
              </label>
              {errors["privacy"] && <p className="text-xs text-destructive">{errors["privacy"]}</p>}

              <label className="flex items-start gap-3 text-sm">
                <Checkbox checked={marketing} onCheckedChange={(v) => setMarketing(v === true)} aria-label={t("auth.marketing")} />
                <span>{t("auth.marketing")}</span>
              </label>
            </div>
          </>
        )}

        {formError && (
          <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {formError}
          </p>
        )}

        <Button type="submit" size="lg" className="h-14 rounded-2xl text-base font-bold" disabled={pending}>
          {pending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSignup ? t("auth.createAccount") : t("auth.signIn")}
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        {isSignup ? (
          <>
            Already have an account?{" "}
            <Link to="/auth" search={{ mode: "signin" }} className="font-semibold text-primary hover:underline">
              {t("auth.signIn")}
            </Link>
          </>
        ) : (
          <>
            New to Ayara?{" "}
            <Link to="/auth" search={{ mode: "signup" }} className="font-semibold text-primary hover:underline">
              {t("welcome.cta")}
            </Link>
          </>
        )}
      </p>

      <p className="mt-4 text-center text-sm">
        <Link to="/child-login" className="font-semibold text-primary hover:underline">
          {t("launch.kidLogin")}
        </Link>
      </p>
    </div>
  );
}
