import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { text, format } = (await request.json()) as { text?: string; format?: string };
        if (!text || !text.trim()) {
          return new Response("Text is required", { status: 400 });
        }

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const wantsFile = format === "mp3";

        const response = await fetch("https://ai.gateway.lovable.dev/v1/audio/speech", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "openai/gpt-4o-mini-tts",
            input: text.slice(0, 3000),
            voice: "alloy",
            instructions:
              "Speak warmly, slowly and cheerfully, like a kind teacher reading to a young child.",
            ...(wantsFile
              ? { stream_format: "audio", response_format: "mp3" }
              : { stream_format: "sse", response_format: "pcm" }),
          }),
        });

        if (!response.ok) {
          const detail = await response.text().catch(() => "");
          return new Response(detail || "Text-to-speech failed", { status: response.status });
        }

        return new Response(response.body, {
          headers: { "Content-Type": wantsFile ? "audio/mpeg" : "text/event-stream" },
        });
      },

    },
  },
});
