import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import {
  createLovableAiGatewayProvider,
  getLovableAiGatewayResponseHeaders,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "@/lib/ai-gateway.server";
import { creationBriefing } from "@/lib/creations";
import {
  CORE_RULES,
  SAFETY_RULES,
  TEACHING_FRAMEWORK,
  gradeBandFor,
  modeInstruction,
  softSafetyInstruction,
} from "@/lib/aya-persona";

type ChatRequestBody = {
  messages?: unknown;
  childProfile?: {
    name: string;
    age: number;
    grade?: string;
    language?: string;
    interests?: string[];
  };
  worldPrompt?: string;
  character?: string;
  mentorTitle?: string;
  worldName?: string;
  stage?: {
    label?: string;
    blurb?: string;
  };
  /** A creation the child carried in from another world (the Ayara Universe). */
  creation?: {
    name?: string;
    kind?: string;
    traits?: string[];
    summary?: string | null;
    originWorldName?: string;
    worldNames?: string[];
  };
  tier?: {
    id?: string;
    label?: string;
    tone?: string;
    input?: string;
    gradeRange?: string;
  };
  /** Compact learning-only memory brief assembled server-side. */
  memoryBrief?: string;
  /** Ask / Explore / Imagine / Reflect */
  mode?: string;
  /** Set when screening flagged the child's last message at a lower severity. */
  softSafetyCategory?: string;
};

function buildSystemPrompt(body: ChatRequestBody) {
  const { childProfile, worldPrompt, character, tier } = body;
  const name = childProfile?.name ?? "the child";
  const age = childProfile?.age ?? 8;
  const grade = childProfile?.grade ?? `${age - 5}`;
  const language = childProfile?.language ?? "en";
  const interests = childProfile?.interests?.join(", ") ?? "learning and creating";

  const languageInstruction =
    language === "es" ? "Respond in Spanish. Responde en español." : "Respond in English.";

  const band = gradeBandFor({ grade: childProfile?.grade ?? null, age });
  const inputNote =
    band.id === "upper"
      ? `${name} is typing, so written formatting is fine.`
      : `${name} may be listening to your reply read aloud, so keep the language spoken and plain.`;

  const mentor = character ?? "Professor Nova";
  const stageInstruction = body.stage?.label
    ? `\nCURRENT STAGE OF THE LEARNING PATH: ${body.stage.label}${body.stage.blurb ? ` — ${body.stage.blurb}` : ""}\nKeep this stage's goal in mind and steer the conversation toward finishing it, then say clearly when it's done.\n`
    : "";

  const universeInstruction = body.creation?.name
    ? `\nTHE AYARA UNIVERSE:\n${creationBriefing({
        name: body.creation.name,
        kind: body.creation.kind ?? "creation",
        traits: body.creation.traits ?? [],
        summary: body.creation.summary ?? null,
        originWorldName: body.creation.originWorldName ?? "another world",
        worldNames: body.creation.worldNames ?? [],
      })}\n`
    : "";

  const memory = body.memoryBrief ? `\n${body.memoryBrief}\n` : "";
  const mode = modeInstruction(body.mode);
  const softSafety = body.softSafetyCategory ? softSafetyInstruction(body.softSafetyCategory) : "";

  return `You are Aya, the AYARA learning companion — a mentor and teammate for children, never a homework machine. In this world you appear as ${mentor}${body.mentorTitle ? `, ${body.mentorTitle}` : ""}${body.worldName ? `, the mentor of ${body.worldName}` : ""}. Stay in character as ${mentor} for the whole conversation while keeping Aya's method and values.

CHILD PROFILE:
- Name: ${name}
- Age: ${age}
- Grade: ${grade}
- Interests: ${interests}
- Tier: ${tier?.label ?? "Spark"} (grades ${tier?.gradeRange ?? "2-5"})

${CORE_RULES}

${TEACHING_FRAMEWORK}

${SAFETY_RULES}

${band.instruction}
${inputNote}

${languageInstruction}
${memory}${worldPrompt ? `\nMISSION GUIDE:\n${worldPrompt}\n` : ""}${stageInstruction}${universeInstruction}${mode ? `\n${mode}\n` : ""}${softSafety}
Open by greeting ${name} as ${mentor} and inviting them into something worth building.`;
}


export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as ChatRequestBody;
        const messages = Array.isArray(body.messages) ? body.messages : [];

        const key = process.env["LOVABLE_API_KEY"];
        if (!key) {
          return new Response("Missing LOVABLE_API_KEY", { status: 500 });
        }

        const initialRunId = getLovableAiGatewayRunId(request);
        const gateway = createLovableAiGatewayProvider(key, initialRunId);
        const model = gateway("google/gemini-3.6-flash");

        const systemPrompt = buildSystemPrompt(body);

        const result = streamText({
          model,
          instructions: systemPrompt,
          messages: await convertToModelMessages(messages as UIMessage[]),
        });

        const response = result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
          headers: getLovableAiGatewayResponseHeaders(undefined, {
            ...(initialRunId ? { "X-Lovable-AIG-Run-ID": initialRunId } : {}),
          }),
        });

        return withLovableAiGatewayRunIdHeader(response, gateway);
      },
    },
  },
});
