import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Aya } from "@/components/aya";
import { useI18n } from "@/lib/i18n";
import { MailCheck } from "lucide-react";

export const Route = createFileRoute("/verify-email")({
  validateSearch: (search: Record<string, unknown>) => ({
    email: typeof search["email"] === "string" ? search["email"] : "",
  }),
  head: () => ({
    meta: [
      { title: "Verify Your Email — Ayara" },
      { name: "description", content: "Confirm your email address to activate your Ayara family account." },
      { property: "og:title", content: "Verify Your Email — Ayara" },
      { property: "og:description", content: "Confirm your email to activate your Ayara family account." },
    ],
  }),
  component: VerifyEmailPage,
});

function VerifyEmailPage() {
  const { email } = Route.useSearch();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [status, setStatus] = useState<null | { kind: "ok" | "error"; message: string }>(null);
  const [pending, setPending] = useState(false);

  async function resend() {
    if (!email) return;
    setPending(true);
    setStatus(null);
    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
      options: { emailRedirectTo: `${window.location.origin}/onboarding` },
    });
    setPending(false);
    setStatus(
      error
        ? { kind: "error", message: "We couldn't resend that email right now. Please try again in a moment." }
        : { kind: "ok", message: "Sent! Check your inbox in a minute." },
    );
  }

  return (
    <div className="mx-auto w-full max-w-md px-4 py-12 text-center">
      <Aya size="md" mood="wave" />
      <h1 className="mt-4 font-display text-2xl font-bold text-foreground md:text-3xl">{t("verify.title")}</h1>
      <p className="mt-3 text-sm text-muted-foreground">{t("verify.body")}</p>
      {email && (
        <p className="mt-2 inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-sm font-semibold text-secondary-foreground">
          <MailCheck className="h-4 w-4" aria-hidden />
          {email}
        </p>
      )}

      <div className="mt-8 grid gap-3">
        <a href="mailto:" className="w-full">
          <Button size="lg" className="h-14 w-full rounded-2xl text-base font-bold">
            {t("verify.open")}
          </Button>
        </a>
        <Button variant="outline" className="h-12 rounded-xl" onClick={() => void resend()} disabled={pending || !email}>
          {t("verify.resend")}
        </Button>
        <Link to="/auth" search={{ mode: "signup" }}>
          <Button variant="ghost" className="w-full">
            {t("verify.change")}
          </Button>
        </Link>
        <Button variant="ghost" className="w-full text-muted-foreground" onClick={() => void navigate({ to: "/onboarding" })}>
          {t("common.skip")}
        </Button>
      </div>

      {status && (
        <p
          role="status"
          className={`mt-4 rounded-lg px-3 py-2 text-sm ${
            status.kind === "ok" ? "bg-secondary text-secondary-foreground" : "bg-destructive/10 text-destructive"
          }`}
        >
          {status.message}
        </p>
      )}

      <p className="mt-6 text-xs text-muted-foreground">
        Verification is required before starting a subscription or activating a child account.
      </p>
    </div>
  );
}
