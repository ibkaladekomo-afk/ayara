import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useServerFn } from "@tanstack/react-start";
import { useChildSession } from "@/lib/child-session-context";
import { createMyConversation } from "@/lib/child-play.functions";
import { startMyMission, advanceMyMission, completeMyMission } from "@/lib/child-dashboard.functions";
import { getBadge } from "@/lib/dashboard-content";
import { saveMyMessage } from "@/lib/child-play.functions";
import {
  getMyAyaMemory,
  claimMyCelebrations,
  logMyLearningEvent,
  summarizeMyConversation,
} from "@/lib/aya.functions";
import { AYA_MODES, REFLECTION_PROMPT, gradeBandFor, scriptedSafetyReply, type AyaMode } from "@/lib/aya-persona";
import { getWorld, getStage, FOLLOW_UP_CHIPS } from "@/lib/worlds";
import { completeStage } from "@/lib/child-worlds.functions";
import { getMyCreation, recordMyCreationAppearance } from "@/lib/child-creations.functions";
import type { CreationRecord } from "@/lib/creations";
import { creationKindMeta, crossoverPrompt } from "@/lib/creations";
import { useQuery } from "@tanstack/react-query";
import { ChildAvatar } from "@/components/child-avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useReadAloud, useVoiceInput } from "@/lib/use-voice";
import { getAgeTier } from "@/lib/age-tiers";
import { ArrowLeft, Loader2, Mic, Send, Square, Volume2, Keyboard, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";


export const Route = createFileRoute("/play/$worldId")({
  validateSearch: (search: Record<string, unknown>) => ({
    mission: typeof search['mission'] === "string" ? (search['mission'] as string) : undefined,
    start: typeof search['start'] === "string" ? (search['start'] as string) : undefined,
    stage: typeof search['stage'] === "string" ? (search['stage'] as string) : undefined,
    creation: typeof search['creation'] === "string" ? (search['creation'] as string) : undefined,
  }),
  component: MissionPage,
});

type Child = {
  id: string;
  name: string;
  age: number;
  grade: string | null;
  language: string;
  interests: string[] | null;
  avatar: string | null;
};

function MissionPage() {
  const { worldId } = Route.useParams();
  const search = Route.useSearch();
  const navigate = useNavigate();
  const world = getWorld(worldId);
  const { child, isLoading } = useChildSession();

  const [conversationId, setConversationId] = useState<string | null>(null);
  const fetchCreation = useServerFn(getMyCreation);
  const carried = useQuery({
    queryKey: ["child-creation", search.creation],
    enabled: Boolean(child && search.creation),
    queryFn: () => fetchCreation({ data: { creation_id: search.creation! } }),
  });
  const [setupError, setSetupError] = useState<string | null>(null);
  const creatingConversationRef = useRef(false);
  const createConversationFn = useServerFn(createMyConversation);

  useEffect(() => {
    if (!isLoading && !child) {
      navigate({ to: "/child-login", replace: true });
    }
  }, [child, isLoading, navigate]);

  useEffect(() => {
    if (child && !conversationId && world && !creatingConversationRef.current) {
      creatingConversationRef.current = true;
      void createConversationFn({
        data: { child_id: child.id, title: `${world.name} with ${world.character}` },
      })
        .then((conversation) => setConversationId(conversation.id))
        .catch((error: unknown) => {
          const message = error instanceof Error ? error.message : "";
          if (/login|session/i.test(message)) {
            navigate({ to: "/child-login", replace: true });
            return;
          }
          setSetupError("This mission couldn't open. Please go back and try again.");
        })
        .finally(() => {
          creatingConversationRef.current = false;
        });
    }
  }, [child, conversationId, createConversationFn, world, navigate]);

  if (!world) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <h1 className="font-display text-2xl">That world isn't ready yet</h1>
        <Button asChild className="mt-6">
          <Link to="/play">Back to worlds</Link>
        </Button>
      </div>
    );
  }

  if (setupError) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <h1 className="font-display text-2xl text-foreground">Let's try that again</h1>
        <p className="mt-2 text-muted-foreground">{setupError}</p>
        <Button asChild className="mt-6">
          <Link to="/play">Back to worlds</Link>
        </Button>
      </div>
    );
  }

  if (isLoading || !child || !conversationId) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Mission
      key={conversationId}
      conversationId={conversationId}
      child={child}
      world={world}
      missionId={search.mission ?? null}
      stageId={search.stage ?? null}
      startPrompt={search.start ?? null}
      creation={(carried.data?.creation as CreationRecord | null | undefined) ?? null}
      onBack={() => navigate({ to: "/play/world/$worldId", params: { worldId: world.id } })}
    />
  );
}

function Mission({
  conversationId,
  child,
  world,
  missionId,
  stageId,
  startPrompt,
  creation,
  onBack,
}: {
  conversationId: string;
  child: Child;
  world: NonNullable<ReturnType<typeof getWorld>>;
  missionId: string | null;
  stageId: string | null;
  startPrompt: string | null;
  creation: CreationRecord | null;
  onBack: () => void;
}) {
  const saveMessageFn = useServerFn(saveMyMessage);
  const bottomRef = useRef<HTMLDivElement>(null);
  const tier = useMemo(() => getAgeTier({ age: child.age, grade: child.grade }), [child.age, child.grade]);
  const band = useMemo(() => gradeBandFor({ age: child.age, grade: child.grade }), [child.age, child.grade]);
  const isOlder = tier.mascot === "minimal";
  const [typing, setTyping] = useState(isOlder);
  const [input, setInput] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [mode, setMode] = useState<AyaMode | null>(null);
  const [celebrations, setCelebrations] = useState<{ key: string; title: string; message: string }[]>([]);
  const { speak, stop, speaking } = useReadAloud();
  const spokenRef = useRef<string | null>(null);
  const startedAtRef = useRef(Date.now());
  const stage = useMemo(() => (stageId ? getStage(world.id, stageId) : undefined), [world.id, stageId]);

  // ---- Aya's memory: learning-only context, assembled server-side ----
  const memoryFn = useServerFn(getMyAyaMemory);
  const memory = useQuery({
    queryKey: ["aya-memory", child.id, world.id],
    queryFn: () => memoryFn({ data: { world_id: world.id } }),
    staleTime: 60_000,
  });
  const memoryBrief = memory.data?.brief ?? "";

  const logEventFn = useServerFn(logMyLearningEvent);
  const claimCelebrationsFn = useServerFn(claimMyCelebrations);
  const summarizeFn = useServerFn(summarizeMyConversation);

  const logEvent = (event: string, metadata?: Record<string, unknown>) => {
    void logEventFn({ data: { event, ...(metadata ? { metadata } : {}) } }).catch(() => {});
  };

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        body: {
          worldPrompt: world.prompt,
          character: world.character,
          mentorTitle: world.mentorTitle,
          worldName: world.name,
          ...(memoryBrief ? { memoryBrief } : {}),
          ...(stage ? { stage: { label: stage.label, blurb: stage.blurb } } : {}),
          ...(creation
            ? {
                creation: {
                  name: creation.name,
                  kind: creation.kind,
                  traits: creation.traits,
                  summary: creation.summary,
                  originWorldName: getWorld(creation.origin_world)?.name ?? creation.origin_world,
                  worldNames: creation.worlds.map((w) => getWorld(w)?.name ?? w),
                },
              }
            : {}),
          childProfile: {
            name: child.name,
            age: child.age,
            ...(child.grade ? { grade: child.grade } : {}),
            language: child.language,
            ...(child.interests ? { interests: child.interests } : {}),
          },
          tier: {
            id: tier.id,
            label: tier.label,
            tone: tier.tone,
            input: tier.input,
            gradeRange: tier.gradeRange,
          },
        },
      }),
    [world, child, tier, stage, creation, memoryBrief],
  );

  const { messages, setMessages, sendMessage, status } = useChat({
    id: conversationId,
    transport,
    onFinish: async ({ message }) => {
      const text = message.parts
        .map((p: { type: string; text?: string }) => (p.type === "text" ? p.text : ""))
        .join("");
      if (text && !isOlder && spokenRef.current !== message.id) {
        spokenRef.current = message.id;
        void speak(text);
      }
      await saveMessageFn({
        data: { conversation_id: conversationId, role: message.role, content: text },
      });
      void claimCelebrationsFn({ data: { world_id: world.id } })
        .then((r) => {
          if (r.celebrations.length) setCelebrations((prev) => [...prev, ...r.celebrations]);
        })
        .catch(() => {});
    },
    onError: () => {
      setNotice("That answer didn't load. Please tap your choice again.");
    },
  });

  const isLoading = status === "submitted" || status === "streaming";

  const send = async (text: string, options?: { mode?: AyaMode | null }) => {
    const value = text.trim();
    if (!value || isLoading) return;
    stop();
    setInput("");
    const activeMode = options?.mode ?? mode;

    let safety: { category: string; severity: string } | null = null;
    try {
      const saved = (await saveMessageFn({
        data: { conversation_id: conversationId, role: "user", content: value },
      })) as { safety?: { category: string; severity: string } | null };
      safety = saved?.safety ?? null;
    } catch {
      // keep the child moving even if saving hiccups
    }

    logEvent("question_asked", { world_id: world.id, ...(activeMode ? { mode: activeMode } : {}) });
    if (activeMode === "reflect") logEvent("reflection_completed", { world_id: world.id });

    // Empathy first: a serious flag gets a scripted reply from Aya rather than
    // anything the model improvises.
    const scripted = safety ? scriptedSafetyReply(safety.severity as "urgent", child.name, band.id) : null;
    if (scripted) {
      const now = Date.now();
      setMessages((prev) => [
        ...prev,
        { id: `child-${now}`, role: "user", parts: [{ type: "text", text: value }] },
        { id: `aya-safe-${now}`, role: "assistant", parts: [{ type: "text", text: scripted }] },
      ]);
      await saveMessageFn({
        data: { conversation_id: conversationId, role: "assistant", content: scripted },
      }).catch(() => {});
      if (!isOlder) void speak(scripted);
      setMode(null);
      return;
    }

    await sendMessage(
      { text: value },
      {
        body: {
          ...(activeMode ? { mode: activeMode } : {}),
          ...(safety && safety.severity !== "urgent" ? { softSafetyCategory: safety.category } : {}),
        },
      },
    );
    setMode(null);
  };

  const voice = useVoiceInput({
    language: child.language,
    onTranscript: (text) => {
      logEvent("voice_used", { world_id: world.id });
      void send(text);
    },
    onError: (message) => setNotice(message),
  });


  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    if (!notice) return;
    const t = window.setTimeout(() => setNotice(null), 4000);
    return () => window.clearTimeout(t);
  }, [notice]);

  // ---- Daily mission wiring (started from the dashboard) ----
  const startMissionFn = useServerFn(startMyMission);
  const advanceMissionFn = useServerFn(advanceMyMission);
  const completeMissionFn = useServerFn(completeMyMission);
  const startedRef = useRef(false);
  const [reward, setReward] = useState<{ xp: number; badge: string | null; leveledUp: boolean } | null>(null);
  const [finishing, setFinishing] = useState(false);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    if (missionId) {
      void startMissionFn({ data: { mission_id: missionId, conversation_id: conversationId } }).catch(() => {});
    }
    const carry = creation ? crossoverPrompt(world.id, creation.kind, creation.name) : null;
    const opener = [carry, startPrompt].filter(Boolean).join(" ");
    if (opener) void send(opener);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [missionId, stageId, creation?.id]);

  // ---- Ayara Universe: log that this creation visited this world ----
  const appearanceFn = useServerFn(recordMyCreationAppearance);
  const appearanceRef = useRef<string | null>(null);
  const [crossover, setCrossover] = useState<{ xp: number; crystals: number } | null>(null);
  useEffect(() => {
    if (!creation || appearanceRef.current === creation.id) return;
    appearanceRef.current = creation.id;
    void appearanceFn({
      data: { creation_id: creation.id, world_id: world.id, conversation_id: conversationId },
    })
      .then((r) => {
        if (r && (r as { xpAwarded?: number }).xpAwarded) {
          setCrossover({
            xp: (r as { xpAwarded: number }).xpAwarded,
            crystals: (r as { crystals?: number }).crystals ?? 0,
          });
        }
      })
      .catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [creation?.id, world.id]);

  const userTurns = messages.filter((m) => m.role === "user").length;
  useEffect(() => {
    if (!missionId || userTurns === 0) return;
    void advanceMissionFn({ data: { mission_id: missionId, step: Math.min(userTurns, 4) } }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userTurns, missionId]);

  /** Recap the session for the parent and pick up any milestone Aya should celebrate. */
  const wrapUpSession = () => {
    const minutes = Math.max(1, Math.round((Date.now() - startedAtRef.current) / 60000));
    void summarizeFn({ data: { conversation_id: conversationId, world_id: world.id, minutes } }).catch(() => {});
    void claimCelebrationsFn({ data: { world_id: world.id } })
      .then((r) => {
        if (r.celebrations.length) setCelebrations((prev) => [...prev, ...r.celebrations]);
      })
      .catch(() => {});
  };

  const finishMission = async () => {
    if (!missionId || finishing) return;
    setFinishing(true);
    try {
      const result = await completeMissionFn({ data: { mission_id: missionId } });
      setReward({ xp: result.xpAwarded, badge: result.badge, leveledUp: Boolean(result.leveledUp) });
      wrapUpSession();
    } catch {
      setNotice("We couldn't save that just yet. Try again in a moment.");
    } finally {
      setFinishing(false);
    }
  };


  // ---- Learning-path stage wiring (started from a world home screen) ----
  const completeStageFn = useServerFn(completeStage);
  const finishStage = async () => {
    if (!stage || finishing) return;
    setFinishing(true);
    try {
      const result = await completeStageFn({ data: { world_id: world.id, stage_id: stage.id } });
      setReward({ xp: result.xpAwarded, badge: null, leveledUp: Boolean(result.leveledUp) });
      wrapUpSession();
    } catch {
      setNotice("We couldn't save that just yet. Try again in a moment.");
    } finally {
      setFinishing(false);
    }
  };

  const chips = messages.length === 0 ? world.starters : FOLLOW_UP_CHIPS;
  const showReflect = messages.length >= 6;


  return (
    <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-2xl flex-col px-4 py-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" aria-label="Back to worlds" onClick={onBack}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <span className={`flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br ${world.tile} text-2xl`}>
          {world.emoji}
        </span>
        <div>
          <p className="font-display text-lg leading-tight text-foreground">{world.character}</p>
          <p className="text-xs text-muted-foreground">{world.name}</p>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="ml-auto"
          aria-label={speaking ? "Stop reading" : "Read last answer"}
          onClick={() => {
            if (speaking) return stop();
            const last = [...messages].reverse().find((m) => m.role === "assistant");
            const text = last?.parts.map((p) => (p.type === "text" ? p.text : "")).join("") ?? "";
            void speak(text);
          }}
        >
          <Volume2 className={`h-5 w-5 ${speaking ? "text-primary" : ""}`} />
        </Button>
      </div>

      {creation && (
        <div className="mt-3 flex items-center gap-3 rounded-2xl border border-secondary/40 bg-secondary/10 px-4 py-2.5">
          <span className="text-xl" aria-hidden>
            {creation.emoji || creationKindMeta(creation.kind).emoji}
          </span>
          <p className="min-w-0 flex-1 text-sm text-foreground">
            <span className="font-semibold">{creation.name}</span> came with you into {world.name}.
          </p>
          {crossover && crossover.xp > 0 && (
            <span className="shrink-0 rounded-full bg-secondary/30 px-2.5 py-1 text-xs font-semibold">
              +{crossover.xp} XP{crossover.crystals ? ` · +${crossover.crystals} 💎` : ""}
            </span>
          )}
        </div>
      )}

      <div className="mt-4 flex-1 space-y-4 overflow-y-auto pb-4">
        {messages.length === 0 && (
          <div className="rounded-3xl bg-muted/40 p-5 text-center">
            <p className="font-display text-xl text-foreground">
              {isOlder ? `${world.character} here — let's get to work, ${child.name}.` : `Hi ${child.name}! I'm ${world.character}.`}
            </p>
            <p className="mt-2 text-muted-foreground">
              {isOlder
                ? `${world.tagline}. Pick a prompt or type what you want to work on.`
                : `${world.tagline}. Tap a question or hold the mic to talk.`}
            </p>
          </div>
        )}

        {messages.map((message) => {
          const isUser = message.role === "user";
          const text = message.parts.map((p) => (p.type === "text" ? p.text : "")).join("");
          return (
            <div key={message.id} className={`flex items-end gap-2 ${isUser ? "flex-row-reverse" : ""}`}>
              {isUser ? (
                <ChildAvatar avatar={child.avatar} size="sm" />
              ) : (
                <span className={`flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br ${world.tile} text-lg`}>
                  {world.emoji}
                </span>
              )}
              <div
                className={
                  isUser
                    ? "max-w-[80%] rounded-3xl bg-primary px-4 py-3 text-base text-primary-foreground"
                    : "max-w-[85%] text-base leading-relaxed text-foreground"
                }
              >
                <div className="prose prose-sm max-w-none prose-p:my-2 prose-headings:font-display">
                  <ReactMarkdown>{text}</ReactMarkdown>
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
          <p className="animate-pulse font-display text-muted-foreground">Thinking...</p>
        )}
        <div ref={bottomRef} />
      </div>

      {celebrations.map((celebration) => (
        <div
          key={celebration.key}
          className="mb-3 flex items-start gap-3 rounded-3xl border border-secondary/40 bg-secondary/10 p-4"
        >
          <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-primary" aria-hidden />
          <div className="min-w-0">
            <p className="font-display text-base text-foreground">{celebration.title}</p>
            <p className="text-sm text-muted-foreground">{celebration.message}</p>
          </div>
        </div>
      ))}

      {reward && (

        <div className="mb-3 rounded-3xl border border-primary/30 bg-primary/10 p-5 text-center">
          <p className="font-display text-2xl text-foreground">
            {reward.leveledUp ? "Level up! 🎉" : isOlder ? "Mission complete." : "You did it! 🎉"}
          </p>
          <p className="mt-1 text-foreground">+{reward.xp} XP</p>
          {reward.badge && (
            <p className="mt-2 inline-flex items-center gap-2 rounded-full bg-secondary/25 px-4 py-1.5 text-sm font-semibold text-foreground">
              <span aria-hidden>{getBadge(reward.badge).emoji}</span> {getBadge(reward.badge).name} unlocked
            </p>
          )}
          <Button className="mt-4 rounded-full" onClick={onBack}>
            {stage ? `Back to ${world.name}` : "Back to my dashboard"}
          </Button>
        </div>
      )}

      {missionId && !reward && messages.length >= 2 && (
        <Button variant="outline" className="mb-3 rounded-full" onClick={() => void finishMission()} disabled={finishing}>
          {finishing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          {isOlder ? "Mark mission complete" : "I'm finished!"}
        </Button>
      )}

      {!missionId && stage && !reward && messages.length >= 2 && (
        <Button variant="outline" className="mb-3 rounded-full" onClick={() => void finishStage()} disabled={finishing}>
          {finishing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          {isOlder ? `Mark "${stage.label}" complete` : "I finished this part!"}
        </Button>
      )}


      {notice && (
        <p className="mb-2 rounded-xl bg-destructive/10 px-3 py-2 text-center text-sm text-destructive">{notice}</p>
      )}

      <div className="sticky bottom-0 space-y-3 bg-background/90 pb-4 pt-2 backdrop-blur">
        <div className="flex flex-wrap justify-center gap-2">
          {AYA_MODES.filter((m) => m.id !== "reflect" || showReflect).map((m) => (
            <button
              key={m.id}
              type="button"
              aria-pressed={mode === m.id}
              onClick={() => {
                if (m.id === "reflect") {
                  setMode("reflect");
                  void send(REFLECTION_PROMPT, { mode: "reflect" });
                  return;
                }
                setMode((current) => (current === m.id ? null : m.id));
                setTyping(true);
              }}
              className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors ${
                mode === m.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-muted/40 text-muted-foreground hover:bg-muted"
              }`}
            >
              <span aria-hidden className="mr-1">
                {m.emoji}
              </span>
              {m.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-2">
          {chips.map((chip) => (

            <button
              key={chip}
              onClick={() => void send(chip)}
              disabled={isLoading}
              className="rounded-full border border-primary/30 bg-primary/5 px-4 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-primary/15 disabled:opacity-50"
            >
              {chip}
            </button>
          ))}
        </div>

        <div className={`flex items-center justify-center gap-3 ${isOlder ? "hidden" : ""}`}>
          <Button
            size="lg"
            aria-label={voice.isRecording ? "Stop talking" : "Hold to talk"}
            disabled={voice.isTranscribing || isLoading}
            onPointerDown={() => void voice.start()}
            onPointerUp={() => void voice.stop()}
            onPointerLeave={() => voice.isRecording && void voice.stop()}
            className={`h-20 w-20 rounded-full text-primary-foreground shadow-lg transition-transform ${
              voice.isRecording ? "scale-110 animate-pulse bg-destructive" : ""
            }`}
          >
            {voice.isTranscribing ? (
              <Loader2 className="h-8 w-8 animate-spin" />
            ) : voice.isRecording ? (
              <Square className="h-7 w-7" />
            ) : (
              <Mic className="h-8 w-8" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={typing ? "Hide keyboard" : "Type instead"}
            onClick={() => setTyping((t) => !t)}
          >
            <Keyboard className="h-5 w-5" />
          </Button>
        </div>
        {!isOlder && (
          <p className="text-center text-xs text-muted-foreground">
            {voice.isRecording ? "Listening… let go when you're done" : "Hold the mic and talk"}
          </p>
        )}

        {typing && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void send(input);
            }}
            className="flex gap-2"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isOlder ? "What are you building or figuring out?" : "Type a message"}
              className="h-12 rounded-full text-base"
              autoFocus
            />
            {isOlder && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-12 w-12 rounded-full"
                aria-label={voice.isRecording ? "Stop recording" : "Use voice instead"}
                disabled={voice.isTranscribing || isLoading}
                onClick={() => void (voice.isRecording ? voice.stop() : voice.start())}
              >
                {voice.isTranscribing ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : voice.isRecording ? (
                  <Square className="h-5 w-5 text-destructive" />
                ) : (
                  <Mic className="h-5 w-5" />
                )}
              </Button>
            )}
            <Button type="submit" size="icon" className="h-12 w-12 rounded-full" disabled={isLoading} aria-label="Send">
              <Send className="h-5 w-5" />
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
