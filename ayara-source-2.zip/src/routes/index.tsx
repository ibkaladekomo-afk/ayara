import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Aya } from "@/components/aya";
import { useI18n } from "@/lib/i18n";
import heroCreative from "@/assets/ayara-hero-creative.png.asset.json";
import { Shield, Sparkles, Users } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ayara — The Premium AI Learning Platform for Children" },
      {
        name: "description",
        content:
          "Ayara is the premium AI learning platform that grows with your child. Safe, guided AI learning for Grades 2–8, with parents fully in control.",
      },
      { property: "og:title", content: "Ayara — The Premium AI Learning Platform for Children" },
      {
        property: "og:description",
        content: "Ayara is the premium AI learning platform that grows with your child. Safe, guided AI learning for Grades 2–8, with parents fully in control.",
      },
    ],
  }),
  component: LaunchPage,
});

function LanguagePicker() {
  const { lang, setLang } = useI18n();
  return (
    <div className="inline-flex items-center gap-1 rounded-full border border-border bg-card p-1" role="group" aria-label="Language">
      {(["en", "es"] as const).map((code) => (
        <button
          key={code}
          type="button"
          onClick={() => setLang(code)}
          aria-pressed={lang === code}
          className={`min-w-11 rounded-full px-3 py-1 text-sm font-semibold transition-colors ${
            lang === code ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          {code === "en" ? "English" : "Español"}
        </button>
      ))}
    </div>
  );
}

function LaunchPage() {
  const { t } = useI18n();

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col px-4 pb-16 pt-8 md:px-6">
      <section className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-ayara-navy via-ayara-violet to-ayara-blue p-5 md:p-8">
        <div className="relative flex flex-col items-center text-center">
          <img
            src={heroCreative.url}
            alt="A child building a robot with Aya, the Ayara AI companion, in a creative studio"
            width={1024}
            height={768}
            className="w-full max-w-2xl rounded-2xl shadow-[0_24px_60px_-20px_rgba(0,0,0,0.45)]"
          />
          <div className="absolute -bottom-3 -right-2 md:bottom-2 md:right-4">
            <Aya size="sm" mood="idle" className="h-14 w-14 drop-shadow-[0_8px_20px_rgba(76,124,245,0.45)] md:h-16 md:w-16" />
          </div>
        </div>

        <div className="relative mt-8 flex flex-col items-center text-center md:mt-10">
          <h1 className="max-w-2xl font-display text-3xl font-bold leading-tight text-white md:text-5xl">
            {t("launch.greeting")}
          </h1>
          <p className="mt-4 max-w-xl text-base text-white/85 md:text-lg">{t("launch.mission")}</p>

          <div className="mt-8 flex w-full max-w-sm flex-col gap-3">
            <Link to="/welcome" className="w-full">
              <Button size="lg" className="h-14 w-full rounded-2xl bg-white text-base font-bold text-ayara-violet hover:bg-white/90">
                {t("launch.getStarted")}
              </Button>
            </Link>
            <Link to="/auth" search={{ mode: "signin" }} className="w-full">
              <Button size="lg" variant="outline" className="h-14 w-full rounded-2xl border-white/30 bg-white/10 text-base font-semibold text-white hover:bg-white/20 hover:text-white">
                {t("launch.haveAccount")}
              </Button>
            </Link>
            <Link
              to="/child-login"
              className="mt-1 text-sm font-semibold text-white/90 underline-offset-4 hover:text-white hover:underline"
            >
              {t("launch.kidLogin")}
            </Link>
          </div>
        </div>
      </section>

      <section className="mt-14 grid gap-4 sm:grid-cols-3">
        {[
          { icon: Sparkles, titleKey: "launch.feature.projects.title" as const, bodyKey: "launch.feature.projects.body" as const },
          { icon: Shield, titleKey: "launch.feature.safety.title" as const, bodyKey: "launch.feature.safety.body" as const },
          { icon: Users, titleKey: "launch.feature.parents.title" as const, bodyKey: "launch.feature.parents.body" as const },
        ].map((item) => (
          <div key={item.titleKey} className="rounded-2xl border border-border bg-card p-5 text-left">
            <item.icon className="h-6 w-6 text-primary" aria-hidden />
            <h2 className="mt-3 font-heading text-base font-bold text-foreground">{t(item.titleKey)}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{t(item.bodyKey)}</p>
          </div>
        ))}
      </section>

      <footer className="mt-12 flex flex-col items-center gap-4">
        <LanguagePicker />
        <nav className="flex flex-wrap items-center justify-center gap-4 text-sm text-muted-foreground">
          <Link to="/privacy" className="hover:text-foreground">
            {t("common.privacy")}
          </Link>
          <Link to="/terms" className="hover:text-foreground">
            {t("common.terms")}
          </Link>
          <Link to="/safety" className="hover:text-foreground">
            Safety
          </Link>
        </nav>
      </footer>
    </div>
  );
}
