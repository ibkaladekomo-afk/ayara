import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Aya } from "@/components/aya";
import { useI18n } from "@/lib/i18n";
import illusWelcome from "@/assets/welcome-innovator.jpg";
import illusWorlds from "@/assets/welcome-worlds-map.jpg";
import illusParent from "@/assets/welcome-parent-control.jpg";


export const Route = createFileRoute("/welcome")({
  head: () => ({
    meta: [
      { title: "Welcome to Ayara — How Ayara Works" },
      {
        name: "description",
        content:
          "Three quick screens: what Ayara is, how children learn through missions and stories, and how parents stay in control.",
      },
      { property: "og:title", content: "Welcome to Ayara" },
      { property: "og:description", content: "How children learn with Ayara, and how parents stay in control." },
    ],
  }),
  component: WelcomeCarousel,
});

function WelcomeCarousel() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);

  const screens = [
    { title: t("welcome.1.title"), body: t("welcome.1.body"), image: illusWelcome, alt: "A boy and a girl prototyping a robot together in an AI-powered creative studio" },
    { title: t("welcome.2.title"), body: t("welcome.2.body"), image: illusWorlds, alt: "The four Ayara Learning Worlds connected as a constellation" },
    { title: t("welcome.3.title"), body: t("welcome.3.body"), image: illusParent, alt: "A parent reviewing progress on the Ayara dashboard" },
  ];

  const screen = screens[index]!;
  const isLast = index === screens.length - 1;

  return (
    <div className="mx-auto flex min-h-[80vh] w-full max-w-lg flex-col items-center px-4 py-8 text-center">
      <div className="w-full overflow-hidden rounded-3xl bg-gradient-to-b from-primary/20 to-accent/10 p-1 shadow-[0_24px_60px_-30px_rgba(120,103,248,0.55)]">
        <img
          src={screen.image}
          alt={screen.alt}
          width={1024}
          height={768}
          loading="lazy"
          className="w-full rounded-[1.35rem]"
        />
      </div>

      <h1 className="mt-8 font-display text-3xl font-bold leading-tight text-foreground md:text-4xl">
        {screen.title}
      </h1>
      <p className="mt-3 max-w-md text-base text-muted-foreground">{screen.body}</p>


      <div className="mt-6 flex items-center gap-2" role="tablist" aria-label="Welcome progress">
        {screens.map((s, i) => (
          <button
            key={s.title}
            type="button"
            role="tab"
            aria-selected={i === index}
            aria-label={`Screen ${i + 1}`}
            onClick={() => setIndex(i)}
            className={`h-2.5 rounded-full transition-all ${i === index ? "w-8 bg-primary" : "w-2.5 bg-border"}`}
            style={{ minHeight: "auto" }}
          />
        ))}
      </div>

      <div className="mt-auto w-full pt-10">
        <Button
          size="lg"
          className="h-14 w-full rounded-2xl text-base font-bold"
          onClick={() => {
            if (isLast) {
              void navigate({ to: "/auth", search: { mode: "signup" } });
            } else {
              setIndex((i) => i + 1);
            }
          }}
        >
          {isLast ? t("welcome.cta") : t("common.continue")}
        </Button>

        {index > 0 && (
          <Button variant="ghost" className="mt-2 w-full" onClick={() => setIndex((i) => i - 1)}>
            {t("common.back")}
          </Button>
        )}
      </div>

      <div className="pt-8">
        <Aya size="sm" mood="wave" />
      </div>
    </div>
  );
}
