import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { LEARNING_WORLDS, UPCOMING_WORLDS, getWorld } from "@/lib/worlds";
import { ChildAvatar } from "@/components/child-avatar";
import { Loader2, Volume2, Flame, Sparkles, Clock, ArrowRight, Trophy, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useReadAloud } from "@/lib/use-voice";
import { useChildSession } from "@/lib/child-session-context";
import { getAgeTier, tierSubtitle } from "@/lib/age-tiers";
import { readArrival, resetArrival } from "@/lib/arrival";
import { getMyDashboard } from "@/lib/child-dashboard.functions";
import {
  pickGreeting,
  getSeasonAccent,
  streakMessage,
  nextStreakMilestone,
  getBadge,
  BADGES,
} from "@/lib/dashboard-content";

export const Route = createFileRoute("/play/")({
  head: () => ({
    meta: [
      { title: "Innovation Hub — AYARA" },
      { name: "description", content: "Today's mission, your streak, your XP and everything you've created in your AYARA Innovation Hub." },
      { property: "og:title", content: "Innovation Hub — AYARA" },
      { property: "og:description", content: "Today's mission, your streak, your XP and everything you've created." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlayHome,
});

function PlayHome() {
  const { child, isLoading } = useChildSession();
  const navigate = useNavigate();
  const { speak, speaking, stop } = useReadAloud();
  const tier = child ? getAgeTier({ age: child.age, grade: child.grade }) : null;
  const [arrivalChecked, setArrivalChecked] = useState(false);

  const greeting = useMemo(
    () => (child && tier ? pickGreeting(tier.id, child.name) : ""),
    [child, tier],
  );
  const season = useMemo(() => getSeasonAccent(), []);

  const fetchDashboard = useServerFn(getMyDashboard);
  const dashboard = useQuery({
    queryKey: ["child-dashboard", child?.id],
    enabled: Boolean(child && arrivalChecked),
    queryFn: () => fetchDashboard({ data: { tz_offset_minutes: new Date().getTimezoneOffset() } }),
  });

  useEffect(() => {
    if (!child) return;
    if (!readArrival(child.id)) {
      void navigate({ to: "/play/arrival", replace: true });
      return;
    }
    setArrivalChecked(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [child?.id]);

  useEffect(() => {
    if (arrivalChecked && child && tier?.id === "spark" && greeting) speak(greeting);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [child?.id, arrivalChecked]);

  if (isLoading || (child && !arrivalChecked)) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!child || !tier) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="font-display text-2xl text-foreground">Child login required</h1>
        <p className="mt-2 text-muted-foreground">Ask a parent to set up your login, then sign in here.</p>
        <Button asChild className="mt-6">
          <Link to="/child-login">Go to child login</Link>
        </Button>
      </div>
    );
  }

  const isOlder = tier.mascot === "minimal";
  const data = dashboard.data;
  const mission = data?.mission;
  const missionWorld = mission ? getWorld(mission.world_id) : undefined;
  const level = data?.level;
  const streakDays = data?.streak.days ?? 0;

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 pb-16">
      {/* Greeting */}
      <header
        className={`grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 rounded-3xl bg-gradient-to-br ${season.wash} p-5 text-background sm:flex sm:justify-between`}
      >
        <div className="flex min-w-0 items-center gap-3">
          <div className="shrink-0">
            <ChildAvatar avatar={child.avatar} size="lg" />
          </div>
          <div className="min-w-0">
            <h1 className={`font-display leading-tight ${isOlder ? "text-xl sm:text-2xl" : "text-2xl sm:text-3xl"}`}>
              {greeting}
            </h1>
            <p className="mt-1 text-sm text-background/85">
              <span aria-hidden>{season.emoji}</span> {tierSubtitle(tier.id)}
            </p>
          </div>
        </div>
        {!isOlder && (
          <Button
            variant="secondary"
            size="icon"
            className="h-11 w-11 shrink-0 rounded-full"
            aria-label={speaking ? "Stop reading" : "Read this to me"}
            onClick={() => (speaking ? stop() : speak(greeting))}
          >
            <Volume2 className="h-5 w-5" />
          </Button>
        )}
      </header>

      {dashboard.isLoading && (
        <div className="flex justify-center py-10">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      )}

      {dashboard.isError && (
        <p className="mt-6 rounded-2xl bg-destructive/10 px-4 py-3 text-center text-sm text-destructive">
          We couldn't load your Innovation Hub. Pull down to refresh or pick a world below.
        </p>
      )}

      {/* Streak + XP */}
      {data && level && (
        <section className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="rounded-3xl border border-border bg-card p-4">
            <div className="flex items-center gap-2">
              <Flame className={`h-5 w-5 shrink-0 ${streakDays > 0 ? "text-[oklch(0.72_0.18_45)]" : "text-muted-foreground"}`} />
              <p className="font-display text-lg text-foreground">
                {streakDays} day{streakDays === 1 ? "" : "s"} in a row
              </p>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{streakMessage(streakDays, tier.id)}</p>
            {data.streak.recovered && (
              <p className="mt-2 rounded-xl bg-secondary/20 px-3 py-2 text-sm text-foreground">
                ✨ Spark Recovery — you missed a day, but your streak is safe. Welcome back!
              </p>
            )}
            <div className="mt-3 flex gap-1" aria-hidden>
              {Array.from({ length: Math.min(nextStreakMilestone(streakDays), 7) }).map((_, i) => (
                <span
                  key={i}
                  className={`h-2 flex-1 rounded-full ${i < Math.min(streakDays, 7) ? "bg-[oklch(0.72_0.18_45)]" : "bg-muted"}`}
                />
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-border bg-card p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="font-display text-lg text-foreground">
                Level {level.level} · {level.title}
              </p>
              <span className="shrink-0 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                {level.xp} XP
              </span>
            </div>
            <div className="mt-3 h-3 overflow-hidden rounded-full bg-muted">
              <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${level.percent}%` }} />
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {level.xpToNext} XP to level {level.level + 1}
            </p>
          </div>
        </section>
      )}

      {/* Today's mission */}
      {mission && missionWorld && (
        <section className="mt-4">
          <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-muted-foreground">Today's mission</h2>
          <div className={`rounded-3xl bg-gradient-to-br ${missionWorld.tile} p-5 text-background shadow-lg`}>
            <div className="flex items-center gap-2 text-sm font-semibold text-background/90">
              <span className="text-2xl" aria-hidden>
                {missionWorld.emoji}
              </span>
              <span>{missionWorld.name}</span>
              <span className="ml-auto inline-flex items-center gap-1">
                <Clock className="h-4 w-4" /> {mission.estimated_minutes} min
              </span>
            </div>
            <h3 className="mt-3 font-display text-2xl leading-tight">{mission.title}</h3>
            <p className="mt-1 text-sm text-background/90">
              With {missionWorld.character} · +{mission.xp_reward} XP
              {mission.badge_reward ? ` · ${getBadge(mission.badge_reward).emoji} ${getBadge(mission.badge_reward).name}` : ""}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {mission.steps.map((step: string, i: number) => (
                <span
                  key={step}
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${
                    i < mission.progress_step ? "bg-background text-foreground" : "bg-background/25 text-background"
                  }`}
                >
                  {i + 1}. {step}
                </span>
              ))}
            </div>
            <Button asChild size="lg" variant="secondary" className="mt-5 h-12 w-full rounded-full text-base">
              <Link
                to="/play/$worldId"
                params={{ worldId: mission.world_id }}
                search={{ mission: mission.id, start: mission.prompt }}
              >
                {mission.progress_step > 0 ? "Keep going" : isOlder ? "Start the build" : "Let's go!"}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
          <Button asChild variant="ghost" className="mt-3 h-11 w-full rounded-full">
            <Link to="/play/missions">See all missions</Link>
          </Button>
        </section>
      )}

      {/* Continue learning */}
      {data && data.inProgress.length > 0 && (
        <section className="mt-6">
          <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-muted-foreground">Continue learning</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {data.inProgress.map((item: any) => {
              const world = getWorld(item.world_id);
              const percent = Math.round((item.progress_step / Math.max(1, item.total_steps)) * 100);
              return (
                <Link
                  key={item.id}
                  to="/play/$worldId"
                  params={{ worldId: item.world_id }}
                  search={{ mission: item.id, start: "" }}
                  className="rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xl" aria-hidden>
                      {world?.emoji ?? "✨"}
                    </span>
                    <p className="min-w-0 flex-1 truncate font-display text-base text-foreground">{item.title}</p>
                  </div>
                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${percent}%` }} />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{percent}% done · pick up where you left off</p>
                </Link>
              );
            })}
          </div>
        </section>
      )}

      {/* Worlds */}
      <section className="mt-6">
        <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
          {isOlder ? "Studios" : "Explore a world"}
        </h2>
        <div className={isOlder ? "grid gap-3 sm:grid-cols-2" : "grid grid-cols-2 gap-4 md:grid-cols-3"}>
          {LEARNING_WORLDS.map((world) => (
            <Link
              key={world.id}
              to="/play/world/$worldId"
              params={{ worldId: world.id }}
              className={`group flex flex-col justify-between rounded-3xl bg-gradient-to-br ${world.tile} p-4 text-left shadow-md transition-transform hover:-translate-y-1 hover:shadow-xl ${
                isOlder ? "min-h-28 rounded-2xl" : "aspect-square"
              }`}
            >
              <span className={isOlder ? "text-2xl" : "text-4xl md:text-5xl"} aria-hidden>
                {world.emoji}
              </span>
              <span>
                <span
                  className={`block font-display leading-tight text-background ${
                    isOlder ? "text-base" : "text-lg md:text-xl"
                  }`}
                >
                  {world.name}
                </span>
                <span className="mt-1 block text-xs font-medium text-background/85">{world.tagline}</span>
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Worlds still being built */}
      <section className="mt-6">
        <h2 className="mb-2 font-display text-sm uppercase tracking-wide text-muted-foreground">Coming soon</h2>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {UPCOMING_WORLDS.map((world) => (
            <div
              key={world.id}
              className="flex min-h-24 flex-col justify-between rounded-2xl border border-dashed border-border bg-muted/40 p-4"
            >
              <span className="text-2xl opacity-60" aria-hidden>
                {world.emoji}
              </span>
              <span>
                <span className="block font-display text-base leading-tight text-foreground">{world.name}</span>
                <span className="mt-1 block text-xs text-muted-foreground">{world.tagline}</span>
              </span>
            </div>
          ))}
        </div>
      </section>


      {/* Achievements */}
      {data && (
        <section className="mt-6">
          <h2 className="mb-2 flex items-center gap-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
            <Trophy className="h-4 w-4" /> Achievements
          </h2>
          <div className="rounded-3xl border border-border bg-card p-4">
            <p className="text-sm text-muted-foreground">
              {data.badges.length} of {BADGES.length} badges · {data.missionsCompleted} missions completed
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {BADGES.map((badge) => {
                const earned = data.badges.some((b: { badge_id: string }) => b.badge_id === badge.id);
                return (
                  <span
                    key={badge.id}
                    title={badge.description}
                    className={`inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-sm font-semibold ${
                      earned ? "bg-secondary/25 text-foreground" : "bg-muted text-muted-foreground opacity-60"
                    }`}
                  >
                    <span aria-hidden>{earned ? badge.emoji : "🔒"}</span>
                    {badge.name}
                  </span>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Ayara Universe entry */}
      <section className="mt-6">
        <Link
          to="/play/universe"
          className="flex items-center gap-4 rounded-3xl bg-gradient-to-br from-primary via-primary/85 to-secondary p-5 text-primary-foreground shadow-lg"
        >
          <span className="text-3xl" aria-hidden>
            🌌
          </span>
          <div className="min-w-0">
            <p className="font-display text-lg leading-tight">My Universe</p>
            <p className="text-sm text-primary-foreground/85">
              {isOlder
                ? "Every creation you've made — and the worlds it can travel to next."
                : "See everything you've made and take it into a new world!"}
            </p>
          </div>
        </Link>
      </section>

      {/* Portfolio preview */}
      {data && (
        <section className="mt-6">
          <h2 className="mb-2 flex items-center gap-2 font-display text-sm uppercase tracking-wide text-muted-foreground">
            <FolderOpen className="h-4 w-4" /> {isOlder ? "Your work" : "Your creations"}
          </h2>
          {data.portfolio.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-border p-6 text-center">
              <Sparkles className="mx-auto h-6 w-6 text-primary" />
              <p className="mt-2 text-sm text-muted-foreground">
                Nothing here yet — finish today's mission and your first creation lands right here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {data.portfolio.map((item: any) => {
                const world = getWorld(item.world_id ?? "");
                return (
                  <div key={item.id} className="rounded-2xl border border-border bg-card p-3">
                    <span className="text-2xl" aria-hidden>
                      {world?.emoji ?? "🗂️"}
                    </span>
                    <p className="mt-1 line-clamp-2 font-display text-sm text-foreground">{item.title}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {new Date(item.created_at).toLocaleDateString()}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      <div className="mt-8 text-center">
        <Button
          variant="ghost"
          size="sm"
          className="rounded-full text-muted-foreground"
          onClick={() => {
            stop();
            resetArrival(child.id);
            void navigate({ to: "/play/arrival" });
          }}
        >
          {isOlder ? "Replay the studio intro" : "Play the welcome again"}
        </Button>
      </div>
    </div>
  );
}
