import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — Ayara" },
      {
        name: "description",
        content: "How Ayara collects, uses, and protects family and children's data on our AI learning platform.",
      },
      { property: "og:title", content: "Privacy Policy — Ayara" },
      { property: "og:description", content: "How Ayara protects family and children's data." },
    ],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <article className="mx-auto w-full max-w-2xl px-4 py-12">
      <h1 className="font-display text-3xl font-bold text-foreground">Privacy Policy</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        This page is maintained by Ayara to explain how we handle family and children's information.
      </p>

      <section className="mt-8 grid gap-6 text-sm leading-relaxed text-muted-foreground">
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Who controls the account</h2>
          <p>
            Every Ayara account is created and owned by a parent or guardian aged 18 or older. Children access Ayara
            only through a child profile that the parent creates, and they cannot change safety settings, make
            purchases, or manage the account.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">What we collect</h2>
          <p>
            Parent name, email address, country, language, and notification and safety preferences. For each child
            profile: first name, avatar, grade, age, language, interests, a username, and a PIN that is stored only as
            a one-way hash. We also store learning activity and AI conversation transcripts so parents can review them.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">How we use it</h2>
          <p>
            To adapt lessons to the child's grade and language, to show parents progress and transcripts, to apply the
            safety settings the parent chose, and to operate and improve the service. Ayara does not run third-party
            advertising to children.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">AI processing</h2>
          <p>
            Conversations are processed by an AI provider through Ayara's own orchestration layer. Children never
            interact with an underlying provider directly, and every response passes through Ayara's moderation and
            age-adaptation rules before it is shown.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Your choices</h2>
          <p>
            Parents can turn off conversation history, disable voice and microphone access, delete a child profile, or
            delete the family account at any time from the parent dashboard. Contact us to request an export or
            deletion of your family's data.
          </p>
        </div>
      </section>
    </article>
  );
}
