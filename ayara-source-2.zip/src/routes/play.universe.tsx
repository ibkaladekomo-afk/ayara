import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useChildSession } from "@/lib/child-session-context";
import { getAgeTier } from "@/lib/age-tiers";
import { getWorld, LEARNING_WORLDS } from "@/lib/worlds";
import { listMyCreations } from "@/lib/child-creations.functions";
import { creationKindMeta, UNIVERSE_MILESTONES, type CreationRecord } from "@/lib/creations";

export const Route = createFileRoute("/play/universe")({
  head: () => ({
    meta: [
      { title: "My Universe — AYARA" },
      {
        name: "description",
        content:
          "Everything you've created in AYARA lives here: characters, inventions and stories that travel between Learning Worlds.",
      },
      { property: "og:title", content: "My Universe — AYARA" },
      {
        property: "og:description",
        content: "Your creations and the worlds they've travelled to, all in one constellation.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: UniversePage,
});

function UniversePage() {
  const navigate = useNavigate();
  const { child, isLoading } = useChildSession();
  const tier = child ? getAgeTier({ age: child.age, grade: child.grade }) : null;
  const isOlder = tier?.mascot === "minimal";

  const fetchUniverse = useServerFn(listMyCreations);
  const universe = useQuery({
    queryKey: ["child-universe", child?.id],
    enabled: Boolean(child),
    queryFn: () => fetchUniverse({}),
  });

  useEffect(() => {
    if (!isLoading && !child) navigate({ to: "/child-login", replace: true });
  }, [child, isLoading, navigate]);

  const creations = (universe.data?.creations ?? []) as CreationRecord[];
  const stats = universe.data?.stats ?? { creations: 0, crossovers: 0, maxWorlds: 0 };
  const milestones = useMemo(
    () => UNIVERSE_MILESTONES.map((m) => ({ ...m, done: m.reached(stats) })),
    [stats],
  );

  if (isLoading || !child) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-4 pb-20">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" aria-label="Back to the Innovation Hub" asChild>
          <Link to="/play">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div>
          <h1 className="font-display text-xl leading-tight text-foreground">My Universe</h1>
          <p className="text-xs text-muted-foreground">
            {stats.creations} creations · {stats.crossovers} crossovers
          </p>
        </div>
      </div>

      <section className="mt-4 rounded-3xl bg-gradient-to-br from-primary via-primary/80 to-secondary p-5 text-primary-foreground shadow-lg">
        <p className="font-display text-lg leading-snug">
          {isOlder
            ? "Everything you build here stays. Take it into another world and it evolves."
            : "Everything you make lives here. Bring your creations along to new worlds!"}
        </p>
      </section>

      {universe.isLoading && (
        <div className="flex justify-center py-10">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      )}

      {!universe.isLoading && creations.length === 0 && (
        <div className="mt-6 rounded-3xl border border-dashed border-border p-8 text-center">
          <span className="text-4xl" aria-hidden>
            🌌
          </span>
          <p className="mt-3 font-display text-xl text-foreground">Your universe is empty — for now</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Finish a Master Project in any world and your creation appears here.
          </p>
          <Button asChild className="mt-5 rounded-full">
            <Link to="/play">Pick a world</Link>
          </Button>
        </div>
      )}

      {creations.length > 0 && (
        <section className="mt-6 space-y-3">
          <h2 className="font-display text-sm uppercase tracking-wide text-muted-foreground">Your creations</h2>
          {creations.map((creation) => {
            const meta = creationKindMeta(creation.kind);
            const origin = getWorld(creation.origin_world);
            const elsewhere = LEARNING_WORLDS.filter(
              (w) => w.id !== creation.origin_world && !creation.worlds.includes(w.id),
            ).slice(0, 3);
            return (
              <article key={creation.id} className="rounded-3xl border border-border bg-card p-4">
                <div className="flex items-start gap-3">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-muted text-2xl">
                    {creation.emoji || meta.emoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-display text-lg leading-tight text-foreground">{creation.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {meta.label} · born in {origin?.name ?? creation.origin_world}
                    </p>
                    {creation.summary && (
                      <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{creation.summary}</p>
                    )}
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {creation.worlds.map((w) => (
                        <span
                          key={w}
                          className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground"
                        >
                          {getWorld(w)?.emoji ?? "✨"} {getWorld(w)?.name ?? w}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {elsewhere.length > 0 && (
                  <div className="mt-4">
                    <p className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                      <Sparkles className="h-3.5 w-3.5" /> Take {creation.name} somewhere new
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {elsewhere.map((w) => (
                        <Button key={w.id} asChild size="sm" variant="outline" className="rounded-full">
                          <Link
                            to="/play/$worldId"
                            params={{ worldId: w.id }}
                            search={{
                              mission: undefined,
                              start: undefined,
                              stage: undefined,
                              creation: creation.id,
                            }}
                          >
                            {w.emoji} {w.name}
                          </Link>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </section>
      )}

      <section className="mt-8">
        <h2 className="font-display text-sm uppercase tracking-wide text-muted-foreground">Universe milestones</h2>
        <ul className="mt-2 grid gap-2 sm:grid-cols-2">
          {milestones.map((m) => (
            <li
              key={m.id}
              className={`flex items-center gap-3 rounded-2xl border p-3 ${
                m.done ? "border-secondary/50 bg-secondary/10" : "border-border bg-card opacity-70"
              }`}
            >
              <span className="text-2xl" aria-hidden>
                {m.emoji}
              </span>
              <div className="min-w-0">
                <p className="font-display text-base leading-tight text-foreground">{m.label}</p>
                <p className="text-xs text-muted-foreground">{m.detail}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
