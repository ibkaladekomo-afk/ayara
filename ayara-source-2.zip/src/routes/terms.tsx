import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Service — Ayara" },
      { name: "description", content: "The terms that govern parent and child use of the Ayara AI learning platform." },
      { property: "og:title", content: "Terms of Service — Ayara" },
      { property: "og:description", content: "The terms that govern use of the Ayara AI learning platform." },
    ],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <article className="mx-auto w-full max-w-2xl px-4 py-12">
      <h1 className="font-display text-3xl font-bold text-foreground">Terms of Service</h1>
      <p className="mt-2 text-sm text-muted-foreground">Please read these terms before creating a family account.</p>

      <section className="mt-8 grid gap-6 text-sm leading-relaxed text-muted-foreground">
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Eligibility</h2>
          <p>
            Ayara accounts may only be created by a parent or guardian aged 18 or older. By creating an account you
            confirm you have the authority to consent on behalf of each child profile you add.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Acceptable use</h2>
          <p>
            Ayara is an educational platform for children. Do not use it to generate harmful, unlawful, or
            age-inappropriate content, and do not attempt to bypass the safety layer or share account credentials
            outside your family.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Subscriptions</h2>
          <p>
            The Free Explorer plan is available at no cost with limited AI interactions. Premium Family subscriptions
            renew until cancelled and may include a free trial. You can change or cancel your plan at any time from the
            parent dashboard.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Educational guidance, not professional advice</h2>
          <p>
            Ayara supports learning and creativity. It does not provide medical, legal, psychological, or emergency
            guidance, and it will redirect children to a trusted adult when a sensitive topic arises.
          </p>
        </div>
        <div>
          <h2 className="font-heading text-lg font-bold text-foreground">Changes</h2>
          <p>
            We may update these terms as Ayara grows. We will notify account holders by email before material changes
            take effect.
          </p>
        </div>
      </section>
    </article>
  );
}
