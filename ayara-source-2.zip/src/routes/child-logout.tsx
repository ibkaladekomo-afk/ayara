import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { useChildSession } from "@/lib/child-session-context";

export const Route = createFileRoute("/child-logout")({
  component: ChildLogoutPage,
});

function ChildLogoutPage() {
  const { logout } = useChildSession();
  const navigate = useNavigate();
  const started = useRef(false);

  useEffect(() => {
    if (started.current) return;
    started.current = true;

    void logout().finally(() => navigate({ to: "/child-login", replace: true }));
  }, [logout, navigate]);

  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <p className="text-muted-foreground">Signing out...</p>
    </div>
  );
}
