import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Clock, Sparkles, Gem, ArrowRight, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useChildSession } from "@/lib/child-session-context";
import { getWorld } from "@/lib/worlds";
import { getMissionBoard, abandonMission } from "@/lib/missions.functions";
import { missionKindMeta, type MissionKind } from "@/lib/missions/catalog";

export const Route = createFileRoute("/play/missions")({
  head: () => ({
    meta: [
      { title: "Mission Board — AYARA" },
      { name: "description", content: "Daily missions, world missions, weekly Innovation Challenges, family missions and seasonal events — all on your AYARA mission board." },
      { property: "og:title", content: "Mission Board — AYARA" },
      { property: "og:description", content: "Every AYARA mission you can pick up right now." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MissionBoard,
});

interface MissionRow {
  id: string;
  world_id: string;
  title: string;
  kind: string;
  status: string;
  estimated_minutes: number;
  xp_reward: number;
  crystal_reward: number | null;
  progress_step: number;
  total_steps: number;
  family_role: string | null;
  child_confirmed_at: string | null;
}

function MissionCard({
  mission,
  onOpen,
  onDrop,
}: {
  mission: MissionRow;
  onOpen: () => void;
  onDrop: () => void;
}) {
  const world = getWorld(mission.world_id);
  const percent = mission.total_steps > 0 ? Math.round((mission.progress_step / mission.total_steps) * 100) : 0;
  const done = mission.status === "completed";
  const awaiting = mission.kind === "family" && !done && Boolean(mission.child_confirmed_at);

  return (
    <article className="rounded-3xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span className="text-xl" aria-hidden>
          {world?.emoji ?? "✨"}
        </span>
        <span className="font-semibold text-foreground">{world?.name ?? "AYARA"}</span>
        <span className="ml-auto inline-flex items-center gap-1">
          <Clock className="h-4 w-4" aria-hidden /> {mission.estimated_minutes} min
        </span>
      </div>

      <h3 className="mt-2 font-display text-lg leading-tight text-foreground">{mission.title}</h3>

      {mission.family_role ? (
        <p className="mt-1 text-sm text-muted-foreground">👨‍👩‍👧 {mission.family_role}</p>
      ) : null}

      <div className="mt-3 flex flex-wrap items-center gap-2 text-xs font-semibold">
        <span className="rounded-full bg-primary/10 px-3 py-1 text-primary">+{mission.xp_reward} XP</span>
        {mission.crystal_reward ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-secondary/20 px-3 py-1 text-secondary-foreground">
            <Gem className="h-3.5 w-3.5" aria-hidden /> {mission.crystal_reward}
          </span>
        ) : null}
        {done ? <span className="rounded-full bg-accent/20 px-3 py-1 text-foreground">Complete</span> : null}
        {awaiting ? (
          <span className="rounded-full bg-muted px-3 py-1 text-muted-foreground">Waiting for a grown-up</span>
        ) : null}
      </div>

      {mission.progress_step > 0 && !done ? (
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${percent}%` }} />
        </div>
      ) : null}

      {!done ? (
        <div className="mt-4 flex flex-wrap gap-2">
          <Button onClick={onOpen} className="min-h-11">
            {mission.progress_step > 0 ? "Keep going" : "Start mission"}
            <ArrowRight className="ml-1 h-4 w-4" aria-hidden />
          </Button>
          <Button variant="ghost" className="min-h-11" onClick={onDrop}>
            Not today
          </Button>
        </div>
      ) : null}
    </article>
  );
}

function Section({ kind, missions, children }: { kind: MissionKind; missions: MissionRow[]; children: React.ReactNode }) {
  const meta = missionKindMeta(kind);
  if (missions.length === 0) return null;
  return (
    <section className="mt-6">
      <h2 className="font-display text-sm uppercase tracking-wide text-muted-foreground">
        <span aria-hidden>{meta.emoji}</span> {meta.label}
      </h2>
      <p className="mb-3 text-sm text-muted-foreground">{meta.blurb}</p>
      <div className="grid gap-3 sm:grid-cols-2">{children}</div>
    </section>
  );
}

function MissionBoard() {
  const { child, isLoading } = useChildSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const fetchBoard = useServerFn(getMissionBoard);
  const dropMission = useServerFn(abandonMission);

  const board = useQuery({
    queryKey: ["mission-board", child?.id],
    enabled: Boolean(child),
    queryFn: () => fetchBoard({ data: { tz_offset_minutes: new Date().getTimezoneOffset() } }),
  });

  const drop = useMutation({
    mutationFn: (missionId: string) => dropMission({ data: { mission_id: missionId } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["mission-board", child?.id] }),
  });

  const open = (mission: MissionRow) =>
    navigate({ to: "/play/$worldId", params: { worldId: mission.world_id }, search: { mission: mission.id } as never });

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" aria-label="Loading" />
      </div>
    );
  }

  if (!child) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="font-display text-2xl text-foreground">Child login required</h1>
        <Button asChild className="mt-6">
          <Link to="/child-login">Go to child login</Link>
        </Button>
      </div>
    );
  }

  const data = board.data;
  const render = (mission: MissionRow) => (
    <MissionCard key={mission.id} mission={mission} onOpen={() => open(mission)} onDrop={() => drop.mutate(mission.id)} />
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 pb-16">
      <header className="rounded-3xl bg-foreground px-5 py-5 text-background">
        <h1 className="font-display text-2xl">Mission Board</h1>
        <p className="mt-1 text-sm text-background/85">
          Everything you can build right now. Pick what excites you most.
        </p>
        {data ? (
          <div className="mt-3 flex flex-wrap gap-2 text-xs font-semibold">
            <span className="inline-flex items-center gap-1 rounded-full bg-background/15 px-3 py-1">
              <Gem className="h-3.5 w-3.5" aria-hidden /> {data.wallet.crystals} crystals
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-background/15 px-3 py-1">
              <Coins className="h-3.5 w-3.5" aria-hidden /> {data.wallet.coins} coins
            </span>
            <span className="inline-flex items-center gap-1 rounded-full bg-background/15 px-3 py-1">
              <Sparkles className="h-3.5 w-3.5" aria-hidden /> {data.difficulty === "stretch" ? "Stretch level" : data.difficulty === "gentle" ? "Warm-up level" : "Just-right level"}
            </span>
          </div>
        ) : null}
      </header>

      {board.isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-primary" aria-label="Loading missions" />
        </div>
      ) : null}

      {board.error ? (
        <p className="mt-6 rounded-2xl bg-destructive/10 px-4 py-3 text-center text-sm text-destructive">
          We couldn't load your missions. Try again in a moment.
        </p>
      ) : null}

      {data ? (
        <>
          {data.recovery ? (
            <Section kind="recovery" missions={[data.recovery as MissionRow]}>
              {render(data.recovery as MissionRow)}
            </Section>
          ) : null}

          <Section kind="daily" missions={[data.daily as MissionRow]}>
            {render(data.daily as MissionRow)}
          </Section>

          <Section kind="weekly" missions={[data.weekly as MissionRow]}>
            {render(data.weekly as MissionRow)}
          </Section>

          <Section kind="world" missions={(data.world ?? []) as MissionRow[]}>
            {((data.world ?? []) as MissionRow[]).map(render)}
          </Section>

          <Section kind="family" missions={(data.family ?? []) as MissionRow[]}>
            {((data.family ?? []) as MissionRow[]).map(render)}
          </Section>

          <Section kind="seasonal" missions={(data.seasonal ?? []) as MissionRow[]}>
            {((data.seasonal ?? []) as MissionRow[]).map(render)}
          </Section>

          <p className="mt-8 text-center text-sm text-muted-foreground">
            <Link to="/play" className="font-semibold text-primary underline-offset-4 hover:underline">
              Back to your Innovation Hub
            </Link>
          </p>
        </>
      ) : null}
    </div>
  );
}
