import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listChildProfiles } from "@/lib/child-profiles.functions";
import { listConversations } from "@/lib/conversations.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AddChildDialog } from "@/components/add-child-dialog";
import { ChildAvatar, TierBadge } from "@/components/child-avatar";
import { SafetyAlertsCard } from "@/components/safety-alerts-card";
import { LearningSummaryCard } from "@/components/learning-summary-card";
import { MissionsGrowthCard } from "@/components/missions-growth-card";

import { DeleteChildButton } from "@/components/delete-child-button";
import { ResetChildPinDialog } from "@/components/reset-child-pin-dialog";

import { getAgeTier, gradeLabel } from "@/lib/age-tiers";
import { Activity, MessageSquare, Shield, Sparkles, UserPlus } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Family dashboard — AYARA" },
      {
        name: "description",
        content: "Manage child profiles, safety settings and learning progress in your AYARA family dashboard.",
      },
      { property: "og:title", content: "Family dashboard — AYARA" },
      {
        property: "og:description",
        content: "Manage child profiles, safety settings and learning progress in your AYARA family dashboard.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const fetchChildren = useServerFn(listChildProfiles);
  const fetchConversations = useServerFn(listConversations);

  const { data: children = [] } = useQuery({
    queryKey: ["childProfiles"],
    queryFn: fetchChildren,
  });

  const { data: conversations = [] } = useQuery({
    queryKey: ["conversations"],
    queryFn: fetchConversations,
  });

  const recent = conversations.slice(0, 6);
  const childNames = Object.fromEntries(children.map((c) => [c.id, c.name]));

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl tracking-tight text-foreground">Family dashboard</h1>
          <p className="mt-1 text-muted-foreground">
            Each child gets an experience matched to their grade — characters, tone and activities included.
          </p>
        </div>
        <Link to="/child-login">
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Sparkles className="mr-2 h-4 w-4" />
            Open kid login
          </Button>
        </Link>
      </div>

      <div className="mb-6 space-y-6">
        <MissionsGrowthCard />
        <SafetyAlertsCard childNames={childNames} />
      </div>


      <LearningSummaryCard children={children.map((c) => ({ id: c.id, name: c.name }))} />




      <Card className="mb-6">
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle className="text-lg">Children</CardTitle>
          <AddChildDialog />
        </CardHeader>
        <CardContent>
          {children.length === 0 ? (
            <div className="rounded-xl border border-dashed border-border p-6 text-center">
              <UserPlus className="mx-auto h-6 w-6 text-muted-foreground" />
              <p className="mt-2 font-medium text-foreground">No child profiles yet</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Add your first child to unlock their learning worlds.
              </p>
            </div>
          ) : (
            <ul className="grid gap-3 sm:grid-cols-2">
              {children.map((child) => {
                const tier = getAgeTier({ age: child.age, grade: child.grade });
                return (
                  <li
                    key={child.id}
                    className="rounded-2xl border border-border/60 bg-muted/25 p-4"
                  >
                    <div className="flex items-start gap-3">
                      <ChildAvatar avatar={child.avatar} size="lg" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold text-foreground">{child.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Age {child.age}
                          {gradeLabel(child.grade) ? ` • ${gradeLabel(child.grade)}` : ""}
                        </p>
                        <div className="mt-2">
                          <TierBadge tier={tier} />
                        </div>
                      </div>
                      <DeleteChildButton childId={child.id} childName={child.name} />

                    </div>
                    <p className="mt-3 text-sm text-muted-foreground">{tier.description}</p>
                    <div className="mt-3 flex items-center justify-between rounded-lg bg-background/70 px-3 py-2 text-sm">
                      <span className="text-muted-foreground">Kid login</span>
                      <span className="font-mono font-medium text-foreground">{child.username ?? "—"}</span>
                    </div>
                    <div className="mt-3 flex justify-end">
                      <ResetChildPinDialog childId={child.id} childName={child.name} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <MessageSquare className="h-5 w-5 text-primary" />
              Recent activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recent.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Nothing yet. Activity appears here once your child starts a mission.
              </p>
            ) : (
              <ul className="space-y-3">
                {recent.map((conversation) => (
                  <li key={conversation.id} className="rounded-xl border border-border/50 bg-muted/25 p-3">
                    <p className="font-medium text-foreground">{conversation.title ?? "Learning session"}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(conversation.updated_at).toLocaleDateString()}
                    </p>
                  </li>
                ))}
              </ul>
            )}
            {conversations.length > recent.length && (
              <p className="mt-3 text-xs text-muted-foreground">
                Showing the {recent.length} most recent of {conversations.length} sessions.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Shield className="h-5 w-5 text-primary" />
                Safety centre
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>
                Every AI reply is age-filtered and moderated. Sensitive topics are redirected back to you.
              </p>
              <Link to="/safety" className="inline-block font-medium text-primary hover:underline">
                Read how AYARA keeps children safe
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Activity className="h-5 w-5 text-primary" />
                This week
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <div className="flex items-baseline gap-6">
                <div>
                  <p className="font-display text-2xl text-foreground">{children.length}</p>
                  <p>Child profiles</p>
                </div>
                <div>
                  <p className="font-display text-2xl text-foreground">{conversations.length}</p>
                  <p>Learning sessions</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
