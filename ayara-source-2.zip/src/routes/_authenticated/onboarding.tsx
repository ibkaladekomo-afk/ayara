import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Aya, AyaLoading } from "@/components/aya";
import { AvatarPicker } from "@/components/child-avatar";
import { DEFAULT_CHILD_AVATAR } from "@/lib/child-avatars";
import { useI18n } from "@/lib/i18n";
import {
  getOnboardingState,
  saveFamily,
  saveParentDetails,
  saveSafetySettings,
  setOnboardingStep,
  trackOnboardingEvent,
  type OnboardingStep,
} from "@/lib/onboarding.functions";
import { createChildProfile } from "@/lib/child-profiles.functions";
import { Check, Loader2, Sparkles } from "lucide-react";

export const Route = createFileRoute("/_authenticated/onboarding")({
  component: OnboardingPage,
});

const GOALS = [
  "Creativity",
  "STEM",
  "Reading",
  "Writing",
  "Coding",
  "AI Foundations",
  "Problem Solving",
  "General Learning",
];

const SESSION_LENGTHS = [
  { value: "10", label: "10 min" },
  { value: "20", label: "20 min" },
  { value: "30", label: "30 min" },
  { value: "45", label: "45 min" },
  { value: "no_preference", label: "No preference" },
] as const;

const LEARNING_DAYS = [
  { value: "weekdays", label: "Weekdays" },
  { value: "weekends", label: "Weekends" },
  { value: "daily", label: "Daily" },
  { value: "custom", label: "Custom" },
] as const;

const STEP_ORDER: OnboardingStep[] = ["account", "family", "plan", "prefs", "safety", "child"];

function StepHeader({ step, title, subtitle }: { step: OnboardingStep; title: string; subtitle?: string }) {
  const index = STEP_ORDER.indexOf(step);
  return (
    <div className="mb-6">
      <div className="flex gap-1.5" aria-label={`Step ${index + 1} of ${STEP_ORDER.length}`}>
        {STEP_ORDER.map((s, i) => (
          <span key={s} className={`h-1.5 flex-1 rounded-full ${i <= index ? "bg-primary" : "bg-border"}`} />
        ))}
      </div>
      <h1 className="mt-5 font-display text-2xl font-bold text-foreground md:text-3xl">{title}</h1>
      {subtitle && <p className="mt-2 text-sm text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

function OnboardingPage() {
  const navigate = useNavigate();
  const { t, lang } = useI18n();

  const [step, setStep] = useState<OnboardingStep | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const startedAt = useRef(Date.now());

  // account
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [country, setCountry] = useState("United States");

  // family
  const [familyName, setFamilyName] = useState("");
  const [childrenCount, setChildrenCount] = useState(1);
  const [timezone, setTimezone] = useState("UTC");
  const [notify, setNotify] = useState({
    notify_weekly_reports: true,
    notify_learning_reminders: true,
    notify_achievements: true,
    notify_product_updates: false,
  });

  // preferences
  const [goals, setGoals] = useState<string[]>(["AI Foundations", "Creativity"]);
  const [sessionLength, setSessionLength] = useState<(typeof SESSION_LENGTHS)[number]["value"]>("20");
  const [learningDays, setLearningDays] = useState<(typeof LEARNING_DAYS)[number]["value"]>("daily");

  // safety
  const [safety, setSafety] = useState({
    daily_minutes: 30,
    allowed_start_hour: 7,
    allowed_end_hour: 20,
    voice_chat_enabled: true,
    microphone_enabled: true,
    portfolio_sharing_enabled: false,
    notifications_enabled: true,
    conversation_history_enabled: true,
    report_download_enabled: true,
  });

  // child
  const [childName, setChildName] = useState("");
  const [childGrade, setChildGrade] = useState("3");
  const [childAge, setChildAge] = useState("8");
  const [childLang, setChildLang] = useState<"en" | "es">(lang);
  const [interests, setInterests] = useState("");
  const [avatar, setAvatar] = useState(DEFAULT_CHILD_AVATAR);
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");

  useEffect(() => {
    let cancelled = false;
    getOnboardingState()
      .then((state) => {
        if (cancelled) return;
        const profile = state.profile;
        if (profile?.first_name) setFirstName(profile.first_name);
        if (profile?.last_name) setLastName(profile.last_name);
        if (profile?.country) setCountry(profile.country);
        if (state.family) {
          setFamilyName(state.family.name ?? "");
          setChildrenCount(state.family.children_count);
          setTimezone(state.family.timezone);
          setNotify({
            notify_weekly_reports: state.family.notify_weekly_reports,
            notify_learning_reminders: state.family.notify_learning_reminders,
            notify_achievements: state.family.notify_achievements,
            notify_product_updates: state.family.notify_product_updates,
          });
          if (state.family.learning_goals.length) setGoals(state.family.learning_goals);
        }
        if (state.safety) setSafety({ ...safety, ...state.safety });

        if (profile?.onboarding_completed_at || state.childCount > 0) {
          void navigate({ to: "/dashboard", replace: true });
          return;
        }

        const saved = (profile?.onboarding_step as OnboardingStep | undefined) ?? "account";
        setStep(profile?.first_name && saved === "account" ? "family" : saved);
        void trackOnboardingEvent({ data: { event: "parent_onboarding_resumed", metadata: { step: saved } } });
      })
      .catch(() => {
        if (!cancelled) {
          setStep("account");
          setError(t("err.generic"));
        }
      });

    try {
      setTimezone(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
    } catch {
      /* keep UTC */
    }

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function advance(next: OnboardingStep, work: () => Promise<void>, event: string) {
    setError(null);
    setPending(true);
    try {
      await work();
      await setOnboardingStep({ data: { step: next } });
      void trackOnboardingEvent({ data: { event, metadata: {} } });
      setStep(next);
      window.scrollTo({ top: 0 });
    } catch (err) {
      setError(err instanceof Error ? err.message : t("err.generic"));
    } finally {
      setPending(false);
    }
  }

  if (!step) return <AyaLoading message={t("loading.1")} />;

  return (
    <div className="mx-auto w-full max-w-lg px-4 py-8">
      {step === "account" && (
        <>
          <StepHeader step="account" title="Let's start with you" subtitle="You'll always stay in control of your family's account." />
          <form
            className="grid gap-4"
            onSubmit={(e) => {
              e.preventDefault();
              void advance(
                "family",
                async () => {
                  await saveParentDetails({
                    data: {
                      first_name: firstName.trim(),
                      last_name: lastName.trim(),
                      country,
                      language: lang,
                      marketing_opt_in: false,
                    },
                  });
                },
                "account_completed",
              );
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="fn">First name</Label>
                <Input id="fn" required minLength={2} maxLength={40} value={firstName} onChange={(e) => setFirstName(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="ln">Last name</Label>
                <Input id="ln" required minLength={2} maxLength={40} value={lastName} onChange={(e) => setLastName(e.target.value)} />
              </div>
            </div>
            <div>
              <Label htmlFor="ct">Country</Label>
              <Input id="ct" value={country} onChange={(e) => setCountry(e.target.value)} />
            </div>
            <SubmitRow pending={pending} label={t("common.continue")} />
          </form>
        </>
      )}

      {step === "family" && (
        <>
          <StepHeader step="family" title={t("ob.family.title")} subtitle="This helps Ayara schedule learning and send the right updates." />
          <form
            className="grid gap-5"
            onSubmit={(e) => {
              e.preventDefault();
              void advance(
                "plan",
                async () => {
                  await saveFamily({
                    data: {
                      name: familyName.trim() || null,
                      country,
                      timezone,
                      language: lang,
                      children_count: childrenCount,
                      ...notify,
                    },
                  });
                },
                "family_created",
              );
            }}
          >
            <div>
              <Label htmlFor="famname">Family name (optional)</Label>
              <Input id="famname" value={familyName} maxLength={60} onChange={(e) => setFamilyName(e.target.value)} placeholder="The Rivera Family" />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="kids">Number of children</Label>
                <select id="kids" value={childrenCount} onChange={(e) => setChildrenCount(Number(e.target.value))} className="mt-1 h-11 w-full rounded-md border border-input bg-background px-3 text-sm">
                  {Array.from({ length: 10 }, (_, i) => i + 1).map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="tz">Time zone</Label>
                <Input id="tz" value={timezone} onChange={(e) => setTimezone(e.target.value)} />
              </div>
            </div>

            <fieldset className="rounded-xl border border-border bg-card p-4">
              <legend className="px-1 text-sm font-semibold">Notifications</legend>
              {([
                ["notify_weekly_reports", "Weekly reports"],
                ["notify_learning_reminders", "Learning reminders"],
                ["notify_achievements", "Achievement alerts"],
                ["notify_product_updates", "Product updates"],
              ] as const).map(([key, label]) => (
                <label key={key} className="flex items-center justify-between gap-3 py-2 text-sm">
                  <span>{label}</span>
                  <Switch checked={notify[key]} onCheckedChange={(v) => setNotify((n) => ({ ...n, [key]: v }))} aria-label={label} />
                </label>
              ))}
            </fieldset>

            <SubmitRow pending={pending} label={t("common.continue")} />
          </form>
        </>
      )}

      {step === "plan" && (
        <>
          <StepHeader step="plan" title={t("ob.plan.title")} subtitle="You can change or cancel at any time." />
          <div className="grid gap-4">
            <PlanCard
              title="Free Explorer"
              price="Free forever"
              features={["Limited AI interactions", "Introductory Learning Worlds", "One child profile", "Basic parent dashboard"]}
              cta="Continue free"
              pending={pending}
              onSelect={() =>
                void advance("prefs", async () => {
                  await saveFamily({ data: { plan: "free", plan_interval: null } });
                }, "subscription_skipped")
              }
            />
            <PlanCard
              highlight
              title="Premium Family"
              price="Best value — annual"
              features={[
                "Unlimited AI learning",
                "Full curriculum & all Learning Worlds",
                "Multiple child profiles",
                "Voice conversations",
                "Certificates & advanced reports",
              ]}
              cta="Start free trial"
              pending={pending}
              onSelect={() =>
                void advance("prefs", async () => {
                  await saveFamily({
                    data: { plan: "premium", plan_interval: "annual", trial_started_at: new Date().toISOString() },
                  });
                }, "subscription_started")
              }
            />
            <p className="text-center text-xs text-muted-foreground">
              Payment is collected later — your trial choice is saved with your family account.
            </p>
          </div>
        </>
      )}

      {step === "prefs" && (
        <>
          <StepHeader step="prefs" title={t("ob.prefs.title")} subtitle="Pick as many learning goals as you like." />
          <form
            className="grid gap-5"
            onSubmit={(e) => {
              e.preventDefault();
              void advance("safety", async () => {
                await saveFamily({
                  data: { learning_goals: goals, session_length: sessionLength, learning_days: learningDays },
                });
              }, "preferences_saved");
            }}
          >
            <fieldset>
              <legend className="mb-2 text-sm font-semibold">Learning goals</legend>
              <div className="grid grid-cols-2 gap-2">
                {GOALS.map((goal) => {
                  const active = goals.includes(goal);
                  return (
                    <button
                      key={goal}
                      type="button"
                      aria-pressed={active}
                      onClick={() => setGoals((g) => (active ? g.filter((x) => x !== goal) : [...g, goal]))}
                      className={`rounded-xl border px-3 py-3 text-left text-sm font-semibold transition-colors ${
                        active ? "border-primary bg-primary/10 text-foreground" : "border-border bg-card text-muted-foreground"
                      }`}
                    >
                      {active && <Check className="mr-1 inline h-4 w-4 text-primary" aria-hidden />}
                      {goal}
                    </button>
                  );
                })}
              </div>
            </fieldset>

            <fieldset>
              <legend className="mb-2 text-sm font-semibold">Preferred session length</legend>
              <div className="flex flex-wrap gap-2">
                {SESSION_LENGTHS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    aria-pressed={sessionLength === opt.value}
                    onClick={() => setSessionLength(opt.value)}
                    className={`rounded-full border px-4 py-2 text-sm font-semibold ${
                      sessionLength === opt.value ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend className="mb-2 text-sm font-semibold">Learning days</legend>
              <div className="flex flex-wrap gap-2">
                {LEARNING_DAYS.map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    aria-pressed={learningDays === opt.value}
                    onClick={() => setLearningDays(opt.value)}
                    className={`rounded-full border px-4 py-2 text-sm font-semibold ${
                      learningDays === opt.value ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </fieldset>

            <SubmitRow pending={pending} label={t("common.continue")} />
          </form>
        </>
      )}

      {step === "safety" && (
        <>
          <StepHeader step="safety" title={t("ob.safety.title")} subtitle="These are our recommended settings — accept them or adjust anything." />
          <form
            className="grid gap-5"
            onSubmit={(e) => {
              e.preventDefault();
              void advance("child", async () => {
                await saveSafetySettings({ data: safety });
              }, "safety_settings_completed");
            }}
          >
            <div className="grid gap-4 rounded-xl border border-border bg-card p-4">
              <div>
                <Label htmlFor="mins">Daily screen-time limit: {safety.daily_minutes} minutes</Label>
                <input
                  id="mins"
                  type="range"
                  min={10}
                  max={120}
                  step={5}
                  value={safety.daily_minutes}
                  onChange={(e) => setSafety((s) => ({ ...s, daily_minutes: Number(e.target.value) }))}
                  className="mt-2 w-full"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="from">Allowed from</Label>
                  <Input id="from" type="number" min={0} max={23} value={safety.allowed_start_hour} onChange={(e) => setSafety((s) => ({ ...s, allowed_start_hour: Number(e.target.value) }))} />
                </div>
                <div>
                  <Label htmlFor="to">Allowed until</Label>
                  <Input id="to" type="number" min={1} max={24} value={safety.allowed_end_hour} onChange={(e) => setSafety((s) => ({ ...s, allowed_end_hour: Number(e.target.value) }))} />
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-border bg-card p-4">
              {([
                ["voice_chat_enabled", "Voice conversations"],
                ["microphone_enabled", "Microphone access"],
                ["portfolio_sharing_enabled", "Portfolio sharing"],
                ["notifications_enabled", "Notifications"],
                ["conversation_history_enabled", "Save AI conversation history"],
                ["report_download_enabled", "Allow learning report downloads"],
              ] as const).map(([key, label]) => (
                <label key={key} className="flex items-center justify-between gap-3 py-2 text-sm">
                  <span>{label}</span>
                  <Switch checked={safety[key]} onCheckedChange={(v) => setSafety((s) => ({ ...s, [key]: v }))} aria-label={label} />
                </label>
              ))}
            </div>

            <SubmitRow pending={pending} label="Save safety settings" />
          </form>
        </>
      )}

      {step === "child" && (
        <>
          <div className="mb-4 flex flex-col items-center text-center">
            <Aya size="md" mood="celebrate" />
            <h1 className="mt-3 font-display text-2xl font-bold text-foreground md:text-3xl">{t("ob.done.title")}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{t("ob.done.body")}</p>
          </div>

          <form
            className="grid gap-5"
            onSubmit={(e) => {
              e.preventDefault();
              void advance("done", async () => {
                await createChildProfile({
                  data: {
                    name: childName.trim(),
                    username: username.trim().toLowerCase(),
                    pin,
                    age: Number(childAge),
                    grade: `Grade ${childGrade}`,
                    language: childLang,
                    avatar,
                    interests: interests.split(",").map((s) => s.trim()).filter(Boolean),
                  },
                });
                void trackOnboardingEvent({
                  data: {
                    event: "parent_onboarding_completed",
                    metadata: { seconds: Math.round((Date.now() - startedAt.current) / 1000) },
                  },
                });
              }, "child_profile_created").then(() => {
                void navigate({ to: "/dashboard" });
              });
            }}
          >
            <div>
              <Label htmlFor="cn">Child's first name</Label>
              <Input id="cn" required maxLength={50} value={childName} onChange={(e) => setChildName(e.target.value)} />
            </div>

            <div>
              <Label>Choose a character</Label>
              <div className="mt-2">
                <AvatarPicker value={avatar} onChange={setAvatar} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="gr">Grade</Label>
                <select id="gr" value={childGrade} onChange={(e) => setChildGrade(e.target.value)} className="mt-1 h-11 w-full rounded-md border border-input bg-background px-3 text-sm">
                  {["2", "3", "4", "5", "6", "7", "8"].map((g) => (
                    <option key={g} value={g}>
                      Grade {g}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="ag">Age</Label>
                <Input id="ag" type="number" min={6} max={15} value={childAge} onChange={(e) => setChildAge(e.target.value)} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cl">Language</Label>
                <select id="cl" value={childLang} onChange={(e) => setChildLang(e.target.value as "en" | "es")} className="mt-1 h-11 w-full rounded-md border border-input bg-background px-3 text-sm">
                  <option value="en">English</option>
                  <option value="es">Español</option>
                </select>
              </div>
              <div>
                <Label htmlFor="in">Interests</Label>
                <Input id="in" value={interests} onChange={(e) => setInterests(e.target.value)} placeholder="space, dinosaurs" />
              </div>
            </div>

            <div className="grid gap-4 rounded-xl border border-border bg-card p-4">
              <p className="text-sm font-semibold">Your child's own login</p>
              <div>
                <Label htmlFor="un">Username</Label>
                <Input id="un" required minLength={3} maxLength={50} pattern="[a-zA-Z0-9_.\-]+" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="maya.explores" />
              </div>
              <div>
                <Label htmlFor="pin">PIN (4–6 digits)</Label>
                <Input id="pin" required inputMode="numeric" pattern="\d{4,6}" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))} />
              </div>
            </div>

            <SubmitRow pending={pending} label={t("ob.done.cta")} />
          </form>
        </>
      )}

      {error && (
        <p role="alert" className="mt-4 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}

function SubmitRow({ pending, label }: { pending: boolean; label: string }) {
  return (
    <Button type="submit" size="lg" className="h-14 rounded-2xl text-base font-bold" disabled={pending}>
      {pending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
      {label}
    </Button>
  );
}

function PlanCard({
  title,
  price,
  features,
  cta,
  onSelect,
  pending,
  highlight,
}: {
  title: string;
  price: string;
  features: string[];
  cta: string;
  onSelect: () => void;
  pending: boolean;
  highlight?: boolean;
}) {
  return (
    <div className={`rounded-2xl border p-5 ${highlight ? "border-primary bg-primary/5" : "border-border bg-card"}`}>
      {highlight && (
        <span className="inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
          <Sparkles className="h-3 w-3" aria-hidden /> Best value
        </span>
      )}
      <h2 className="mt-2 font-heading text-lg font-bold text-foreground">{title}</h2>
      <p className="text-sm text-muted-foreground">{price}</p>
      <ul className="mt-3 grid gap-1.5 text-sm text-muted-foreground">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
            {f}
          </li>
        ))}
      </ul>
      <Button className="mt-4 h-12 w-full rounded-xl font-bold" variant={highlight ? "default" : "outline"} onClick={onSelect} disabled={pending}>
        {cta}
      </Button>
    </div>
  );
}
