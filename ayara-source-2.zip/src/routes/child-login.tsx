import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useChildSession } from "@/lib/child-session-context";
import { Loader2, Sparkles } from "lucide-react";

export const Route = createFileRoute("/child-login")({
  head: () => ({
    meta: [
      { title: "Child login — AYARA" },
      { name: "description", content: "Kids log in to AYARA with their own username and PIN." },
      { property: "og:title", content: "Child login — AYARA" },
      { property: "og:description", content: "Kids log in to AYARA with their own username and PIN." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChildLoginPage,
});

function ChildLoginPage() {
  const { child, login, isLoading } = useChildSession();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  if (!isLoading && child) {
    navigate({ to: "/play", replace: true });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setPending(true);
    try {
      await login(username.trim().toLowerCase(), pin.trim());
      navigate({ to: "/play", replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not log in. Please try again.");
    } finally {
      setPending(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-4 py-12">
      <div className="w-full rounded-2xl border border-border/50 bg-card p-6 shadow-sm md:p-8">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-4xl text-primary-foreground">
            <Sparkles className="h-8 w-8" />
          </div>
          <h1 className="mt-4 font-display text-2xl text-foreground">Kids' login</h1>
          <p className="mt-2 text-sm text-muted-foreground">Enter your AYARA username and PIN.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="your-username"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              autoComplete="off"
              required
            />
          </div>
          <div>
            <Label htmlFor="pin">PIN</Label>
            <Input
              id="pin"
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="••••••"
              autoComplete="off"
              required
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={pending}>
            {pending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Start learning
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-muted-foreground">
          Are you a parent?{" "}
          <Link to="/auth" search={{ mode: "signin" }} className="text-primary hover:underline">
            Sign in here
          </Link>
        </p>
      </div>
    </div>
  );
}
