/**
 * Aya's memory.
 *
 * A compact, learning-only brief about the child that is injected into the
 * mentor system prompt so Aya can refer back to what they've built, where they
 * are in a world and how they're doing. No personal identifiers beyond the
 * first name ever go in here.
 */
import { getWorld } from "@/lib/worlds";
import type { ChildSessionContext } from "@/lib/child-session.server";

export interface AyaMemory {
  brief: string;
  interests: string[];
  level: number;
  streakDays: number;
  projects: string[];
  creations: string[];
}

export async function buildAyaMemory(ctx: ChildSessionContext, worldId?: string | null): Promise<AyaMemory> {
  const { supabaseAdmin, childId, child } = ctx;

  const [progressRes, worldRes, portfolioRes, creationsRes, badgesRes] = await Promise.all([
    supabaseAdmin.from("child_progress").select("xp, level, streak_days").eq("child_id", childId).maybeSingle(),
    worldId
      ? supabaseAdmin
          .from("child_world_progress")
          .select("world_id, stage_index, completed_stages, master_project_status")
          .eq("child_id", childId)
          .eq("world_id", worldId)
          .maybeSingle()
      : Promise.resolve({ data: null }),
    supabaseAdmin
      .from("portfolio_items")
      .select("title, kind, created_at")
      .eq("child_id", childId)
      .order("created_at", { ascending: false })
      .limit(3),
    supabaseAdmin
      .from("child_creations")
      .select("name, kind, origin_world")
      .eq("child_id", childId)
      .order("created_at", { ascending: false })
      .limit(3),
    supabaseAdmin.from("child_badges").select("badge_id").eq("child_id", childId),
  ]);

  const progress = progressRes?.data ?? null;
  const worldProgress = worldRes?.data ?? null;
  const projects: string[] = (portfolioRes?.data ?? []).map((p: { title: string }) => p.title);
  const creations: string[] = (creationsRes?.data ?? []).map(
    (c: { name: string; kind: string }) => `${c.name} (${c.kind})`,
  );
  const badgeCount = (badgesRes?.data ?? []).length;
  const interests = child.interests ?? [];

  const lines: string[] = [];
  if (interests.length) lines.push(`- Loves: ${interests.join(", ")}`);
  if (progress) {
    lines.push(`- Level ${progress.level} (${progress.xp} XP), ${progress.streak_days}-day learning streak, ${badgeCount} badges earned`);
  }
  if (worldProgress) {
    const worldName = getWorld(worldProgress.world_id)?.name ?? worldProgress.world_id;
    lines.push(
      `- In ${worldName}: on step ${(worldProgress.stage_index ?? 0) + 1}, master project ${worldProgress.master_project_status ?? "not started"}`,
    );
  }
  if (projects.length) lines.push(`- Recently made: ${projects.join("; ")}`);
  if (creations.length) lines.push(`- Creations in their universe: ${creations.join("; ")}`);

  const brief = lines.length
    ? `WHAT YOU REMEMBER ABOUT ${child.name.toUpperCase()}:\n${lines.join("\n")}\nRefer back to these naturally when it helps — never list them back at the child.`
    : "";

  return {
    brief,
    interests,
    level: progress?.level ?? 1,
    streakDays: progress?.streak_days ?? 0,
    projects,
    creations,
  };
}
