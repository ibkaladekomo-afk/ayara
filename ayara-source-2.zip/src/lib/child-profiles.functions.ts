import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ChildProfileSchema = z.object({
  name: z.string().min(1).max(50),
  username: z.string().min(3).max(50).regex(/^[a-zA-Z0-9_.-]+$/).transform((v) => v.trim().toLowerCase()),
  pin: z.string().transform((v) => v.replace(/\D/g, "")).pipe(z.string().min(4).max(6)),
  age: z.number().int().min(3).max(18),
  grade: z.string().max(30).optional(),
  language: z.enum(["en", "es"]).default("en"),
  interests: z.array(z.string().max(30)).max(10).default([]),
  avatar: z.string().max(30).default("nova"),
});

export const listChildProfiles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("child_profiles")
      .select("id, name, username, age, grade, language, interests, avatar, created_at, updated_at")
      .eq("parent_id", context.userId)
      .order("created_at", { ascending: true });

    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createChildProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ChildProfileSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { hashPin } = await import("@/lib/pin.server");

    const { data: existing } = await supabaseAdmin
      .from("child_profiles")
      .select("id")
      .eq("username", data.username)
      .maybeSingle();

    if (existing) {
      throw new Error("That username is already taken. Please choose another.");
    }

    const insert = {
      name: data.name,
      username: data.username,
      pin_hash: await hashPin(data.pin),
      age: data.age,
      grade: data.grade ?? null,
      language: data.language,
      interests: data.interests,
      avatar: data.avatar,
      parent_id: context.userId,
    };

    const { data: profile, error } = await supabaseAdmin
      .from("child_profiles")
      .insert(insert)
      .select("id, name, username, age, grade, language, interests, avatar, created_at, updated_at")
      .single();

    if (error) throw new Error(error.message);
    return profile;
  });

export const getChildProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: profile, error } = await context.supabase
      .from("child_profiles")
      .select("id, name, username, age, grade, language, interests, avatar, created_at, updated_at")
      .eq("id", data.id)
      .eq("parent_id", context.userId)
      .single();

    if (error) throw new Error(error.message);
    return profile;
  });

export const deleteChildProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: owned, error: ownErr } = await context.supabase
      .from("child_profiles")
      .select("id")
      .eq("id", data.id)
      .eq("parent_id", context.userId)
      .maybeSingle();

    if (ownErr) throw new Error(ownErr.message);
    if (!owned) throw new Error("Child profile not found.");

    const { data: convos } = await supabaseAdmin
      .from("conversations")
      .select("id")
      .eq("child_id", data.id);

    const convoIds = (convos ?? []).map((c) => c.id);
    if (convoIds.length > 0) {
      await supabaseAdmin.from("messages").delete().in("conversation_id", convoIds);
    }

    for (const table of [
      "safety_alerts",
      "conversations",
      "child_badges",
      "child_events",
      "child_onboarding",
      "child_progress",
      "child_world_unlocks",
      "child_sessions",
      "portfolio_items",
    ] as const) {
      const { error } = await supabaseAdmin.from(table).delete().eq("child_id", data.id);
      if (error) throw new Error(error.message);
    }

    const { error } = await supabaseAdmin.from("child_profiles").delete().eq("id", data.id);
    if (error) throw new Error(error.message);

    return { ok: true };
  });
