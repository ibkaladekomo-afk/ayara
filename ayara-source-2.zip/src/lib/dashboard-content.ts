/**
 * Content + pure helpers for the child Innovation Hub (Section 3).
 *
 * Everything here is deterministic and framework-free so it can run on the
 * server (mission assignment) and in the browser (rendering) alike.
 */

import type { AgeTierId } from "./age-tiers";

/* ------------------------------------------------------------------ *
 * Time of day + greetings
 * ------------------------------------------------------------------ */

export type DayPart = "morning" | "afternoon" | "evening";

export function getDayPart(date: Date = new Date()): DayPart {
  const hour = date.getHours();
  if (hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  return "evening";
}

const GREETINGS: Record<AgeTierId, Record<DayPart, string[]>> = {
  spark: {
    morning: [
      "Good morning, {name}! Ready to make something?",
      "Morning, {name} — your ideas are already awake.",
      "Hi {name}! Let's start the day with a spark.",
    ],
    afternoon: [
      "Hey {name}! What are we creating today?",
      "Afternoon, {name} — got a big idea in there?",
      "Hi {name}! Your workshop is ready.",
    ],
    evening: [
      "Evening, {name}. One cozy mission before bed?",
      "Hi {name}! Perfect time for a quiet creation.",
      "Hey {name} — let's end the day with something fun.",
    ],
  },
  forge: {
    morning: [
      "Morning, {name}. Let's build something real.",
      "Good morning, {name} — the studio is open.",
      "{name}, fresh start. What are we shipping today?",
    ],
    afternoon: [
      "Welcome back, {name}. Pick up where you left off.",
      "Afternoon, {name}. Ready for today's build?",
      "{name} — studio time. Let's get into it.",
    ],
    evening: [
      "Evening, {name}. Good time for deep work.",
      "Back for a late session, {name}? Respect.",
      "{name} — quiet hours are the best build hours.",
    ],
  },
};

/** Deterministic per day so the greeting doesn't shuffle on every render. */
export function pickGreeting(tier: AgeTierId, name: string, date: Date = new Date()): string {
  const part = getDayPart(date);
  const pool = GREETINGS[tier][part];
  const index = (date.getFullYear() * 372 + date.getMonth() * 31 + date.getDate()) % pool.length;
  return (pool[index] ?? pool[0]!).replace("{name}", name);
}

/* ------------------------------------------------------------------ *
 * Seasonal accents
 * ------------------------------------------------------------------ */

export interface SeasonAccent {
  id: string;
  label: string;
  emoji: string;
  /** Tailwind gradient classes for the Innovation Hub header wash */
  wash: string;
}

export function getSeasonAccent(date: Date = new Date()): SeasonAccent {
  const month = date.getMonth();
  if (month <= 1 || month === 11) {
    return { id: "winter", label: "Winter", emoji: "❄️", wash: "from-[oklch(0.72_0.15_255)] to-[oklch(0.66_0.17_285)]" };
  }
  if (month <= 4) {
    return { id: "spring", label: "Spring", emoji: "🌱", wash: "from-[oklch(0.78_0.13_150)] to-[oklch(0.72_0.12_195)]" };
  }
  if (month <= 7) {
    return { id: "summer", label: "Summer", emoji: "☀️", wash: "from-[oklch(0.85_0.13_95)] to-[oklch(0.78_0.14_35)]" };
  }
  return { id: "autumn", label: "Autumn", emoji: "🍂", wash: "from-[oklch(0.78_0.14_35)] to-[oklch(0.72_0.15_255)]" };
}

/* ------------------------------------------------------------------ *
 * XP + Innovation Levels
 *
 * XP is only ever awarded for thinking, making, revising and reflecting —
 * never for logging in. See src/lib/missions/rewards.ts for the earn rules.
 * ------------------------------------------------------------------ */

export interface InnovationLevelDef {
  level: number;
  title: string;
  emoji: string;
  /** Total XP required to reach this level */
  threshold: number;
  /** What reaching this level opens up */
  unlocks: string[];
}

export const INNOVATION_LEVELS: InnovationLevelDef[] = [
  { level: 1, title: "Spark", emoji: "✨", threshold: 0, unlocks: ["Daily missions", "Your first two worlds"] },
  { level: 2, title: "Explorer", emoji: "🧭", threshold: 250, unlocks: ["All learning worlds", "Hidden discoveries"] },
  { level: 3, title: "Creator", emoji: "🎨", threshold: 600, unlocks: ["Weekly Innovation Challenges", "Avatar colour packs"] },
  { level: 4, title: "Inventor", emoji: "🛠️", threshold: 1100, unlocks: ["Family missions", "Improve-your-project missions"] },
  { level: 5, title: "Innovator", emoji: "🚀", threshold: 1800, unlocks: ["Mentor deep-dives", "Portfolio themes"] },
  { level: 6, title: "Visionary", emoji: "🔭", threshold: 2800, unlocks: ["Master projects in every world", "Seasonal missions"] },
  { level: 7, title: "Pioneer", emoji: "🌟", threshold: 4200, unlocks: ["Pioneer challenges", "Everything AYARA has to offer"] },
];

/** Legacy export kept for older imports. */
export const LEVEL_TITLES = INNOVATION_LEVELS.map((l) => l.title);
export const XP_PER_LEVEL = 250;

export interface LevelInfo {
  level: number;
  title: string;
  emoji: string;
  unlocks: string[];
  xp: number;
  xpIntoLevel: number;
  xpForLevel: number;
  xpToNext: number;
  percent: number;
  /** Title of the next level, or null at the top of the ladder */
  nextTitle: string | null;
}

/** Beyond Pioneer the ladder keeps counting in even steps. */
const PIONEER_STEP = 1000;

export function getLevelInfo(xp: number): LevelInfo {
  const safeXp = Math.max(0, Math.round(xp));

  let current = INNOVATION_LEVELS[0]!;
  for (const entry of INNOVATION_LEVELS) if (safeXp >= entry.threshold) current = entry;

  const top = INNOVATION_LEVELS[INNOVATION_LEVELS.length - 1]!;
  let level = current.level;
  let start = current.threshold;
  let next = INNOVATION_LEVELS.find((l) => l.threshold > safeXp)?.threshold ?? null;
  let nextTitle = INNOVATION_LEVELS.find((l) => l.threshold > safeXp)?.title ?? null;

  if (next === null) {
    const past = Math.floor((safeXp - top.threshold) / PIONEER_STEP);
    level = top.level + past;
    start = top.threshold + past * PIONEER_STEP;
    next = start + PIONEER_STEP;
    nextTitle = `${top.title} ${past + 2}`;
  }

  const xpForLevel = next - start;
  const xpIntoLevel = safeXp - start;

  return {
    level,
    title: level > top.level ? `${top.title} ${level - top.level + 1}` : current.title,
    emoji: current.emoji,
    unlocks: current.unlocks,
    xp: safeXp,
    xpIntoLevel,
    xpForLevel,
    xpToNext: Math.max(0, xpForLevel - xpIntoLevel),
    percent: Math.min(100, Math.round((xpIntoLevel / xpForLevel) * 100)),
    nextTitle,
  };
}


/* ------------------------------------------------------------------ *
 * Streaks
 * ------------------------------------------------------------------ */

export const STREAK_MILESTONES = [3, 7, 14, 30, 60, 100];

export function nextStreakMilestone(days: number): number {
  return STREAK_MILESTONES.find((m) => m > days) ?? days + 30;
}

export function streakMessage(days: number, tier: AgeTierId): string {
  if (days === 0) return tier === "spark" ? "Start your spark today!" : "Start a new streak today.";
  if (days === 1) return tier === "spark" ? "Day one — nice start!" : "Day 1. Keep it going.";
  const next = nextStreakMilestone(days);
  const left = next - days;
  return tier === "spark"
    ? `${days} days in a row! ${left} more to reach ${next}.`
    : `${days}-day streak. ${left} to the ${next}-day mark.`;
}

/* ------------------------------------------------------------------ *
 * Badges
 * ------------------------------------------------------------------ */

export interface BadgeDef {
  id: string;
  name: string;
  emoji: string;
  description: string;
}

export const BADGES: BadgeDef[] = [
  { id: "first-spark", name: "First Spark", emoji: "✨", description: "Finished your very first mission." },
  { id: "curious-mind", name: "Curious Mind", emoji: "🔎", description: "Asked five great questions." },
  { id: "storyteller", name: "Storyteller", emoji: "📖", description: "Created a story in the Story Tree." },
  { id: "maker", name: "Maker", emoji: "🛠️", description: "Built something in the Code Workshop." },
  { id: "artist", name: "Artist", emoji: "🎨", description: "Made original art in the Art Studio." },
  { id: "scientist", name: "Scientist", emoji: "🔬", description: "Ran an experiment in the Science Lab." },
  { id: "ai-savvy", name: "AI Savvy", emoji: "🚀", description: "Learned how AI thinks — and when it's wrong." },
  { id: "planet-friend", name: "Planet Friend", emoji: "🌍", description: "Explored nature and how to protect it." },
  { id: "streak-3", name: "Three in a Row", emoji: "🔥", description: "Three days of learning in a row." },
  { id: "streak-7", name: "Week of Wonder", emoji: "🌟", description: "Seven days in a row." },
  { id: "level-5", name: "Level Five", emoji: "🏅", description: "Reached level 5." },
  { id: "portfolio-5", name: "Collector", emoji: "🗂️", description: "Five creations in your portfolio." },
  { id: "curious-questioner", name: "Curious Questioner", emoji: "❓", description: "Asked questions that made your mentor think." },
  { id: "creative-builder", name: "Creative Builder", emoji: "🧱", description: "Built something nobody had built before." },
  { id: "science-explorer", name: "Science Explorer", emoji: "🧪", description: "Investigated a real question like a scientist." },
  { id: "story-weaver", name: "Story Weaver", emoji: "🧶", description: "Wove a story with a beginning, a twist and an ending." },
  { id: "coding-starter", name: "Coding Starter", emoji: "💻", description: "Wrote your first working set of instructions." },
  { id: "problem-solver", name: "Problem Solver", emoji: "🧩", description: "Improved a project after finding what was wrong with it." },
  { id: "team-player", name: "Team Player", emoji: "🤝", description: "Finished a family mission together with a grown-up." },
  { id: "kindness-champion", name: "Kindness Champion", emoji: "💛", description: "Designed something that makes life better for other people." },
  { id: "future-inventor", name: "Future Inventor", emoji: "🔮", description: "Completed a Weekly Innovation Challenge from start to finish." },
  { id: "reflector", name: "Deep Thinker", emoji: "🪞", description: "Reflected on what you learned five times." },
  { id: "comeback", name: "Comeback Spark", emoji: "🔁", description: "Came back and restored your streak with a Spark Recovery mission." },
];


export function getBadge(id: string): BadgeDef {
  return (
    BADGES.find((b) => b.id === id) ?? { id, name: id.replace(/-/g, " "), emoji: "🏆", description: "Achievement earned." }
  );
}

/* ------------------------------------------------------------------ *
 * Mission templates
 * ------------------------------------------------------------------ */

export interface MissionTemplate {
  worldId: string;
  title: string;
  prompt: string;
  minutes: number;
  xp: number;
  badge?: string;
  /** Interests this mission speaks to, used for personalisation */
  interests: string[];
  tiers: AgeTierId[];
  steps: string[];
}

export const MISSION_TEMPLATES: MissionTemplate[] = [
  {
    worldId: "science-lab",
    title: "The Mystery of the Bouncing Light",
    prompt: "Help me figure out why light bounces off some things and not others.",
    minutes: 12,
    xp: 75,
    badge: "scientist",
    interests: ["science", "space"],
    tiers: ["spark", "forge"],
    steps: ["Wonder", "Guess", "Try it", "Explain it"],
  },
  {
    worldId: "science-lab",
    title: "Design an Experiment Nobody Has Tried",
    prompt: "I want to design my own experiment. Help me pick a question and a fair test.",
    minutes: 18,
    xp: 110,
    badge: "scientist",
    interests: ["science"],
    tiers: ["forge"],
    steps: ["Question", "Method", "Predict", "Write it up"],
  },
  {
    worldId: "art-studio",
    title: "Invent a Creature Nobody Has Drawn",
    prompt: "Help me invent and draw a creature that has never existed.",
    minutes: 15,
    xp: 80,
    badge: "artist",
    interests: ["art", "animals"],
    tiers: ["spark", "forge"],
    steps: ["Imagine", "Describe", "Draw", "Name it"],
  },
  {
    worldId: "story-tree",
    title: "The Story Where You're the Hero",
    prompt: "Let's write a story where I'm the hero. Start us off.",
    minutes: 12,
    xp: 75,
    badge: "storyteller",
    interests: ["stories", "reading"],
    tiers: ["spark"],
    steps: ["Hero", "Problem", "Twist", "Ending"],
  },
  {
    worldId: "story-tree",
    title: "Build a World, Then Break It",
    prompt: "Help me build a fictional world with real rules, then find its biggest flaw.",
    minutes: 20,
    xp: 120,
    badge: "storyteller",
    interests: ["stories", "writing"],
    tiers: ["forge"],
    steps: ["Setting", "Rules", "Conflict", "Draft"],
  },
  {
    worldId: "code-workshop",
    title: "Teach a Robot to Make a Sandwich",
    prompt: "Give me the robot sandwich challenge — I'll write the exact steps.",
    minutes: 10,
    xp: 70,
    badge: "maker",
    interests: ["coding", "robots", "technology"],
    tiers: ["spark", "forge"],
    steps: ["Plan", "Write steps", "Test", "Fix bugs"],
  },
  {
    worldId: "code-workshop",
    title: "Design Your First Algorithm",
    prompt: "Help me design an algorithm that solves a problem in my real life.",
    minutes: 20,
    xp: 120,
    badge: "maker",
    interests: ["coding", "technology"],
    tiers: ["forge"],
    steps: ["Problem", "Steps", "Edge cases", "Improve"],
  },
  {
    worldId: "ai-explorer",
    title: "Catch the AI Making a Mistake",
    prompt: "Let's test whether you can be wrong — help me try to catch a mistake and check facts.",
    minutes: 12,
    xp: 90,
    badge: "ai-savvy",
    interests: ["technology", "ai"],
    tiers: ["spark", "forge"],
    steps: ["Ask", "Check", "Compare", "Decide"],
  },
  {
    worldId: "nature-trail",
    title: "The Secret Life of Your Street",
    prompt: "Help me investigate the living things right outside my home.",
    minutes: 15,
    xp: 80,
    badge: "planet-friend",
    interests: ["nature", "animals"],
    tiers: ["spark", "forge"],
    steps: ["Look", "Record", "Identify", "Share"],
  },
];

/** Deterministic daily mission pick, nudged by the child's interests. */
export function pickDailyMission(options: {
  tier: AgeTierId;
  interests: string[] | null | undefined;
  seed: string;
  excludeWorldIds?: string[];
}): MissionTemplate {
  const interests = (options.interests ?? []).map((i) => i.toLowerCase());
  const exclude = new Set(options.excludeWorldIds ?? []);

  let pool = MISSION_TEMPLATES.filter((m) => m.tiers.includes(options.tier));
  const fresh = pool.filter((m) => !exclude.has(m.worldId));
  if (fresh.length > 0) pool = fresh;

  const matching = pool.filter((m) => m.interests.some((i) => interests.includes(i)));
  const finalPool = matching.length > 0 ? matching : pool;

  let hash = 0;
  for (const char of options.seed) hash = (hash * 31 + char.charCodeAt(0)) % 100000;
  return finalPool[hash % finalPool.length]!;
}
