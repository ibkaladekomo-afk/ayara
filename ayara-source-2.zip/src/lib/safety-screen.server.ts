/**
 * AYARA child-safety screening.
 *
 * Runs server-side on every message a child sends. When a message touches a
 * sensitive topic we record a safety alert for the parent. The AI itself still
 * redirects the child gently — this layer exists so a parent is never the last
 * to know.
 */

export type SafetySeverity = "notice" | "attention" | "urgent";

export interface SafetyMatch {
  category: string;
  severity: SafetySeverity;
  /** Short, parent-facing explanation of why this was flagged */
  reason: string;
}

interface Rule {
  category: string;
  severity: SafetySeverity;
  reason: string;
  patterns: RegExp[];
}

const RULES: Rule[] = [
  {
    category: "Self-harm or distress",
    severity: "urgent",
    reason: "Your child used words linked to self-harm, hopelessness or wanting to disappear.",
    patterns: [
      /\b(kill|hurt|cut)\s+(myself|my ?self)\b/i,
      /\bsuicid(e|al)\b/i,
      /\b(want|wanna)\s+to\s+(die|disappear)\b/i,
      /\bi\s+hate\s+(myself|my life)\b/i,
      /\bnobody\s+(loves|likes)\s+me\b/i,
      /\bself[\s-]?harm\b/i,
    ],
  },
  {
    category: "Someone is hurting me",
    severity: "urgent",
    reason: "Your child described being hurt, threatened or touched by someone.",
    patterns: [
      /\b(hits?|hitting|beats?|beating|hurts?|hurting)\s+me\b/i,
      /\b(someone|a man|a woman|a stranger|he|she)\s+touch(ed|es)?\s+me\b/i,
      /\bi'?m\s+(scared|afraid)\s+of\s+\w+/i,
      /\b(abuse|abused|molest\w*)\b/i,
      /\bkeep\s+it\s+a\s+secret\s+from\s+(my\s+)?(mom|dad|parents)\b/i,
    ],
  },
  {
    category: "Bullying",
    severity: "attention",
    reason: "Your child mentioned bullying or being left out at school.",
    patterns: [
      /\bbull(y|ies|ied|ying)\b/i,
      /\bmake\s+fun\s+of\s+me\b/i,
      /\bno\s+one\s+(plays|sits)\s+with\s+me\b/i,
      /\bthey\s+(are|were)\s+mean\s+to\s+me\b/i,
    ],
  },
  {
    category: "Personal information shared",
    severity: "attention",
    reason: "Your child typed something that looks like personal contact details.",
    patterns: [
      /\b\d{1,5}\s+\w+\s+(street|st|road|rd|avenue|ave|lane|ln|drive|dr)\b/i,
      /\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/,
      /\b[\w.+-]+@[\w-]+\.[a-z]{2,}\b/i,
      /\bmy\s+(password|address|phone number)\s+is\b/i,
    ],
  },
  {
    category: "Adult or unsafe content",
    severity: "attention",
    reason: "Your child asked about a topic AYARA does not discuss with children.",
    patterns: [
      /\b(sex|sexy|porn\w*|nude|naked)\b/i,
      /\b(gun|knife|bomb|explosive)s?\b.*\b(make|build|get|buy)\b/i,
      /\b(make|build|get|buy)\b.*\b(gun|knife|bomb|explosive)s?\b/i,
      /\b(drugs?|weed|vape|vaping|alcohol|beer|drunk)\b/i,
      /\b(kill|murder|shoot)\s+(him|her|them|someone|people)\b/i,
    ],
  },
  {
    category: "Meeting someone online",
    severity: "urgent",
    reason: "Your child mentioned meeting or being contacted by someone they met online.",
    patterns: [
      /\bmet\s+(a\s+)?(guy|man|woman|person|someone)\s+(online|on the internet|in a game)\b/i,
      /\b(wants?|asked)\s+to\s+meet\s+me\b/i,
      /\bsend\s+(him|her|them)\s+(a\s+)?(photo|picture|pic)\b/i,
    ],
  },
];

/** Returns the most serious match, or null when the message is fine. */
export function screenChildMessage(content: string): SafetyMatch | null {
  const order: SafetySeverity[] = ["urgent", "attention", "notice"];
  let best: SafetyMatch | null = null;

  for (const rule of RULES) {
    if (!rule.patterns.some((p) => p.test(content))) continue;
    const match: SafetyMatch = { category: rule.category, severity: rule.severity, reason: rule.reason };
    if (!best || order.indexOf(match.severity) < order.indexOf(best.severity)) best = match;
  }

  return best;
}

/** Trim what we store so a parent sees context without a full transcript dump. */
export function excerptFor(content: string, max = 240): string {
  const clean = content.replace(/\s+/g, " ").trim();
  return clean.length <= max ? clean : `${clean.slice(0, max - 1)}…`;
}
