/**
 * AYARA layered avatar.
 *
 * Children build a character from a small set of layers instead of uploading a
 * photo. Everything is drawn as SVG so it scales anywhere in the app and never
 * carries personal imagery.
 */

export interface AvatarConfig {
  skin: string;
  hair: string;
  hairColor: string;
  glasses: string;
  outfit: string;
  accessory: string;
}

export interface SwatchOption {
  id: string;
  label: string;
  color: string;
}

export interface ShapeOption {
  id: string;
  label: string;
}

export const SKIN_TONES: SwatchOption[] = [
  { id: "porcelain", label: "Porcelain", color: "#f7d9c4" },
  { id: "sand", label: "Sand", color: "#efc194" },
  { id: "honey", label: "Honey", color: "#dda36a" },
  { id: "amber", label: "Amber", color: "#c67f4b" },
  { id: "sienna", label: "Sienna", color: "#a15f37" },
  { id: "chestnut", label: "Chestnut", color: "#7c4426" },
  { id: "espresso", label: "Espresso", color: "#573018" },
  { id: "cocoa", label: "Cocoa", color: "#3d2113" },
];

export const HAIR_COLORS: SwatchOption[] = [
  { id: "jet", label: "Jet black", color: "#1f1b19" },
  { id: "brown", label: "Brown", color: "#5a3620" },
  { id: "chestnut", label: "Chestnut", color: "#84492a" },
  { id: "auburn", label: "Auburn", color: "#a4471f" },
  { id: "blonde", label: "Blonde", color: "#dfb063" },
  { id: "platinum", label: "Platinum", color: "#e8dfd0" },
  { id: "violet", label: "Violet", color: "#8b5cf6" },
  { id: "teal", label: "Teal", color: "#2bb3ad" },
];

export const HAIR_STYLES: ShapeOption[] = [
  { id: "short", label: "Short" },
  { id: "buzz", label: "Buzz" },
  { id: "curly", label: "Curly" },
  { id: "afro", label: "Afro" },
  { id: "long", label: "Long" },
  { id: "wavy", label: "Wavy" },
  { id: "ponytail", label: "Ponytail" },
  { id: "braids", label: "Braids" },
  { id: "bun", label: "Top bun" },
  { id: "hijab", label: "Hijab" },
];

export const GLASSES_STYLES: ShapeOption[] = [
  { id: "none", label: "No glasses" },
  { id: "round", label: "Round" },
  { id: "square", label: "Square" },
  { id: "sport", label: "Sport" },
];

export const OUTFIT_COLORS: SwatchOption[] = [
  { id: "blue", label: "Blue", color: "#4c7cf5" },
  { id: "violet", label: "Violet", color: "#8b5cf6" },
  { id: "teal", label: "Teal", color: "#2bb3ad" },
  { id: "sun", label: "Sunshine", color: "#f5c243" },
  { id: "coral", label: "Coral", color: "#f2765c" },
  { id: "green", label: "Green", color: "#54b06a" },
  { id: "slate", label: "Slate", color: "#4a5568" },
  { id: "pink", label: "Pink", color: "#ee7ab0" },
];

export const ACCESSORIES: ShapeOption[] = [
  { id: "none", label: "None" },
  { id: "headphones", label: "Headphones" },
  { id: "cap", label: "Cap" },
  { id: "star", label: "Star clip" },
  { id: "flower", label: "Flower" },
];

export const DEFAULT_AVATAR_CONFIG: AvatarConfig = {
  skin: "honey",
  hair: "curly",
  hairColor: "brown",
  glasses: "none",
  outfit: "blue",
  accessory: "none",
};

export function colorOf(options: SwatchOption[], id: string, fallback: string): string {
  return options.find((o) => o.id === id)?.color ?? fallback;
}

/** Accepts whatever is stored in the database and returns a usable config. */
export function normalizeAvatarConfig(value: unknown): AvatarConfig | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Partial<AvatarConfig>;
  if (!raw.skin && !raw.hair && !raw.outfit) return null;
  return { ...DEFAULT_AVATAR_CONFIG, ...raw } as AvatarConfig;
}

/** A pleasant starting point so the first preview never looks empty. */
export function randomAvatarConfig(): AvatarConfig {
  const pick = <T extends { id: string }>(list: T[]) =>
    list[Math.floor(Math.random() * list.length)]!.id;
  return {
    skin: pick(SKIN_TONES),
    hair: pick(HAIR_STYLES),
    hairColor: pick(HAIR_COLORS),
    glasses: "none",
    outfit: pick(OUTFIT_COLORS),
    accessory: "none",
  };
}
