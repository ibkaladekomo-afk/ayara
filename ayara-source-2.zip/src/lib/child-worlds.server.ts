/**
 * Server-only helpers for the Learning Worlds experience.
 *
 * Kept out of the `.functions.ts` wrapper so server-function code splitting
 * never strips a runtime sibling.
 */

import { requireChildSession, type ChildSessionCtx, levelFromXp } from "./child-dashboard.server";
import { getWorld, type LearningWorld } from "./worlds";

export { requireChildSession };

export async function logChildEvent(
  ctx: ChildSessionCtx,
  event: string,
  metadata: Record<string, unknown>,
) {
  try {
    await ctx.supabaseAdmin.from("child_events").insert({
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      event,
      metadata,
    });
  } catch {
    /* analytics must never break the child's flow */
  }
}

export function requireWorld(worldId: string): LearningWorld {
  const world = getWorld(worldId);
  if (!world) throw new Error("That world isn't open yet.");
  return world;
}

export async function ensureWorldProgress(ctx: ChildSessionCtx, worldId: string) {
  const { supabaseAdmin, childId, parentId } = ctx;

  await supabaseAdmin
    .from("child_world_progress")
    .upsert(
      { child_id: childId, parent_id: parentId, world_id: worldId },
      { onConflict: "child_id,world_id", ignoreDuplicates: true },
    );

  const { data } = await supabaseAdmin
    .from("child_world_progress")
    .select("*")
    .eq("child_id", childId)
    .eq("world_id", worldId)
    .maybeSingle();

  return data;
}

export async function awardXp(ctx: ChildSessionCtx, amount: number) {
  const { supabaseAdmin, childId, parentId } = ctx;

  await supabaseAdmin
    .from("child_progress")
    .upsert({ child_id: childId, parent_id: parentId }, { onConflict: "child_id", ignoreDuplicates: true });

  const { data: progress } = await supabaseAdmin
    .from("child_progress")
    .select("xp")
    .eq("child_id", childId)
    .maybeSingle();

  const before = levelFromXp(progress?.xp ?? 0);
  const xp = (progress?.xp ?? 0) + amount;
  const after = levelFromXp(xp);

  await supabaseAdmin.from("child_progress").update({ xp, level: after.level }).eq("child_id", childId);

  return { level: after, leveledUp: after.level > before.level, xpAwarded: amount };
}

export async function grantBadge(ctx: ChildSessionCtx, badgeId: string) {
  await ctx.supabaseAdmin
    .from("child_badges")
    .upsert(
      { child_id: ctx.childId, parent_id: ctx.parentId, badge_id: badgeId },
      { onConflict: "child_id,badge_id", ignoreDuplicates: true },
    );
}

/** Percent of the learning path a child has finished in a world. */
export function worldCompletion(world: LearningWorld, completedStages: string[] | null | undefined) {
  const done = (completedStages ?? []).length;
  return Math.min(100, Math.round((done / world.stages.length) * 100));
}
