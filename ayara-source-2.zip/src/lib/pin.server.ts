/**
 * PIN hashing using Web Crypto PBKDF2 (works in both Node and the edge worker
 * runtime, where node:crypto's sync pbkdf2 can fail or blow the CPU budget).
 * Format stays `saltBase64:hashBase64` so previously stored hashes still verify.
 */

const ITERATIONS = 100_000;
const KEYLEN_BYTES = 64;

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary);
}

function fromBase64(value: string): Uint8Array {
  const binary = atob(value);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) out[i] = binary.charCodeAt(i);
  return out;
}

async function derive(pin: string, saltBase64: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(pin),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: fromBase64(saltBase64) as unknown as BufferSource,
      iterations: ITERATIONS,
      hash: "SHA-512",
    },
    key,
    KEYLEN_BYTES * 8,
  );
  return toBase64(new Uint8Array(bits));
}

export async function hashPin(pin: string): Promise<string> {
  const salt = toBase64(crypto.getRandomValues(new Uint8Array(16)));
  const hash = await derive(pin, salt);
  return `${salt}:${hash}`;
}

export async function verifyPin(pin: string, stored: string): Promise<boolean> {
  const parts = stored.split(":");
  if (parts.length !== 2) return false;
  const [salt, hash] = parts;
  if (!salt || !hash) return false;
  try {
    const computed = await derive(pin, salt);
    if (computed.length !== hash.length) return false;
    let diff = 0;
    for (let i = 0; i < computed.length; i += 1) {
      diff |= computed.charCodeAt(i) ^ hash.charCodeAt(i);
    }
    return diff === 0;
  } catch {
    return false;
  }
}
