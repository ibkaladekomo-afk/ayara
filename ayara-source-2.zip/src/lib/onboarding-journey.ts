/**
 * The child's first-run journey (Volume 2, Section 2).
 *
 * One ordered adventure, two voices: Spark (grades 2-5) hears a storybook,
 * Forge (grades 6-8) gets a studio briefing. Same beats, different tone.
 */

import type { AgeTierId } from "@/lib/age-tiers";

export const JOURNEY_STEPS = [
  "doorway",
  "welcome",
  "avatar",
  "interests",
  "mentors",
  "quest",
  "conversation",
  "creation",
  "celebration",
  "worldmap",
  "done",
] as const;

export type JourneyStep = (typeof JOURNEY_STEPS)[number];

export function nextStep(step: JourneyStep): JourneyStep {
  const i = JOURNEY_STEPS.indexOf(step);
  return JOURNEY_STEPS[Math.min(i + 1, JOURNEY_STEPS.length - 1)]!;
}

export function stepProgress(step: JourneyStep): number {
  const i = JOURNEY_STEPS.indexOf(step);
  return Math.round((i / (JOURNEY_STEPS.length - 1)) * 100);
}

export function isJourneyStep(value: unknown): value is JourneyStep {
  return typeof value === "string" && (JOURNEY_STEPS as readonly string[]).includes(value);
}

/* ------------------------------- Interests ------------------------------ */

export interface InterestOption {
  id: string;
  label: string;
  emoji: string;
}

export const INTERESTS: InterestOption[] = [
  { id: "space", label: "Space", emoji: "🪐" },
  { id: "animals", label: "Animals", emoji: "🦊" },
  { id: "art", label: "Art", emoji: "🎨" },
  { id: "music", label: "Music", emoji: "🎵" },
  { id: "reading", label: "Reading", emoji: "📖" },
  { id: "building", label: "Building", emoji: "🧱" },
  { id: "nature", label: "Nature", emoji: "🌿" },
  { id: "sports", label: "Sports", emoji: "⚽" },
  { id: "coding", label: "Coding", emoji: "💻" },
  { id: "science", label: "Science", emoji: "🔬" },
  { id: "robots", label: "Robots", emoji: "🤖" },
  { id: "stories", label: "Stories", emoji: "📚" },
  { id: "history", label: "History", emoji: "🏛️" },
  { id: "math", label: "Math", emoji: "➗" },
  { id: "helping", label: "Helping people", emoji: "💛" },
];

export const MIN_INTERESTS = 3;

export function interestLabel(id: string): string {
  return INTERESTS.find((i) => i.id === id)?.label ?? id;
}

/* -------------------------------- Mentors ------------------------------- */

export interface Mentor {
  id: string;
  name: string;
  emoji: string;
  role: string;
  worldId: string;
  /** Spoken to Spark learners */
  sparkLine: string;
  /** Spoken to Forge learners */
  forgeLine: string;
  tile: string;
}

export const MENTORS: Mentor[] = [
  {
    id: "nova",
    name: "Dr. Nova",
    emoji: "🔭",
    role: "Science & big questions",
    worldId: "science-lab",
    sparkLine: "I love science and asking big questions.",
    forgeLine: "I run the lab. Bring me a question worth testing and we'll design the experiment together.",
    tile: "from-[oklch(0.72_0.15_255)] to-[oklch(0.66_0.17_285)]",
  },
  {
    id: "luna",
    name: "Luna",
    emoji: "🎨",
    role: "Art & imagination",
    worldId: "art-studio",
    sparkLine: "I help ideas become beautiful creations.",
    forgeLine: "I work in the studio. Ideas are cheap — I'll help you make yours land.",
    tile: "from-[oklch(0.78_0.14_35)] to-[oklch(0.85_0.13_95)]",
  },
  {
    id: "byte",
    name: "Byte",
    emoji: "🤖",
    role: "Code, games & inventions",
    worldId: "code-workshop",
    sparkLine: "I build games, robots, and cool inventions.",
    forgeLine: "I build things that run. Code, robots, systems — we prototype, break it, then fix it.",
    tile: "from-[oklch(0.66_0.17_285)] to-[oklch(0.72_0.12_195)]",
  },
  {
    id: "echo",
    name: "Echo",
    emoji: "📚",
    role: "Story & communication",
    worldId: "story-tree",
    sparkLine: "Every great adventure begins with a story.",
    forgeLine: "Every project needs a story. I'll help you say what you built and why it matters.",
    tile: "from-[oklch(0.78_0.13_150)] to-[oklch(0.72_0.12_195)]",
  },
];

/* ---------------------------- Curiosity Quest --------------------------- */

export type QuestBeatKind = "tap" | "listen" | "ask" | "choose" | "puzzle";

export interface QuestBeat {
  id: QuestBeatKind;
  sparkTitle: string;
  forgeTitle: string;
  sparkLine: string;
  forgeLine: string;
}

export const QUEST_NAME = "The Missing Spark";

export const QUEST_BEATS: QuestBeat[] = [
  {
    id: "tap",
    sparkTitle: "Find the glowing bits",
    forgeTitle: "Collect the fragments",
    sparkLine: "My Spark of Curiosity broke into pieces! Tap every glowing piece you can find.",
    forgeLine: "The Spark scattered into fragments. Collect all of them to continue.",
  },
  {
    id: "listen",
    sparkTitle: "Listen closely",
    forgeTitle: "Signal check",
    sparkLine: "Great! Now press listen — the Spark hums when it's close by.",
    forgeLine: "Play the signal. The Spark leaves a trace you can hear.",
  },
  {
    id: "ask",
    sparkTitle: "Ask me anything",
    forgeTitle: "Ask a question",
    sparkLine: "Curiosity grows when you ask questions. Pick a question to ask me!",
    forgeLine: "A good question moves a project forward. Pick one to open with.",
  },
  {
    id: "choose",
    sparkTitle: "Pick an idea",
    forgeTitle: "Choose a direction",
    sparkLine: "Which idea feels most exciting to you right now?",
    forgeLine: "Which of these would you actually want to build?",
  },
  {
    id: "puzzle",
    sparkTitle: "Finish the pattern",
    forgeTitle: "Complete the sequence",
    sparkLine: "One more piece! Finish the pattern to bring the Spark back.",
    forgeLine: "Last fragment. Complete the sequence and the Spark reassembles.",
  },
];

export const QUEST_QUESTIONS = [
  "Why do stars twinkle?",
  "How do robots think?",
  "What makes a story good?",
  "Why is the ocean salty?",
];

export const QUEST_IDEAS = [
  { id: "invent", emoji: "💡", label: "Invent something new" },
  { id: "explore", emoji: "🧭", label: "Explore somewhere far" },
  { id: "make", emoji: "🎨", label: "Make something beautiful" },
  { id: "help", emoji: "💛", label: "Help someone" },
];

/** Simple shape pattern: the child picks the missing item. */
export const QUEST_PATTERN = ["🔵", "🟡", "🔵", "🟡", "🔵"];
export const QUEST_PATTERN_OPTIONS = ["🟡", "🔵", "🟣"];
export const QUEST_PATTERN_ANSWER = "🟡";

/* --------------------------- Creative activity -------------------------- */

export interface CreativeActivity {
  id: string;
  title: string;
  prompt: string;
  placeholder: string;
  /** true when the child draws instead of writing */
  drawing?: boolean;
}

export function activitiesForGrade(grade: string | null, age: number): CreativeActivity[] {
  const g = grade ? Number(grade) : age <= 8 ? 3 : age <= 11 ? 5 : 7;

  if (g <= 3) {
    return [
      {
        id: "dream-animal",
        title: "Draw a dream animal",
        prompt: "Draw an animal nobody has ever seen before.",
        placeholder: "",
        drawing: true,
      },
      {
        id: "robot-name",
        title: "Name a friendly robot",
        prompt: "This robot needs a name and one special power. What are they?",
        placeholder: "My robot is called…",
      },
      {
        id: "tiny-story",
        title: "Build a tiny story",
        prompt: "Tell a story in three sentences. Anything you want!",
        placeholder: "Once upon a time…",
      },
    ];
  }

  if (g <= 5) {
    return [
      {
        id: "invention",
        title: "Design an invention",
        prompt: "Invent something that would make one day better for someone. What does it do?",
        placeholder: "My invention is…",
      },
      {
        id: "comic",
        title: "Write a short comic",
        prompt: "Write three comic panels. What happens in each one?",
        placeholder: "Panel 1…",
      },
      {
        id: "mission-idea",
        title: "Create a mission idea",
        prompt: "If you could send Ayara's crew on a mission, what would it be?",
        placeholder: "The mission is…",
      },
    ];
  }

  return [
    {
      id: "challenge",
      title: "Solve a challenge",
      prompt:
        "Your school wants to cut food waste in the cafeteria. Outline how you'd tackle it in a few sentences.",
      placeholder: "My approach…",
    },
    {
      id: "improve-idea",
      title: "Improve an idea with AI",
      prompt:
        "Describe an everyday product, then explain one way AI could genuinely make it better — and one risk it would introduce.",
      placeholder: "The product I'd improve…",
    },
    {
      id: "future-city",
      title: "Design a future city",
      prompt: "Describe one system in your future city — transport, energy, food — and how it works.",
      placeholder: "In my city…",
    },
  ];
}

/* ------------------------------- Copy ----------------------------------- */

export const FIRST_BADGE = { id: "first-spark", label: "First Spark", emoji: "✨" };
export const ONBOARDING_XP = 120;
export const STARTING_WORLD = "science-lab";

export function welcomeLine(tier: AgeTierId, name: string): string {
  return tier === "forge"
    ? `Welcome to Ayara, ${name}. I'm Aya. This is your studio — we build real things here. Ready to set it up?`
    : `Hi, ${name}! Welcome to Ayara. I'm Aya, your guide. Together we'll discover amazing ideas, build incredible projects, and explore the world of AI. Are you ready?`;
}

export function moreLine(tier: AgeTierId): string {
  return tier === "forge"
    ? "Ayara is where you learn to use AI well — research it, build with it, question it. You'll pick a look, choose what you're into, meet the crew, then run your first build. Around five minutes."
    : "Ayara is a place made just for you. You'll choose how you look, pick things you love, meet our friends, and go on a little adventure with me. It takes about five minutes!";
}

export const STEP_TITLES: Record<JourneyStep, { spark: string; forge: string }> = {
  doorway: { spark: "The doorway", forge: "Entering the studio" },
  welcome: { spark: "Meet Aya", forge: "Briefing" },
  avatar: { spark: "Make your character", forge: "Build your profile" },
  interests: { spark: "Things you love", forge: "Your focus areas" },
  mentors: { spark: "Meet your friends", forge: "Meet the crew" },
  quest: { spark: QUEST_NAME, forge: QUEST_NAME },
  conversation: { spark: "Talk with Aya", forge: "First exchange" },
  creation: { spark: "Make something", forge: "First build" },
  celebration: { spark: "You did it!", forge: "Logged" },
  worldmap: { spark: "Your worlds", forge: "Your worlds" },
  done: { spark: "Home", forge: "Home" },
};

/* ------------------------------ Analytics ------------------------------- */

export const EVENTS = {
  started: "child_onboarding_started",
  avatar: "avatar_selected",
  interests: "interest_selection_completed",
  mentors: "mentor_introductions_viewed",
  quest: "curiosity_quest_completed",
  conversation: "first_ai_conversation_completed",
  portfolio: "first_portfolio_item_created",
  badge: "first_badge_earned",
  world: "learning_world_unlocked",
  completed: "child_onboarding_completed",
} as const;
