import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  requireChildSession,
  listCreations,
  getCreation,
  insertCreation,
  recordCreationAppearance,
  logChildEvent,
} from "./child-creations.server";

/** The child's whole universe: creations, where they've been, and milestones. */
export const listMyCreations = createServerFn({ method: "POST" }).handler(async () => {
  const ctx = await requireChildSession();
  const creations = await listCreations(ctx);
  const crossovers = creations.reduce((n, c) => n + Math.max(0, c.worlds.length - 1), 0);
  const maxWorlds = creations.reduce((n, c) => Math.max(n, c.worlds.length), 0);
  return { creations, stats: { creations: creations.length, crossovers, maxWorlds } };
});

export const getMyCreation = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ creation_id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    return { creation: await getCreation(ctx, data.creation_id) };
  });

/** Register something the child just made as a creation in their universe. */
export const createMyCreation = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        name: z.string().min(1).max(60),
        kind: z.string().min(1).max(30),
        emoji: z.string().max(8).optional(),
        origin_world: z.string().min(1).max(60),
        traits: z.array(z.string().max(40)).max(12).optional(),
        summary: z.string().max(2000).optional(),
        portfolio_item_id: z.string().uuid().optional(),
        parent_creation_id: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const id = await insertCreation(ctx, {
      name: data.name,
      kind: data.kind,
      ...(data.emoji ? { emoji: data.emoji } : {}),
      origin_world: data.origin_world,
      traits: data.traits ?? [],
      summary: data.summary ?? null,
      portfolio_item_id: data.portfolio_item_id ?? null,
      parent_creation_id: data.parent_creation_id ?? null,
    });
    return { id };
  });

/** The child carried a creation into a world — log the visit and award the crossover. */
export const recordMyCreationAppearance = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        creation_id: z.string().uuid(),
        world_id: z.string().min(1).max(60),
        summary: z.string().max(2000).optional(),
        conversation_id: z.string().uuid().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const result = await recordCreationAppearance(ctx, {
      creation_id: data.creation_id,
      world_id: data.world_id,
      summary: data.summary ?? null,
      conversation_id: data.conversation_id ?? null,
    });
    await logChildEvent(ctx, "creation_carried", { creation_id: data.creation_id, world_id: data.world_id });
    return result;
  });

export const renameMyCreation = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ creation_id: z.string().uuid(), name: z.string().min(1).max(60) }).parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const { error } = await ctx.supabaseAdmin
      .from("child_creations")
      .update({ name: data.name })
      .eq("id", data.creation_id)
      .eq("child_id", ctx.childId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
