import { useEffect, useState } from "react";

const KEY = "ayara.reducedMotion";

/**
 * Honours the OS setting and an in-app toggle stored per browser.
 * Children who get overwhelmed by movement can turn animation off from any
 * onboarding screen.
 */
export function useReducedMotion(): [boolean, (value: boolean) => void] {
  const [system, setSystem] = useState(false);
  const [override, setOverride] = useState<boolean | null>(null);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setSystem(mq.matches);
    const onChange = () => setSystem(mq.matches);
    mq.addEventListener("change", onChange);
    try {
      const stored = window.localStorage.getItem(KEY);
      if (stored) setOverride(stored === "true");
    } catch {
      /* storage blocked */
    }
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const set = (value: boolean) => {
    setOverride(value);
    try {
      window.localStorage.setItem(KEY, String(value));
    } catch {
      /* storage blocked */
    }
  };

  return [override ?? system, set];
}
