/**
 * Parent-facing learning transparency: recaps and activity, not transcripts.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ChildInput = z.object({ child_id: z.string().uuid() });

export const getChildLearningSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ChildInput.parse(input))
  .handler(async ({ data, context }) => {
    const [summariesRes, eventsRes, portfolioRes, celebrationsRes] = await Promise.all([
      context.supabase
        .from("conversation_summaries")
        .select("id, summary, themes, skills, world_id, minutes, message_count, created_at")
        .eq("child_id", data.child_id)
        .eq("parent_id", context.userId)
        .order("created_at", { ascending: false })
        .limit(10),
      context.supabase
        .from("child_events")
        .select("event")
        .eq("child_id", data.child_id)
        .eq("parent_id", context.userId)
        .limit(1000),
      context.supabase
        .from("portfolio_items")
        .select("id")
        .eq("child_id", data.child_id)
        .eq("parent_id", context.userId),
      context.supabase
        .from("child_celebrations")
        .select("key, title, created_at")
        .eq("child_id", data.child_id)
        .eq("parent_id", context.userId)
        .order("created_at", { ascending: false })
        .limit(5),
    ]);

    const summaries = summariesRes.data ?? [];
    const events = eventsRes.data ?? [];

    const counts: Record<string, number> = {};
    for (const row of events) counts[row.event] = (counts[row.event] ?? 0) + 1;

    const themes = Array.from(new Set(summaries.flatMap((s) => s.themes ?? []))).slice(0, 8);
    const skills = Array.from(new Set(summaries.flatMap((s) => s.skills ?? []))).slice(0, 8);
    const minutes = summaries.reduce((total, s) => total + (s.minutes ?? 0), 0);

    return {
      summaries,
      themes,
      skills,
      minutes,
      projects: (portfolioRes.data ?? []).length,
      celebrations: celebrationsRes.data ?? [],
      questionsAsked: counts["question_asked"] ?? 0,
      voiceInteractions: counts["voice_used"] ?? 0,
      reflections: counts["reflection_completed"] ?? 0,
      challenges: counts["challenge_accepted"] ?? 0,
    };
  });

export const clearChildConversationHistory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ChildInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: child } = await context.supabase
      .from("child_profiles")
      .select("id")
      .eq("id", data.child_id)
      .eq("parent_id", context.userId)
      .maybeSingle();
    if (!child) throw new Error("Child not found");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: conversations } = await supabaseAdmin
      .from("conversations")
      .select("id")
      .eq("child_id", data.child_id)
      .eq("parent_id", context.userId);

    const ids = (conversations ?? []).map((c: { id: string }) => c.id);
    if (ids.length > 0) {
      await supabaseAdmin.from("messages").delete().in("conversation_id", ids);
      await supabaseAdmin.from("conversation_summaries").delete().in("conversation_id", ids);
      await supabaseAdmin.from("child_missions").update({ conversation_id: null }).in("conversation_id", ids);
      await supabaseAdmin.from("creation_appearances").update({ conversation_id: null }).in("conversation_id", ids);
      await supabaseAdmin.from("safety_alerts").update({ conversation_id: null }).in("conversation_id", ids);
      await supabaseAdmin.from("conversations").delete().in("id", ids);
    }

    return { cleared: ids.length };
  });
