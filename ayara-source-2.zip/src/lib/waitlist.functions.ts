import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const WaitlistSchema = z.object({
  email: z.string().email().max(255),
  name: z.string().max(100).optional(),
  type: z.enum(["parent"]),
});

export const joinWaitlist = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WaitlistSchema.parse(input))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const supabasePublic = createClient(
      process.env["SUPABASE_URL"]!,
      process.env["SUPABASE_PUBLISHABLE_KEY"]!,
      {
        auth: { persistSession: false, autoRefreshToken: false },
      },
    );

    const { data: entry, error } = await supabasePublic
      .from("waitlist")
      .insert(data)
      .select()
      .single();

    if (error) {
      if (error.code === "23505") {
        throw new Error("This email is already on the list.");
      }
      throw new Error(error.message);
    }
    return entry;
  });
