import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SaveMessageSchema = z.object({
  conversation_id: z.string().uuid(),
  role: z.enum(["user", "assistant", "system"]),
  content: z.string().min(1),
});

export const saveMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SaveMessageSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: conversation, error: convError } = await context.supabase
      .from("conversations")
      .select("id")
      .eq("id", data.conversation_id)
      .eq("parent_id", context.userId)
      .single();

    if (convError || !conversation) {
      throw new Error("Conversation not found or access denied");
    }

    const { data: message, error } = await context.supabase
      .from("messages")
      .insert(data)
      .select()
      .single();

    if (error) throw new Error(error.message);
    return message;
  });
