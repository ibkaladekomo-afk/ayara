import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface SafetyAlert {
  id: string;
  child_id: string;
  conversation_id: string | null;
  category: string;
  severity: "notice" | "attention" | "urgent";
  excerpt: string;
  ayara_response: string | null;
  reviewed_at: string | null;
  created_at: string;
}

/** Alerts for the signed-in parent's children, newest first. */
export const listSafetyAlerts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("safety_alerts")
      .select("id, child_id, conversation_id, category, severity, excerpt, ayara_response, reviewed_at, created_at")
      .eq("parent_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) throw new Error(error.message);
    return (data ?? []) as SafetyAlert[];
  });

export const markSafetyAlertReviewed = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("safety_alerts")
      .update({ reviewed_at: new Date().toISOString() })
      .eq("id", data.id)
      .eq("parent_id", context.userId);

    if (error) throw new Error(error.message);
    return { ok: true };
  });
