import { useCallback, useEffect, useRef, useState } from "react";
import { createParser } from "eventsource-parser";

/* ---------------------------------- WAV ---------------------------------- */

function encodeWav(chunks: Float32Array[], sampleRate: number): Blob {
  const length = chunks.reduce((sum, c) => sum + c.length, 0);
  const samples = new Float32Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    samples.set(chunk, offset);
    offset += chunk.length;
  }

  // Downsample to 16 kHz to keep uploads small
  const target = 16000;
  const ratio = sampleRate / target;
  const outLength = Math.floor(samples.length / ratio);
  const pcm = new Int16Array(outLength);
  for (let i = 0; i < outLength; i++) {
    const s = Math.max(-1, Math.min(1, samples[Math.floor(i * ratio)] ?? 0));
    pcm[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }

  const buffer = new ArrayBuffer(44 + pcm.length * 2);
  const view = new DataView(buffer);
  const writeString = (pos: number, str: string) => {
    for (let i = 0; i < str.length; i++) view.setUint8(pos + i, str.charCodeAt(i));
  };
  writeString(0, "RIFF");
  view.setUint32(4, 36 + pcm.length * 2, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, target, true);
  view.setUint32(28, target * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, "data");
  view.setUint32(40, pcm.length * 2, true);
  new Int16Array(buffer, 44).set(pcm);

  return new Blob([buffer], { type: "audio/wav" });
}

/* ------------------------------ Voice input ------------------------------ */

type RecorderState = "idle" | "recording" | "transcribing";

export function useVoiceInput({
  language,
  onTranscript,
  onError,
}: {
  language?: string;
  onTranscript: (text: string) => void;
  onError?: (message: string) => void;
}) {
  const [state, setState] = useState<RecorderState>("idle");
  const streamRef = useRef<MediaStream | null>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const nodeRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const chunksRef = useRef<Float32Array[]>([]);

  const cleanup = useCallback(() => {
    nodeRef.current?.disconnect();
    sourceRef.current?.disconnect();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    nodeRef.current = null;
    sourceRef.current = null;
    streamRef.current = null;
  }, []);

  useEffect(() => () => cleanup(), [cleanup]);

  const start = useCallback(async () => {
    if (state !== "idle") return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const ctx = new AudioContext();
      ctxRef.current = ctx;
      if (ctx.state === "suspended") await ctx.resume().catch(() => {});
      const source = ctx.createMediaStreamSource(stream);
      const node = ctx.createScriptProcessor(4096, 1, 1);
      chunksRef.current = [];
      node.onaudioprocess = (e) => {
        chunksRef.current.push(new Float32Array(e.inputBuffer.getChannelData(0)));
      };
      source.connect(node);
      node.connect(ctx.destination);
      sourceRef.current = source;
      nodeRef.current = node;
      setState("recording");
    } catch {
      onError?.("I couldn't hear you — please allow microphone access.");
      cleanup();
      setState("idle");
    }
  }, [state, cleanup, onError]);

  const stop = useCallback(async () => {
    if (state !== "recording") return;
    const ctx = ctxRef.current;
    const sampleRate = ctx?.sampleRate ?? 48000;
    cleanup();
    setState("transcribing");

    const blob = encodeWav(chunksRef.current, sampleRate);
    chunksRef.current = [];
    await ctx?.close().catch(() => {});
    ctxRef.current = null;

    if (blob.size < 4096) {
      onError?.("I didn't catch that — hold the button and speak.");
      setState("idle");
      return;
    }

    try {
      const form = new FormData();
      form.append("file", blob, "recording.wav");
      if (language) form.append("language", language);
      const res = await fetch("/api/stt", { method: "POST", body: form });
      if (!res.ok) throw new Error(await res.text().catch(() => ""));
      const data = (await res.json()) as { text?: string };
      const text = (data.text ?? "").trim();
      if (text) onTranscript(text);
      else onError?.("I didn't catch that — let's try again.");
    } catch {
      onError?.("I couldn't understand that — let's try again.");
    } finally {
      setState("idle");
    }
  }, [state, cleanup, language, onTranscript, onError]);

  return { state, start, stop, isRecording: state === "recording", isTranscribing: state === "transcribing" };
}

/* ------------------------------ Read aloud ------------------------------- */

/**
 * One shared AudioContext for the whole app, unlocked by the first user
 * gesture. Browsers (especially iOS and sandboxed preview iframes) create
 * contexts in a "suspended" state; without this unlock, playback silently
 * produces nothing.
 */
let sharedCtx: AudioContext | null = null;
const unlockWaiters: Array<() => void> = [];
let activeSpeechStop: (() => void) | null = null;

function getAudioContext(): AudioContext {
  if (!sharedCtx || sharedCtx.state === "closed") {
    sharedCtx = new AudioContext({ sampleRate: 24000 });
  }
  return sharedCtx;
}

function flushUnlockWaiters() {
  while (unlockWaiters.length) unlockWaiters.shift()?.();
}

async function tryResume(ctx: AudioContext) {
  if (ctx.state === "running") return true;
  try {
    await ctx.resume();
  } catch {
    /* blocked by autoplay policy */
  }
  return (ctx.state as string) === "running";
}

if (typeof window !== "undefined") {
  const unlock = () => {
    const ctx = getAudioContext();
    void tryResume(ctx).then((ok) => {
      if (!ok) return;
      // Silent tick keeps some browsers from re-suspending immediately.
      try {
        const buffer = ctx.createBuffer(1, 1, 24000);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.start(0);
      } catch {
        /* ignore */
      }
      flushUnlockWaiters();
    });
  };
  for (const evt of ["pointerdown", "touchstart", "keydown"] as const) {
    window.addEventListener(evt, unlock, { passive: true });
  }
}

/** Resolves once the context is running, or immediately if it already is. */
function waitForAudioUnlock(ctx: AudioContext, signal: AbortSignal, timeoutMs = 15000) {
  if (ctx.state === "running") return Promise.resolve(true);
  return new Promise<boolean>((resolve) => {
    let settled = false;
    const done = (value: boolean) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    unlockWaiters.push(() => done(true));
    signal.addEventListener("abort", () => done(false), { once: true });
    // Give up after a while rather than hanging the "speaking" state forever.
    window.setTimeout(() => done(ctx.state === "running"), timeoutMs);
  });
}


/** Split text so no single request exceeds the model's input limit. */
function chunkForSpeech(text: string, maxChars = 900): string[] {
  const sentences = text.match(/[^.!?\n]+[.!?\n]*\s*/g) ?? [text];
  const chunks: string[] = [];
  let current = "";
  const flush = () => {
    if (current.trim()) chunks.push(current.trim());
    current = "";
  };
  for (const sentence of sentences) {
    if (sentence.length > maxChars) {
      flush();
      for (let i = 0; i < sentence.length; i += maxChars) {
        chunks.push(sentence.slice(i, i + maxChars));
      }
      continue;
    }
    if (current.length + sentence.length > maxChars) flush();
    current += sentence;
  }
  flush();
  return chunks;
}

export function useReadAloud() {
  const [speaking, setSpeaking] = useState(false);
  const sourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const abortRef = useRef<AbortController | null>(null);
  const endTimerRef = useRef<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const stop = useCallback(() => {
    if (activeSpeechStop === stop) activeSpeechStop = null;
    abortRef.current?.abort();
    abortRef.current = null;
    if (endTimerRef.current !== null) {
      window.clearTimeout(endTimerRef.current);
      endTimerRef.current = null;
    }
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      audioRef.current = null;
    }
    sourcesRef.current.forEach((s) => {
      try {
        s.stop();
      } catch {
        /* already stopped */
      }
    });
    sourcesRef.current = [];
    setSpeaking(false);
  }, []);

  useEffect(() => () => stop(), [stop]);

  /**
   * Fallback for browsers/iframes that keep the Web Audio engine suspended:
   * fetch a plain mp3 and play it through an <audio> element.
   */
  const speakViaAudioElement = useCallback(async (text: string, signal: AbortSignal) => {
    for (const chunk of chunkForSpeech(text)) {
      if (signal.aborted) return;
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: chunk, format: "mp3" }),
        signal,
      });
      if (!res.ok) throw new Error(`tts failed: ${res.status}`);
      const url = URL.createObjectURL(await res.blob());
      const audio = new Audio(url);
      audioRef.current = audio;
      try {
        await new Promise<void>((resolve, reject) => {
          audio.onended = () => resolve();
          audio.onerror = () => reject(new Error("audio playback failed"));
          signal.addEventListener("abort", () => resolve(), { once: true });
          void audio.play().catch(reject);
        });
      } finally {
        URL.revokeObjectURL(url);
      }
    }
  }, []);

  const speak = useCallback(
    async (text: string) => {
      if (!text.trim()) return;
      // Read-aloud is app-wide, not hook-local. Onboarding screens can render
      // a shell narrator and an interactive Aya narrator at the same time;
      // always silence whichever one spoke previously before starting another.
      if (activeSpeechStop && activeSpeechStop !== stop) activeSpeechStop();
      stop();
      activeSpeechStop = stop;
      const controller = new AbortController();
      abortRef.current = controller;
      setSpeaking(true);

      const ctx = getAudioContext();
      if (!(await tryResume(ctx))) {
        // Autoplay-blocked: wait briefly for a tap, then fall back to <audio>.
        const unlocked = await waitForAudioUnlock(ctx, controller.signal, 1500);
        if (controller.signal.aborted) {
          setSpeaking(false);
          return;
        }
        if (!unlocked) {
          try {
            await speakViaAudioElement(text, controller.signal);
          } catch (error) {
            if (!controller.signal.aborted) console.warn("[read-aloud:fallback]", error);
          }
          if (activeSpeechStop === stop) activeSpeechStop = null;
          setSpeaking(false);
          return;
        }
      }


      let playhead = 0;
      let pending = new Uint8Array(0);

      const playChunk = (incoming: Uint8Array) => {
        const bytes = new Uint8Array(pending.length + incoming.length);
        bytes.set(pending);
        bytes.set(incoming, pending.length);
        const usable = bytes.length - (bytes.length % 2);
        pending = bytes.slice(usable);
        if (usable === 0) return;
        const samples = new Int16Array(bytes.buffer, 0, usable / 2);
        const floats = Float32Array.from(samples, (s) => s / 32768);
        const buffer = ctx.createBuffer(1, floats.length, 24000);
        buffer.copyToChannel(floats, 0);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        playhead = playhead < ctx.currentTime ? ctx.currentTime + 0.08 : playhead;
        source.start(playhead);
        playhead += buffer.duration;
        sourcesRef.current.push(source);
      };

      const streamChunk = async (chunk: string, attempt = 0): Promise<void> => {
        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: chunk }),
          signal: controller.signal,
        });

        if (!res.ok || !res.body) {
          // Rate limits / transient upstream failures: one backoff retry.
          if (attempt < 1 && (res.status === 429 || res.status >= 500)) {
            await new Promise((r) => window.setTimeout(r, 900));
            if (controller.signal.aborted) return;
            return streamChunk(chunk, attempt + 1);
          }
          throw new Error(`tts failed: ${res.status}`);
        }

        const parser = createParser({
          onEvent(event) {
            let payload: { type?: string; audio?: string };
            try {
              payload = JSON.parse(event.data);
            } catch {
              return;
            }
            if (payload.type !== "speech.audio.delta" || !payload.audio) return;
            const binary = atob(payload.audio);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            playChunk(bytes);
          },
        });

        const reader = res.body.pipeThrough(new TextDecoderStream()).getReader();
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          parser.feed(value);
        }
      };

      try {
        for (const chunk of chunkForSpeech(text)) {
          if (controller.signal.aborted) return;
          await streamChunk(chunk);
        }
        const remaining = Math.max(0, playhead - ctx.currentTime);
        endTimerRef.current = window.setTimeout(() => {
          endTimerRef.current = null;
          if (activeSpeechStop === stop) activeSpeechStop = null;
          setSpeaking(false);
        }, remaining * 1000 + 120);
      } catch (error) {
        if (!controller.signal.aborted) {
          console.warn("[read-aloud]", error);
        }
        if (activeSpeechStop === stop) activeSpeechStop = null;
        setSpeaking(false);
      }
    },
    [stop],
  );

  return { speak, stop, speaking };
}

