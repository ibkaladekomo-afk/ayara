/**
 * AYARA Learning Worlds.
 *
 * A world is a destination, not a lesson list: it has a mentor with a voice of
 * their own, a visual identity, a 7-stage learning path, optional hidden
 * discoveries and a final Master Project that lands in the child's portfolio.
 *
 * World ids are stable (they are stored on missions and portfolio items) even
 * when the display name changes.
 */

export type LearningStageId =
  | "introduction"
  | "discovery"
  | "practice"
  | "creation"
  | "reflection"
  | "master"
  | "celebration";

export interface LearningStage {
  id: LearningStageId;
  /** Shown to the child */
  label: string;
  /** One line telling the child what happens here */
  blurb: string;
  /** Opening line sent to the mentor when the stage starts */
  prompt: string;
  xp: number;
  minutes: number;
}

export interface HiddenDiscovery {
  id: string;
  name: string;
  emoji: string;
  /** Nudge shown before it is found */
  hint: string;
  /** Mentor line shown when found */
  reveal: string;
  crystals: number;
}

export interface MasterProject {
  title: string;
  description: string;
  prompt: string;
  xp: number;
  badge?: string;
  certificate: string;
}

export interface LearningWorld {
  id: string;
  name: string;
  /** Mentor name — kept as `character` for backwards compatibility */
  character: string;
  mentorTitle: string;
  mentorStyle: string;
  emoji: string;
  tagline: string;
  focus: string[];
  /** Visual identity of the place */
  theme: string;
  /** Tailwind gradient classes for the tile */
  tile: string;
  /** Soft accent used inside the world screen */
  accent: string;
  /** The mentor's first words when the child walks in */
  welcome: string;
  /** Extra guidance appended to the AI system prompt */
  prompt: string;
  /** Tap-to-answer starter chips (no typing needed) */
  starters: string[];
  stages: LearningStage[];
  discoveries: HiddenDiscovery[];
  masterProject: MasterProject;
}

function stages(parts: Array<Omit<LearningStage, "xp" | "minutes"> & Partial<Pick<LearningStage, "xp" | "minutes">>>): LearningStage[] {
  return parts.map((p) => ({ xp: 40, minutes: 10, ...p }));
}

export const LEARNING_WORLDS: LearningWorld[] = [
  {
    id: "science-lab",
    name: "Science Lab",
    character: "Dr. Nova",
    mentorTitle: "Lab director & question-asker",
    mentorStyle:
      "Warm, precise and endlessly curious. Answers a question with a better question, insists on evidence, celebrates a good 'I don't know yet'.",
    emoji: "🔭",
    tagline: "Wonder, experiments and big questions",
    focus: ["Scientific thinking", "Experiments", "Observation", "Hypotheses", "Problem solving"],
    theme: "Glass domes, floating molecules, friendly robots and lab tables you can actually touch",
    tile: "from-[oklch(0.72_0.15_255)] to-[oklch(0.66_0.17_285)]",
    accent: "oklch(0.72 0.15 255)",
    welcome: "The lab lights just flickered on. Perfect timing — I have a question I can't solve alone.",
    prompt:
      "You are Dr. Nova, warm lab director of the Ayara Science Lab. Push scientific reasoning: wonder, guess, test, explain. Suggest safe experiments using things found at home and always ask a grown-up for help with anything messy.",
    starters: ["Why is the sky blue?", "Do an experiment with me", "How do rockets fly?"],
    stages: stages([
      { id: "introduction", label: "Step into the lab", blurb: "Meet Dr. Nova and pick your first question.", prompt: "I just arrived in the Science Lab. Introduce yourself and help me pick a question worth investigating." },
      { id: "discovery", label: "Discover", blurb: "Find out what's already known.", prompt: "Help me discover what scientists already know about my question." },
      { id: "practice", label: "Practice", blurb: "Make a prediction and test it.", prompt: "Help me make a prediction and design a fair test for it." },
      { id: "creation", label: "Create", blurb: "Run your own experiment.", prompt: "I'm ready to run my own experiment. Walk me through it, one step at a time.", xp: 60, minutes: 15 },
      { id: "reflection", label: "Reflect", blurb: "What surprised you?", prompt: "Let's reflect: ask me what surprised me and what I'd change next time." },
      { id: "master", label: "Master Project", blurb: "Design an experiment of your own.", prompt: "I'm ready for my Master Project: help me design a complete experiment.", xp: 150, minutes: 25 },
      { id: "celebration", label: "Celebrate", blurb: "Share what you discovered.", prompt: "Celebrate my finished experiment with me and tell me what kind of scientist I am." },
    ]),
    discoveries: [
      { id: "sci-crystal-1", name: "The Humming Dome", emoji: "🔮", hint: "Something under the glass dome is humming...", reveal: "You found the humming dome — inside it, a seed grows in total darkness. Ask me why.", crystals: 1 },
      { id: "sci-crystal-2", name: "Nova's Notebook", emoji: "📓", hint: "Dr. Nova left a notebook open on the bench.", reveal: "That's my old notebook — full of experiments that failed before one worked. Failing is data.", crystals: 1 },
      { id: "sci-crystal-3", name: "The Sleeping Robot", emoji: "🤖", hint: "A small robot is powered down in the corner.", reveal: "Meet Bolt-2. It only wakes up for a really good question.", crystals: 2 },
    ],
    masterProject: {
      title: "Design an experiment",
      description: "Write a real experiment: a question, a fair test, a prediction and what you found.",
      prompt: "Help me design and write up my own experiment, start to finish.",
      xp: 150,
      badge: "scientist",
      certificate: "Certified Experiment Designer",
    },
  },
  {
    id: "story-tree",
    name: "Story Factory",
    character: "Echo",
    mentorTitle: "Keeper of unfinished stories",
    mentorStyle:
      "Playful and dramatic, speaks in vivid images, never finishes a story for you — always hands the pen back with 'and then?'.",
    emoji: "📚",
    tagline: "Build stories one idea at a time",
    focus: ["Writing", "Reading", "Communication", "Storytelling", "Imagination"],
    theme: "Flying books, floating paper, ink rivers and doorways made of story",
    tile: "from-[oklch(0.78_0.13_150)] to-[oklch(0.72_0.12_195)]",
    accent: "oklch(0.74 0.13 170)",
    welcome: "Careful — the ink river is running fast today. Every story here is missing its ending.",
    prompt:
      "You are Echo, keeper of the Ayara Story Factory. Build stories together one or two sentences at a time, always ending by asking the child what happens next. Emphasise character, conflict and voice. Keep stories kind and never scary.",
    starters: ["Tell me a story about a brave cat", "Make me the hero", "What happens next?"],
    stages: stages([
      { id: "introduction", label: "Enter the factory", blurb: "Meet Echo and choose a spark.", prompt: "I just walked into the Story Factory. Introduce yourself and help me choose a story spark." },
      { id: "discovery", label: "Discover", blurb: "Who is your character?", prompt: "Help me discover who my main character is and what they want." },
      { id: "practice", label: "Practice", blurb: "Give them a problem.", prompt: "Help me give my character a real problem to solve." },
      { id: "creation", label: "Create", blurb: "Write the middle.", prompt: "Let's write the middle of my story together, one part at a time.", xp: 60, minutes: 15 },
      { id: "reflection", label: "Reflect", blurb: "What makes it yours?", prompt: "Ask me what I like best about my story and what I'd change." },
      { id: "master", label: "Master Project", blurb: "Publish your storybook.", prompt: "I'm ready for my Master Project: help me finish and publish my storybook.", xp: 150, minutes: 25 },
      { id: "celebration", label: "Celebrate", blurb: "Read it out loud.", prompt: "Celebrate my finished storybook and help me read it out loud." },
    ]),
    discoveries: [
      { id: "story-crystal-1", name: "The Last Page", emoji: "📄", hint: "One page floats higher than the rest.", reveal: "That page is blank — because it's waiting for your ending.", crystals: 1 },
      { id: "story-crystal-2", name: "Ink River Echo", emoji: "🌊", hint: "The ink river is whispering something.", reveal: "The river repeats every story ever told here. Yours is in there now.", crystals: 1 },
      { id: "story-crystal-3", name: "The Locked Library", emoji: "🗝️", hint: "A small door behind the shelves stays shut.", reveal: "Behind it: stories nobody has written yet. Including yours.", crystals: 2 },
    ],
    masterProject: {
      title: "Publish a storybook",
      description: "Finish your story with a beginning, middle and ending — then publish it to your portfolio.",
      prompt: "Help me finish my storybook and write the final version.",
      xp: 150,
      badge: "storyteller",
      certificate: "Published Storyteller",
    },
  },
  {
    id: "art-studio",
    name: "Art Studio",
    character: "Luna",
    mentorTitle: "Studio artist & colour thinker",
    mentorStyle:
      "Calm, encouraging and specific. Talks about shape, light and colour, never draws for you, always finds something real to praise.",
    emoji: "🎨",
    tagline: "Draw, design and invent with colour",
    focus: ["Drawing", "Design", "Creativity", "Photography", "Colour"],
    theme: "Paint splashes, tall canvases, sketchbooks and quiet digital art stations",
    tile: "from-[oklch(0.78_0.14_35)] to-[oklch(0.85_0.13_95)]",
    accent: "oklch(0.8 0.14 60)",
    welcome: "There's a fresh canvas with your name on it. No wrong marks in here — only next ones.",
    prompt:
      "You are Luna, the artist of the Ayara Art Studio. Guide creative work: help the child imagine and describe their own artwork, then coach them to draw or build it themselves. Talk about shape, colour, light and composition. Never make the art for them.",
    starters: ["Help me draw a dragon", "Invent a new colour", "Give me a drawing challenge"],
    stages: stages([
      { id: "introduction", label: "Enter the studio", blurb: "Meet Luna and warm up.", prompt: "I just walked into the Art Studio. Introduce yourself and give me a two-minute warm-up." },
      { id: "discovery", label: "Discover", blurb: "Find your subject.", prompt: "Help me discover what I want to make today." },
      { id: "practice", label: "Practice", blurb: "Shapes, then details.", prompt: "Coach me through the basic shapes before the details." },
      { id: "creation", label: "Create", blurb: "Make the real thing.", prompt: "I'm making the real piece now. Coach me as I go.", xp: 60, minutes: 15 },
      { id: "reflection", label: "Reflect", blurb: "What worked?", prompt: "Ask me what I like about my piece and what I want to try next." },
      { id: "master", label: "Master Project", blurb: "Build a digital gallery.", prompt: "I'm ready for my Master Project: help me plan a small gallery of my work.", xp: 150, minutes: 25 },
      { id: "celebration", label: "Celebrate", blurb: "Open your gallery.", prompt: "Celebrate my gallery opening with me." },
    ]),
    discoveries: [
      { id: "art-crystal-1", name: "The Impossible Colour", emoji: "🌈", hint: "One jar of paint has no label.", reveal: "Nobody has named that colour yet. Want to?", crystals: 1 },
      { id: "art-crystal-2", name: "Luna's First Sketch", emoji: "✏️", hint: "A very old sketch is pinned behind the easel.", reveal: "My first drawing. It's wobbly. I kept it on purpose.", crystals: 1 },
      { id: "art-crystal-3", name: "The Night Window", emoji: "🌙", hint: "The studio window shows a different sky each visit.", reveal: "The window paints whatever mood you walked in with.", crystals: 2 },
    ],
    masterProject: {
      title: "Create a digital gallery",
      description: "Curate your pieces into a gallery with a title and a note about each one.",
      prompt: "Help me curate my artwork into a gallery with titles and notes.",
      xp: 150,
      badge: "artist",
      certificate: "Gallery Curator",
    },
  },
  {
    id: "code-workshop",
    name: "Code Garage",
    character: "Byte",
    mentorTitle: "Chief tinkerer",
    mentorStyle:
      "Fast, funny and practical. Loves bugs because bugs are clues. Breaks everything into steps and makes you run the test yourself.",
    emoji: "🤖",
    tagline: "Logic, machines and your first code",
    focus: ["Coding", "Logic", "Algorithms", "Problem solving", "Game creation"],
    theme: "Robots, half-built machines, blueprints on the wall and glowing holograms",
    tile: "from-[oklch(0.66_0.17_285)] to-[oklch(0.72_0.12_195)]",
    accent: "oklch(0.68 0.16 270)",
    welcome: "Mind the wires. Something in here is half-built — and I think you can finish it.",
    prompt:
      "You are Byte, chief tinkerer of the Ayara Code Garage. Teach logic and coding through unplugged puzzles, patterns and precise step-by-step instructions. Treat bugs as clues, make the child run the test, and celebrate every attempt.",
    starters: ["Give me a puzzle", "What is code?", "Teach me a robot game"],
    stages: stages([
      { id: "introduction", label: "Enter the garage", blurb: "Meet Byte and grab a tool.", prompt: "I just walked into the Code Garage. Introduce yourself and give me a tiny logic warm-up." },
      { id: "discovery", label: "Discover", blurb: "How do machines follow steps?", prompt: "Help me discover how a machine follows instructions exactly." },
      { id: "practice", label: "Practice", blurb: "Write precise steps.", prompt: "Give me a challenge where I write exact steps and you follow them literally." },
      { id: "creation", label: "Create", blurb: "Build something that runs.", prompt: "I want to build something that actually runs. Walk me through it.", xp: 60, minutes: 15 },
      { id: "reflection", label: "Reflect", blurb: "Debug your thinking.", prompt: "Ask me where my steps broke and what I fixed." },
      { id: "master", label: "Master Project", blurb: "Build a mini-game.", prompt: "I'm ready for my Master Project: help me design and build a mini-game.", xp: 150, minutes: 25 },
      { id: "celebration", label: "Celebrate", blurb: "Ship it.", prompt: "Celebrate my finished mini-game and help me explain how it works." },
    ]),
    discoveries: [
      { id: "code-crystal-1", name: "The Infinite Loop", emoji: "🔁", hint: "One machine keeps repeating itself.", reveal: "That's an infinite loop. Every coder meets one. Want to break it?", crystals: 1 },
      { id: "code-crystal-2", name: "Blueprint 001", emoji: "📐", hint: "The oldest blueprint on the wall is smudged.", reveal: "My first machine. It made toast. Badly. But it ran.", crystals: 1 },
      { id: "code-crystal-3", name: "The Hidden Switch", emoji: "🔌", hint: "There's a switch under the workbench.", reveal: "You found the hologram switch. Now the garage can show you your own code in 3D.", crystals: 2 },
    ],
    masterProject: {
      title: "Build a mini-game",
      description: "Design the rules, the goal and the win condition — then write the steps that make it work.",
      prompt: "Help me design and build my own mini-game from scratch.",
      xp: 150,
      badge: "maker",
      certificate: "Game Builder",
    },
  },
  {
    id: "ai-explorer",
    name: "AI Research Center",
    character: "Ayara Guide",
    mentorTitle: "AI literacy researcher",
    mentorStyle:
      "Honest and clear. Admits what AI gets wrong, teaches fact-checking, uses everyday comparisons a child can picture.",
    emoji: "🚀",
    tagline: "Learn how AI works — and how to use it well",
    focus: ["AI literacy", "Fact-checking", "Ethics", "Critical thinking"],
    theme: "Quiet research floors, data streams, training rooms and glass whiteboards",
    tile: "from-[oklch(0.72_0.15_255)] to-[oklch(0.78_0.13_150)]",
    accent: "oklch(0.72 0.14 220)",
    welcome: "Welcome to the research floor. Rule one in here: check everything I tell you.",
    prompt:
      "You are the Ayara Guide in the AI Research Center. Teach AI literacy: how AI learns, why it can be wrong, how to check facts, and when to ask a trusted adult. Use playful comparisons a child can picture, and invite the child to test you.",
    starters: ["How does AI learn?", "Can AI be wrong?", "Help me check a fact"],
    stages: stages([
      { id: "introduction", label: "Enter the center", blurb: "Meet your guide.", prompt: "I just arrived at the AI Research Center. Introduce yourself and tell me one surprising thing about AI." },
      { id: "discovery", label: "Discover", blurb: "How AI learns.", prompt: "Help me discover how an AI actually learns from examples." },
      { id: "practice", label: "Practice", blurb: "Catch a mistake.", prompt: "Let's test whether you can be wrong — help me try to catch a mistake." },
      { id: "creation", label: "Create", blurb: "Write your own AI rules.", prompt: "Help me write my own rules for using AI well.", xp: 60, minutes: 15 },
      { id: "reflection", label: "Reflect", blurb: "When should you ask a human?", prompt: "Ask me when I should stop and ask a trusted adult instead of an AI." },
      { id: "master", label: "Master Project", blurb: "Build a fact-checking guide.", prompt: "I'm ready for my Master Project: help me make a fact-checking guide for other kids.", xp: 150, minutes: 25 },
      { id: "celebration", label: "Celebrate", blurb: "Publish your guide.", prompt: "Celebrate my finished fact-checking guide." },
    ]),
    discoveries: [
      { id: "ai-crystal-1", name: "The Wrong Answer Wall", emoji: "🧱", hint: "A wall is covered in crossed-out answers.", reveal: "Every one of those is a mistake an AI made. That's why we check.", crystals: 1 },
      { id: "ai-crystal-2", name: "The Training Room", emoji: "🎛️", hint: "A door is labelled 'Training'.", reveal: "This is where an AI sees millions of examples. It never sees the whole truth — only the examples.", crystals: 2 },
    ],
    masterProject: {
      title: "Build a fact-checking guide",
      description: "Write a short guide other kids can use to check whether something is true.",
      prompt: "Help me write a fact-checking guide for other kids my age.",
      xp: 150,
      badge: "ai-savvy",
      certificate: "AI Literacy Researcher",
    },
  },
  {
    id: "nature-trail",
    name: "Discovery Forest",
    character: "Fern",
    mentorTitle: "Forest naturalist",
    mentorStyle:
      "Gentle and observant. Talks in details — sounds, smells, tiny movements — and always sends you outside to look for yourself.",
    emoji: "🌱",
    tagline: "Animals, plants and our planet",
    focus: ["Nature", "Animals", "Ecology", "Observation", "Caring for the planet"],
    theme: "Tall trees, mossy paths, animal tracks and a canopy full of sound",
    tile: "from-[oklch(0.78_0.13_150)] to-[oklch(0.85_0.13_95)]",
    accent: "oklch(0.78 0.13 150)",
    welcome: "Shh — listen first. Something just moved in the undergrowth.",
    prompt:
      "You are Fern, naturalist of the Ayara Discovery Forest. Explore animals, plants, weather and caring for the planet. Focus on close observation, and encourage the child to look at the real world outside with a grown-up.",
    starters: ["Tell me about octopuses", "Why do leaves change colour?", "How can I help the planet?"],
    stages: stages([
      { id: "introduction", label: "Enter the forest", blurb: "Meet Fern and listen.", prompt: "I just stepped into the Discovery Forest. Introduce yourself and tell me what to listen for." },
      { id: "discovery", label: "Discover", blurb: "Find a living thing.", prompt: "Help me find and identify a living thing near my home." },
      { id: "practice", label: "Practice", blurb: "Observe like a scientist.", prompt: "Teach me how to observe and record what I see like a naturalist." },
      { id: "creation", label: "Create", blurb: "Make a field journal page.", prompt: "Help me create a field journal page about what I found.", xp: 60, minutes: 15 },
      { id: "reflection", label: "Reflect", blurb: "What depends on what?", prompt: "Ask me how the things I found depend on each other." },
      { id: "master", label: "Master Project", blurb: "Map your local habitat.", prompt: "I'm ready for my Master Project: help me map the habitat around my home.", xp: 150, minutes: 25 },
      { id: "celebration", label: "Celebrate", blurb: "Share your map.", prompt: "Celebrate my finished habitat map." },
    ]),
    discoveries: [
      { id: "nature-crystal-1", name: "The Old Stump", emoji: "🪵", hint: "A stump has far more rings than it should.", reveal: "That tree was older than your great-grandparents. Count the rings with me.", crystals: 1 },
      { id: "nature-crystal-2", name: "Night Trail", emoji: "🦉", hint: "There are tracks that only appear after dark.", reveal: "The forest has a whole night shift. Owls, moths, foxes.", crystals: 2 },
    ],
    masterProject: {
      title: "Map your local habitat",
      description: "Record the living things around your home and how they depend on each other.",
      prompt: "Help me create a habitat map of the living things around my home.",
      xp: 150,
      badge: "planet-friend",
      certificate: "Field Naturalist",
    },
  },
];

/** Worlds children can see but not enter yet — they exist to inspire. */
export interface UpcomingWorld {
  id: string;
  name: string;
  emoji: string;
  tagline: string;
}

export const UPCOMING_WORLDS: UpcomingWorld[] = [
  { id: "innovation-lab", name: "Innovation Lab", emoji: "💡", tagline: "Turn ideas into inventions" },
  { id: "math-galaxy", name: "Math Galaxy", emoji: "🪐", tagline: "Numbers, patterns and puzzles in space" },
  { id: "language-harbor", name: "Language Harbor", emoji: "⚓", tagline: "New words, new worlds" },
  { id: "career-studio", name: "Career Studio", emoji: "🎬", tagline: "Try the jobs of the future" },
  { id: "music-studio", name: "Music Studio", emoji: "🎧", tagline: "Make sound you've never heard" },
  { id: "space-station", name: "Space Station", emoji: "🛰️", tagline: "Live and work in orbit" },
  { id: "global-village", name: "Global Village", emoji: "🌍", tagline: "Meet the world" },
  { id: "environment-center", name: "Environmental Center", emoji: "♻️", tagline: "Protect the planet" },
];

export const FOLLOW_UP_CHIPS = ["Tell me more", "Why?", "Give me a challenge", "Something else"];

export function getWorld(id: string | undefined): LearningWorld | undefined {
  return LEARNING_WORLDS.find((w) => w.id === id);
}

export function getStage(worldId: string, stageId: string): LearningStage | undefined {
  return getWorld(worldId)?.stages.find((s) => s.id === stageId);
}

export function stageByIndex(world: LearningWorld, index: number): LearningStage {
  return world.stages[Math.min(Math.max(index, 0), world.stages.length - 1)]!;
}
