import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  requireChildSession,
  touchStreak,
  ensureTodayMission,
  missionSteps,
  levelFromXp,
  todayISO,
} from "./child-dashboard.server";

/** Everything the child Innovation Hub renders in one round trip. */
export const getMyDashboard = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ tz_offset_minutes: z.number().int().min(-840).max(840).default(0) }).parse(input ?? {}),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const today = todayISO(data.tz_offset_minutes);

    const { progress, recovered } = await touchStreak(ctx, today);
    const mission = await ensureTodayMission(ctx, today);

    const [inProgress, badges, portfolio, unlocks, completedCount] = await Promise.all([
      ctx.supabaseAdmin
        .from("child_missions")
        .select("*")
        .eq("child_id", ctx.childId)
        .eq("status", "in_progress")
        .order("updated_at", { ascending: false })
        .limit(3),
      ctx.supabaseAdmin
        .from("child_badges")
        .select("badge_id, earned_at")
        .eq("child_id", ctx.childId)
        .order("earned_at", { ascending: false }),
      ctx.supabaseAdmin
        .from("portfolio_items")
        .select("id, kind, title, content, world_id, created_at")
        .eq("child_id", ctx.childId)
        .order("created_at", { ascending: false })
        .limit(6),
      ctx.supabaseAdmin.from("child_world_unlocks").select("world_id").eq("child_id", ctx.childId),
      ctx.supabaseAdmin
        .from("child_missions")
        .select("id", { count: "exact", head: true })
        .eq("child_id", ctx.childId)
        .eq("status", "completed"),
    ]);

    const xp = progress?.xp ?? 0;

    return {
      child: {
        id: ctx.child.id,
        name: ctx.child.name,
        age: ctx.child.age,
        grade: ctx.child.grade,
        language: ctx.child.language,
        interests: ctx.child.interests,
        avatar: ctx.child.avatar,
        avatar_config: ctx.child.avatar_config,
      },
      today,
      mission: {
        ...mission,
        steps: Array.isArray(mission.steps) && mission.steps.length > 0 ? mission.steps : missionSteps(mission.world_id, mission.title),
      },
      inProgress: (inProgress.data ?? []).filter((m: { id: string }) => m.id !== mission.id),
      streak: {
        days: progress?.streak_days ?? 0,
        recovered,
        lastActiveOn: progress?.last_active_on ?? null,
      },
      level: levelFromXp(xp),
      badges: badges.data ?? [],
      portfolio: portfolio.data ?? [],
      unlockedWorlds: (unlocks.data ?? []).map((u: { world_id: string }) => u.world_id),
      missionsCompleted: completedCount.count ?? 0,
    };
  });

/** Mark a mission as started (called when the child opens it from the Innovation Hub). */
export const startMyMission = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ mission_id: z.string().uuid(), conversation_id: z.string().uuid().optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const patch: Record<string, unknown> = { status: "in_progress" };
    if (data.conversation_id) patch['conversation_id'] = data.conversation_id;
    const { error } = await ctx.supabaseAdmin
      .from("child_missions")
      .update(patch)
      .eq("id", data.mission_id)
      .eq("child_id", ctx.childId)
      .neq("status", "completed");
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Advance the mission's step meter (drives the "Continue learning" progress bar). */
export const advanceMyMission = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ mission_id: z.string().uuid(), step: z.number().int().min(0).max(20), label: z.string().max(60).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    await ctx.supabaseAdmin
      .from("child_missions")
      .update({ progress_step: data.step, last_step_label: data.label ?? null, status: "in_progress" })
      .eq("id", data.mission_id)
      .eq("child_id", ctx.childId);
    return { ok: true };
  });

/** Complete a mission: award XP, unlock the badge, log the celebration. */
export const completeMyMission = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ mission_id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();

    const { data: mission } = await ctx.supabaseAdmin
      .from("child_missions")
      .select("*")
      .eq("id", data.mission_id)
      .eq("child_id", ctx.childId)
      .maybeSingle();
    if (!mission) throw new Error("Mission not found");
    if (mission.status === "completed") {
      const { data: p } = await ctx.supabaseAdmin
        .from("child_progress")
        .select("xp")
        .eq("child_id", ctx.childId)
        .maybeSingle();
      return { alreadyDone: true, xpAwarded: 0, level: levelFromXp(p?.xp ?? 0), badge: null as string | null };
    }

    await ctx.supabaseAdmin
      .from("child_missions")
      .update({
        status: "completed",
        completed_at: new Date().toISOString(),
        progress_step: mission.total_steps,
      })
      .eq("id", mission.id);

    const { awardRewards, logMissionEvent } = await import("./missions.server");
    const reward = await awardRewards(ctx, {
      xp: mission.xp_reward ?? 0,
      crystals: mission.crystal_reward ?? 0,
      badges: [mission.badge_reward],
      celebrationKeys: mission.kind === "weekly" ? ["weekly_done"] : [],
    });
    const after = reward.level;

    await logMissionEvent(ctx, "mission_completed", {
      mission_id: mission.id,
      kind: mission.kind,
      world_id: mission.world_id,
      xp: reward.xpAwarded,
    });

    return {
      alreadyDone: false,
      xpAwarded: reward.xpAwarded,
      level: after,
      leveledUp: reward.leveledUp,
      badge: (mission.badge_reward as string | null) ?? null,
    };
  });
