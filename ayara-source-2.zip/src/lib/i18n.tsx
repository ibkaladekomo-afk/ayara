import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "es";

type Entry = { en: string; es: string };

export const STRINGS = {
  // Launch
  "launch.greeting": { en: "Learn, build, and create with AI.", es: "Aprende, construye y crea con IA." },
  "launch.mission": {
    en: "Ayara helps kids use AI to make things, solve problems, and explore ideas — safely.",
    es: "Ayara ayuda a los niños a usar la IA para crear, resolver problemas y explorar ideas de forma segura.",
  },
  "launch.getStarted": { en: "Get started", es: "Comenzar" },
  "launch.haveAccount": { en: "I already have an account", es: "Ya tengo una cuenta" },
  "launch.kidLogin": { en: "Kid login", es: "Entrada para niños" },
  "launch.feature.projects.title": { en: "Build real projects", es: "Construye proyectos reales" },
  "launch.feature.projects.body": {
    en: "Missions across science, art, code and story turn curiosity into something kids can show off.",
    es: "Misiones de ciencia, arte, código e historia convierten la curiosidad en algo que los niños pueden mostrar.",
  },
  "launch.feature.safety.title": { en: "Safety by design", es: "Seguridad por diseño" },
  "launch.feature.safety.body": {
    en: "Every AI response is moderated, age-adapted and curriculum-checked so kids can explore freely.",
    es: "Cada respuesta de IA es moderada, adaptada por edad y revisada por currículo para que los niños exploren con libertad.",
  },
  "launch.feature.parents.title": { en: "Parents are partners", es: "Los padres son socios" },
  "launch.feature.parents.body": {
    en: "Progress, transcripts and controls in one calm dashboard — without hovering over every step.",
    es: "Progreso, transcripciones y controles en un panel tranquilo — sin vigilar cada paso.",
  },
  "common.privacy": { en: "Privacy Policy", es: "Política de privacidad" },
  "common.terms": { en: "Terms", es: "Términos" },
  "common.continue": { en: "Continue", es: "Continuar" },
  "common.back": { en: "Back", es: "Atrás" },
  "common.skip": { en: "Skip for now", es: "Omitir por ahora" },
  "common.saving": { en: "Saving…", es: "Guardando…" },
  "common.retry": { en: "Try again", es: "Intentar de nuevo" },
  "hub.title": { en: "Innovation Hub", es: "Centro de Innovación" },
  "hub.navHome": { en: "Home", es: "Inicio" },
  "hub.loadError": {
    en: "We couldn't load your Innovation Hub. Pull down to refresh or pick a world below.",
    es: "No pudimos cargar tu Centro de Innovación. Desliza para actualizar o elige un mundo abajo.",
  },

  // Carousel
  "welcome.1.title": { en: "Build what you imagine", es: "Construye lo que imaginas" },
  "welcome.1.body": {
    en: "Ayara is an AI learning studio where kids design, prototype and bring real ideas to life.",
    es: "Ayara es un estudio de aprendizaje con IA donde los niños diseñan, prototipan y dan vida a ideas reales.",
  },
  "welcome.2.title": { en: "Four worlds. One universe.", es: "Cuatro mundos. Un universo." },
  "welcome.2.body": {
    en: "Take on missions in engineering, science, story and code — and carry your creations between them.",
    es: "Acepta misiones de ingeniería, ciencia, historia y código, y lleva tus creaciones de un mundo a otro.",
  },
  "welcome.3.title": { en: "Parents stay in control", es: "Los padres tienen el control" },
  "welcome.3.body": {
    en: "Safety settings, progress insights and learning summaries — all from your parent dashboard.",
    es: "Ajustes de seguridad, progreso y resúmenes de aprendizaje, todo desde tu panel.",
  },

  "welcome.cta": { en: "Create Family Account", es: "Crear cuenta familiar" },

  // Auth
  "auth.createTitle": { en: "Create your family account", es: "Crea tu cuenta familiar" },
  "auth.createSubtitle": {
    en: "A few details and your family is ready to begin.",
    es: "Unos pocos datos y tu familia estará lista para comenzar.",
  },
  "auth.signInTitle": { en: "Welcome back", es: "Bienvenido de nuevo" },
  "auth.signInSubtitle": { en: "Sign in to your parent account.", es: "Inicia sesión en tu cuenta de padre." },
  "auth.firstName": { en: "First name", es: "Nombre" },
  "auth.lastName": { en: "Last name", es: "Apellido" },
  "auth.email": { en: "Email address", es: "Correo electrónico" },
  "auth.password": { en: "Password", es: "Contraseña" },
  "auth.confirmPassword": { en: "Confirm password", es: "Confirmar contraseña" },
  "auth.country": { en: "Country", es: "País" },
  "auth.language": { en: "Preferred language", es: "Idioma preferido" },
  "auth.acceptTerms": { en: "I accept the Terms of Service", es: "Acepto los Términos del servicio" },
  "auth.acceptPrivacy": { en: "I accept the Privacy Policy", es: "Acepto la Política de privacidad" },
  "auth.marketing": { en: "Send me occasional learning tips (optional)", es: "Envíenme consejos de aprendizaje (opcional)" },
  "auth.createAccount": { en: "Create account", es: "Crear cuenta" },
  "auth.signIn": { en: "Sign in", es: "Iniciar sesión" },
  "auth.google": { en: "Continue with Google", es: "Continuar con Google" },
  "auth.apple": { en: "Continue with Apple", es: "Continuar con Apple" },
  "auth.or": { en: "or", es: "o" },

  // Verification
  "verify.title": { en: "Check your email", es: "Revisa tu correo" },
  "verify.body": {
    en: "We've sent a verification email. Confirm your address to unlock subscriptions and child accounts.",
    es: "Enviamos un correo de verificación. Confirma tu dirección para activar suscripciones y cuentas infantiles.",
  },
  "verify.open": { en: "Open email app", es: "Abrir correo" },
  "verify.resend": { en: "Resend email", es: "Reenviar correo" },
  "verify.change": { en: "Change email address", es: "Cambiar correo" },

  // Onboarding
  "ob.family.title": { en: "Tell us about your family", es: "Cuéntanos sobre tu familia" },
  "ob.plan.title": { en: "Choose your plan", es: "Elige tu plan" },
  "ob.prefs.title": { en: "What should Ayara focus on?", es: "¿En qué debe enfocarse Ayara?" },
  "ob.safety.title": { en: "Set up safety", es: "Configura la seguridad" },
  "ob.done.title": { en: "Your family is ready!", es: "¡Tu familia está lista!" },
  "ob.done.body": {
    en: "Now let's create your child's learning journey.",
    es: "Ahora creemos el viaje de aprendizaje de tu hijo.",
  },
  "ob.done.cta": { en: "Create child profile", es: "Crear perfil infantil" },

  // Loading lines
  "loading.1": { en: "Preparing your family's adventure…", es: "Preparando la aventura de tu familia…" },
  "loading.2": { en: "Building your child's learning world…", es: "Construyendo el mundo de aprendizaje…" },
  "loading.3": { en: "Almost ready…", es: "Casi listo…" },

  // Errors
  "err.signIn": {
    en: "We couldn't sign you in. Please check your email and password and try again.",
    es: "No pudimos iniciar tu sesión. Revisa tu correo y contraseña e inténtalo de nuevo.",
  },
  "err.offline": {
    en: "We can't reach Ayara right now. Please check your connection.",
    es: "No podemos conectar con Ayara. Revisa tu conexión.",
  },
  "err.generic": {
    en: "Something didn't work as expected. Please try again.",
    es: "Algo no funcionó como esperábamos. Inténtalo de nuevo.",
  },
} satisfies Record<string, Entry>;

export type StringKey = keyof typeof STRINGS;

const STORAGE_KEY = "ayara.lang";

const I18nContext = createContext<{
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (key: StringKey) => string;
} | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (stored === "en" || stored === "es") {
      setLangState(stored);
      document.documentElement.lang = stored;
    }
  }, []);

  const setLang = useCallback((next: Lang) => {
    setLangState(next);
    window.localStorage.setItem(STORAGE_KEY, next);
    document.documentElement.lang = next;
  }, []);

  const t = useCallback((key: StringKey) => STRINGS[key][lang] ?? STRINGS[key].en, [lang]);

  return <I18nContext.Provider value={{ lang, setLang, t }}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const value = useContext(I18nContext);
  if (!value) throw new Error("useI18n must be used within I18nProvider");
  return value;
}
