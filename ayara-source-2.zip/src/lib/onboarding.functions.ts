import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ONBOARDING_STEPS = ["account", "family", "plan", "prefs", "safety", "child", "done"] as const;
export type OnboardingStep = (typeof ONBOARDING_STEPS)[number];

const ParentDetailsSchema = z.object({
  first_name: z.string().trim().min(2).max(40),
  last_name: z.string().trim().min(2).max(40),
  country: z.string().trim().max(60).optional(),
  language: z.enum(["en", "es"]).default("en"),
  marketing_opt_in: z.boolean().default(false),
});

const FamilySchema = z.object({
  name: z.string().trim().max(60).nullish(),
  country: z.string().trim().max(60).nullish(),
  timezone: z.string().trim().max(60).optional(),
  language: z.enum(["en", "es"]).optional(),
  children_count: z.number().int().min(1).max(10).optional(),
  notify_weekly_reports: z.boolean().optional(),
  notify_learning_reminders: z.boolean().optional(),
  notify_achievements: z.boolean().optional(),
  notify_product_updates: z.boolean().optional(),
  learning_goals: z.array(z.string().max(40)).max(12).optional(),
  session_length: z.enum(["10", "20", "30", "45", "no_preference"]).optional(),
  learning_days: z.enum(["weekdays", "weekends", "daily", "custom"]).optional(),
  plan: z.enum(["free", "premium"]).optional(),
  plan_interval: z.enum(["monthly", "annual"]).nullish(),
  trial_started_at: z.string().nullish(),
});

const SafetySchema = z.object({
  daily_minutes: z.number().int().min(10).max(180).optional(),
  allowed_start_hour: z.number().int().min(0).max(23).optional(),
  allowed_end_hour: z.number().int().min(1).max(24).optional(),
  voice_chat_enabled: z.boolean().optional(),
  microphone_enabled: z.boolean().optional(),
  portfolio_sharing_enabled: z.boolean().optional(),
  notifications_enabled: z.boolean().optional(),
  conversation_history_enabled: z.boolean().optional(),
  report_download_enabled: z.boolean().optional(),
});

function clean<T extends Record<string, unknown>>(obj: T) {
  return Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined)) as never;
}

export const getOnboardingState = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const { data: profile } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
    const { data: family } = await supabase.from("families").select("*").eq("owner_id", userId).maybeSingle();
    const { data: safety } = await supabase
      .from("parent_safety_settings")
      .select("*")
      .eq("parent_id", userId)
      .maybeSingle();
    const { count: childCount } = await supabase
      .from("child_profiles")
      .select("id", { count: "exact", head: true })
      .eq("parent_id", userId);

    return { profile, family, safety, childCount: childCount ?? 0 };
  });

export const saveParentDetails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ParentDetailsSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    const fullName = `${data.first_name} ${data.last_name}`.trim();

    const { data: profile, error } = await supabase
      .from("profiles")
      .upsert(
        {
          id: userId,
          email: (claims.email as string) ?? "",
          full_name: fullName,
          first_name: data.first_name,
          last_name: data.last_name,
          country: data.country ?? null,
          language: data.language,
          marketing_opt_in: data.marketing_opt_in,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "id" },
      )
      .select()
      .single();

    if (error) throw new Error(error.message);
    return profile;
  });

export const saveFamily = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => FamilySchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;

    await supabase
      .from("profiles")
      .upsert({ id: userId, email: (claims.email as string) ?? "" }, { onConflict: "id", ignoreDuplicates: true });

    const { data: family, error } = await supabase
      .from("families")
      .upsert(clean({ owner_id: userId, ...data, updated_at: new Date().toISOString() }), { onConflict: "owner_id" })
      .select()
      .single();

    if (error) throw new Error(error.message);

    await supabase.from("profiles").update({ family_id: family.id }).eq("id", userId);
    return family;
  });

export const saveSafetySettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SafetySchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: safety, error } = await context.supabase
      .from("parent_safety_settings")
      .upsert(clean({ parent_id: context.userId, ...data, updated_at: new Date().toISOString() }), { onConflict: "parent_id" })
      .select()
      .single();

    if (error) throw new Error(error.message);
    return safety;
  });

export const setOnboardingStep = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ step: z.enum(ONBOARDING_STEPS) }).parse(input))
  .handler(async ({ data, context }) => {
    const patch = clean({
      onboarding_step: data.step,
      updated_at: new Date().toISOString(),
      onboarding_completed_at: data.step === "done" ? new Date().toISOString() : undefined,
    });

    const { error } = await context.supabase.from("profiles").update(patch).eq("id", context.userId);
    if (error) throw new Error(error.message);
    return { step: data.step };
  });

export const trackOnboardingEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        event: z.string().min(1).max(60),
        metadata: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).default({}),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    await context.supabase
      .from("onboarding_events")
      .insert({ parent_id: context.userId, event: data.event, metadata: data.metadata });
    return { ok: true };
  });
