/**
 * Shared child-session guard for server functions in the child app.
 * Children authenticate with a session cookie, not a Supabase JWT, so these
 * handlers verify the cookie and then act through the admin client.
 */
import { getRequestHeader } from "@tanstack/react-start/server";

const COOKIE_NAME = "ayara_child_session";

function parseCookie(header: string | null | undefined, name: string): string | null {
  if (!header) return null;
  const match = header.match(new RegExp(`(?:^|;)\\s*${name}=([^;]+)`));
  return match?.[1] ?? null;
}

export interface ChildSessionContext {
  childId: string;
  parentId: string;
  child: {
    id: string;
    name: string;
    age: number;
    grade: string | null;
    language: string;
    interests: string[] | null;
  };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  supabaseAdmin: any;
}

export async function requireChildSession(): Promise<ChildSessionContext> {
  const token = parseCookie(getRequestHeader("Cookie"), COOKIE_NAME);
  if (!token) throw new Error("Child login required");

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: session, error: sessionError } = await supabaseAdmin
    .from("child_sessions")
    .select("child_id")
    .eq("token", token)
    .gt("expires_at", new Date().toISOString())
    .single();

  if (sessionError || !session) throw new Error("Child session expired. Please log in again.");

  const { data: child, error: childError } = await supabaseAdmin
    .from("child_profiles")
    .select("id, parent_id, name, age, grade, language, interests")
    .eq("id", session.child_id)
    .single();

  if (childError || !child) throw new Error("Child profile not found");

  return {
    childId: child.id,
    parentId: child.parent_id,
    child: {
      id: child.id,
      name: child.name,
      age: child.age,
      grade: child.grade ?? null,
      language: child.language,
      interests: child.interests ?? null,
    },
    supabaseAdmin,
  };
}
