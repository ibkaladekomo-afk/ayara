/**
 * AYARA age tiers.
 *
 * AYARA starts at 2nd grade — younger children are still learning to read and
 * type, so they are out of scope for now. There are exactly two tiers.
 *
 * A child's experience (tone of voice, mascot presence, avatar set, typing vs
 * voice, visual density) is derived from their grade — or their age when no
 * grade is set. Children still sign in the same way (username + PIN); the tier
 * is read from their profile after login, so there is no "grade login".
 */

export type AgeTierId = "spark" | "forge";

export interface AgeTier {
  id: AgeTierId;
  /** Shown to parents */
  label: string;
  /** Shown to the child */
  childLabel: string;
  gradeRange: string;
  ageRange: string;
  minAge: number;
  maxAge: number;
  /** Mascot behaviour in the child app */
  mascot: "compact" | "minimal";
  /** Primary way the child answers */
  input: "voice-or-type" | "type-first";
  /** Tone used in AI prompts and UI copy */
  tone: string;
  /** Short description for the parent dashboard */
  description: string;
  /** Tailwind classes for the tier badge */
  badgeClass: string;
}

export const AGE_TIERS: Record<AgeTierId, AgeTier> = {
  spark: {
    id: "spark",
    label: "Spark",
    childLabel: "Spark Creator",
    gradeRange: "2–5",
    ageRange: "Ages 7–11",
    minAge: 0,
    maxAge: 11,
    mascot: "compact",
    input: "voice-or-type",
    tone: "Friendly and curious. Short sentences, simple words, asks the child to think first and explains the 'why'.",
    description: "Creative missions, light reading and writing, Aya guides the way and can read everything aloud.",
    badgeClass: "bg-secondary/25 text-foreground",
  },
  forge: {
    id: "forge",
    label: "Forge",
    childLabel: "Forge Innovator",
    gradeRange: "6–8",
    ageRange: "Ages 12–14",
    minAge: 12,
    maxAge: 99,
    mascot: "minimal",
    input: "type-first",
    tone: "Respectful and direct, like a good mentor. No baby talk, real vocabulary, real projects.",
    description: "Project studio, research and build tools, a cleaner and calmer interface.",
    badgeClass: "bg-primary/15 text-primary",
  },
};

export const AGE_TIER_LIST: AgeTier[] = [AGE_TIERS.spark, AGE_TIERS.forge];

/** Grade options offered to parents, mapped to a tier. AYARA starts at 2nd grade. */
export const GRADE_OPTIONS: { value: string; label: string; tier: AgeTierId }[] = [
  { value: "2", label: "2nd grade", tier: "spark" },
  { value: "3", label: "3rd grade", tier: "spark" },
  { value: "4", label: "4th grade", tier: "spark" },
  { value: "5", label: "5th grade", tier: "spark" },
  { value: "6", label: "6th grade", tier: "forge" },
  { value: "7", label: "7th grade", tier: "forge" },
  { value: "8", label: "8th grade", tier: "forge" },
];

export function gradeLabel(grade: string | null | undefined): string | null {
  if (!grade) return null;
  return GRADE_OPTIONS.find((g) => g.value === grade)?.label ?? grade;
}

/** Grade wins when we have it; otherwise fall back to age. */
export function getAgeTier(input: { age?: number | null; grade?: string | null }): AgeTier {
  const byGrade = input.grade ? GRADE_OPTIONS.find((g) => g.value === input.grade) : undefined;
  if (byGrade) return AGE_TIERS[byGrade.tier];
  const age = input.age ?? 9;
  return age <= AGE_TIERS.spark.maxAge ? AGE_TIERS.spark : AGE_TIERS.forge;
}

/** Greeting shown on the child home screen, tuned per tier. */
export function tierGreeting(tier: AgeTierId, name: string): string {
  switch (tier) {
    case "spark":
      return `Hey ${name} — what are we creating today?`;
    case "forge":
    default:
      return `Welcome back, ${name}. Pick where you want to work.`;
  }
}

export function tierSubtitle(tier: AgeTierId): string {
  switch (tier) {
    case "spark":
      return "Talk it out or type it — both work here.";
    case "forge":
    default:
      return "Studios, research tools and build missions. Voice is optional.";
  }
}
