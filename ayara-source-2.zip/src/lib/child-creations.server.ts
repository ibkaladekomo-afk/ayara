/**
 * Server-only helpers for the Ayara Universe (creations that travel worlds).
 *
 * Kept out of the `.functions.ts` wrapper so server-function code splitting
 * never strips a runtime sibling.
 */

import { requireChildSession, type ChildSessionCtx } from "./child-dashboard.server";
import { logChildEvent, awardXp } from "./child-worlds.server";
import { getWorld } from "./worlds";
import { CROSSOVER_XP, CROSSOVER_CRYSTALS, type CreationRecord } from "./creations";

export { requireChildSession, logChildEvent, awardXp };

interface CreationRow {
  id: string;
  name: string;
  kind: string;
  emoji: string;
  origin_world: string;
  traits: unknown;
  summary: string | null;
  created_at: string;
}

function toTraits(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((t): t is string => typeof t === "string").slice(0, 12);
}

/** Every creation the child owns, with the worlds each one has visited. */
export async function listCreations(ctx: ChildSessionCtx): Promise<CreationRecord[]> {
  const [{ data: rows }, { data: appearances }] = await Promise.all([
    ctx.supabaseAdmin
      .from("child_creations")
      .select("id, name, kind, emoji, origin_world, traits, summary, created_at")
      .eq("child_id", ctx.childId)
      .order("created_at", { ascending: false }),
    ctx.supabaseAdmin
      .from("creation_appearances")
      .select("creation_id, world_id")
      .eq("child_id", ctx.childId),
  ]);

  const visits = new Map<string, string[]>();
  for (const a of (appearances ?? []) as { creation_id: string; world_id: string }[]) {
    visits.set(a.creation_id, [...(visits.get(a.creation_id) ?? []), a.world_id]);
  }

  return ((rows ?? []) as CreationRow[]).map((row) => ({
    id: row.id,
    name: row.name,
    kind: row.kind,
    emoji: row.emoji,
    origin_world: row.origin_world,
    traits: toTraits(row.traits),
    summary: row.summary,
    created_at: row.created_at,
    worlds: Array.from(new Set([row.origin_world, ...(visits.get(row.id) ?? [])])),
  }));
}

export async function getCreation(ctx: ChildSessionCtx, id: string): Promise<CreationRecord | null> {
  const all = await listCreations(ctx);
  return all.find((c) => c.id === id) ?? null;
}

export async function insertCreation(
  ctx: ChildSessionCtx,
  input: {
    name: string;
    kind: string;
    emoji?: string;
    origin_world: string;
    traits?: string[];
    summary?: string | null;
    portfolio_item_id?: string | null;
    parent_creation_id?: string | null;
  },
) {
  const { data, error } = await ctx.supabaseAdmin
    .from("child_creations")
    .insert({
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      name: input.name.slice(0, 60),
      kind: input.kind,
      emoji: input.emoji ?? "✨",
      origin_world: input.origin_world,
      traits: input.traits ?? [],
      summary: input.summary ?? null,
      portfolio_item_id: input.portfolio_item_id ?? null,
      parent_creation_id: input.parent_creation_id ?? null,
    })
    .select("id")
    .single();
  if (error) throw new Error(error.message);

  await logChildEvent(ctx, "creation_registered", {
    creation_id: data.id,
    kind: input.kind,
    world_id: input.origin_world,
  });
  return data.id as string;
}

/**
 * Log a creation appearing in a world. The first time a creation leaves the
 * world it was born in, that's a crossover: XP + a Curiosity Crystal.
 */
export async function recordCreationAppearance(
  ctx: ChildSessionCtx,
  input: { creation_id: string; world_id: string; summary?: string | null; conversation_id?: string | null },
) {
  const { data: creation } = await ctx.supabaseAdmin
    .from("child_creations")
    .select("id, name, origin_world")
    .eq("id", input.creation_id)
    .eq("child_id", ctx.childId)
    .maybeSingle();
  if (!creation) throw new Error("Creation not found");

  const { data: existing } = await ctx.supabaseAdmin
    .from("creation_appearances")
    .select("id")
    .eq("creation_id", creation.id)
    .eq("world_id", input.world_id)
    .maybeSingle();

  if (existing) return { alreadyThere: true, xpAwarded: 0, crystals: 0 };

  await ctx.supabaseAdmin.from("creation_appearances").insert({
    creation_id: creation.id,
    child_id: ctx.childId,
    parent_id: ctx.parentId,
    world_id: input.world_id,
    summary: input.summary ?? null,
    conversation_id: input.conversation_id ?? null,
  });

  const isCrossover = input.world_id !== creation.origin_world;
  let xpAwarded = 0;
  let crystals = 0;

  if (isCrossover) {
    await awardXp(ctx, CROSSOVER_XP);
    xpAwarded = CROSSOVER_XP;
    crystals = CROSSOVER_CRYSTALS;
    await addCrystals(ctx, input.world_id, crystals);
    await logChildEvent(ctx, "crossover_completed", {
      creation_id: creation.id,
      world_id: input.world_id,
      from_world: creation.origin_world,
    });
  }

  return { alreadyThere: false, xpAwarded, crystals };
}

async function addCrystals(ctx: ChildSessionCtx, worldId: string, amount: number) {
  await ctx.supabaseAdmin
    .from("child_world_progress")
    .upsert(
      { child_id: ctx.childId, parent_id: ctx.parentId, world_id: worldId },
      { onConflict: "child_id,world_id", ignoreDuplicates: true },
    );
  const { data } = await ctx.supabaseAdmin
    .from("child_world_progress")
    .select("crystals")
    .eq("child_id", ctx.childId)
    .eq("world_id", worldId)
    .maybeSingle();
  await ctx.supabaseAdmin
    .from("child_world_progress")
    .update({ crystals: (data?.crystals ?? 0) + amount })
    .eq("child_id", ctx.childId)
    .eq("world_id", worldId);
}

export function worldName(id: string): string {
  return getWorld(id)?.name ?? id;
}
