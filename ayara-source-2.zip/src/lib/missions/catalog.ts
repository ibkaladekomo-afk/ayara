/**
 * Section 6 — Mission catalog.
 *
 * Pure, deterministic content + helpers shared by the server (assignment)
 * and the browser (rendering). No framework imports.
 */

import type { AgeTierId } from "../age-tiers";

/* ------------------------------------------------------------------ *
 * Mission types
 * ------------------------------------------------------------------ */

export type MissionKind = "daily" | "world" | "weekly" | "family" | "seasonal" | "recovery";

export interface MissionKindMeta {
  id: MissionKind;
  label: string;
  emoji: string;
  blurb: string;
}

export const MISSION_KINDS: MissionKindMeta[] = [
  { id: "daily", label: "Today's mission", emoji: "⚡", blurb: "A short creative challenge for today." },
  { id: "world", label: "World missions", emoji: "🌍", blurb: "Deeper builds inside a learning world." },
  { id: "weekly", label: "Innovation Challenge", emoji: "🏆", blurb: "A bigger project you can build across the week." },
  { id: "family", label: "Family mission", emoji: "👨‍👩‍👧", blurb: "Build it together with a grown-up." },
  { id: "seasonal", label: "Seasonal", emoji: "🎉", blurb: "Only here for a little while." },
  { id: "recovery", label: "Spark Recovery", emoji: "🔁", blurb: "Bring your streak back to life." },
];

export function missionKindMeta(kind: string): MissionKindMeta {
  return MISSION_KINDS.find((k) => k.id === kind) ?? MISSION_KINDS[0]!;
}

/* ------------------------------------------------------------------ *
 * The seven-beat mission journey
 * ------------------------------------------------------------------ */

export type BeatId = "discover" | "understand" | "create" | "improve" | "share" | "reflect" | "celebrate";

export interface BeatDef {
  id: BeatId;
  /** Spark-tier label (grades 2–5) */
  spark: string;
  /** Forge-tier label (grades 6–8) */
  forge: string;
  emoji: string;
}

export const MISSION_BEATS: BeatDef[] = [
  { id: "discover", spark: "Discover", forge: "Discover", emoji: "🔍" },
  { id: "understand", spark: "Figure it out", forge: "Understand", emoji: "🧠" },
  { id: "create", spark: "Make it", forge: "Create", emoji: "✏️" },
  { id: "improve", spark: "Make it better", forge: "Iterate", emoji: "🔧" },
  { id: "share", spark: "Show it", forge: "Ship it", emoji: "📣" },
  { id: "reflect", spark: "Think back", forge: "Reflect", emoji: "🪞" },
  { id: "celebrate", spark: "Celebrate", forge: "Wrap up", emoji: "🎉" },
];

export function beatLabel(beat: BeatDef, tier: AgeTierId): string {
  return tier === "spark" ? beat.spark : beat.forge;
}

export function beatLabels(tier: AgeTierId): string[] {
  return MISSION_BEATS.map((b) => beatLabel(b, tier));
}

/** Mentor prompt for each beat, tuned per tier. */
export function beatPrompt(beat: BeatId, tier: AgeTierId, mission: { title: string; prompt: string }): string {
  const spark = tier === "spark";
  switch (beat) {
    case "discover":
      return mission.prompt;
    case "understand":
      return spark
        ? "Help me understand the tricky part. Explain it like a story, then ask me one question."
        : "Break down what I actually need to know to do this well, then check my understanding.";
    case "create":
      return spark
        ? "I'm ready to make it! Guide me one small step at a time."
        : "I'm building now. Coach me while I make the first real version.";
    case "improve":
      return spark
        ? "Here's my first try. What's one thing I could make even better?"
        : "Critique my first version honestly and help me choose one improvement that matters most.";
    case "share":
      return spark
        ? "Help me describe what I made so I can show someone."
        : "Help me write a short, clear summary of what I built and why it works.";
    case "reflect":
      return spark
        ? "Ask me what my favourite part was and what I'd change next time."
        : "Ask me three reflection questions about this build.";
    case "celebrate":
    default:
      return spark
        ? "Tell me what kind of inventor I'm becoming!"
        : "Give me an honest read on what I got better at with this project.";
  }
}

/* ------------------------------------------------------------------ *
 * Difficulty
 * ------------------------------------------------------------------ */

export type DifficultyId = "gentle" | "core" | "stretch";

export interface DifficultyMeta {
  id: DifficultyId;
  label: string;
  /** Multiplier applied to the template's base XP */
  xpMultiplier: number;
  /** Minutes multiplier */
  timeMultiplier: number;
}

export const DIFFICULTIES: Record<DifficultyId, DifficultyMeta> = {
  gentle: { id: "gentle", label: "Warm-up", xpMultiplier: 0.8, timeMultiplier: 0.8 },
  core: { id: "core", label: "Just right", xpMultiplier: 1, timeMultiplier: 1 },
  stretch: { id: "stretch", label: "Stretch", xpMultiplier: 1.3, timeMultiplier: 1.25 },
};

export interface DifficultySignals {
  tier: AgeTierId;
  missionsCompleted: number;
  worldsCompleted: number;
  missionsAbandoned: number;
  /** Parent safety setting: shorter sessions cap difficulty */
  dailyMinutes?: number | null;
}

/**
 * Adaptive difficulty: challenged, never discouraged. Abandons pull it down,
 * consistent completions push it up, short daily limits cap it.
 */
export function pickDifficulty(signals: DifficultySignals): DifficultyId {
  const { missionsCompleted, missionsAbandoned, worldsCompleted } = signals;
  const attempted = missionsCompleted + missionsAbandoned;
  const abandonRate = attempted > 0 ? missionsAbandoned / attempted : 0;

  if (abandonRate > 0.4 || missionsCompleted < 2) return "gentle";

  const readyToStretch =
    (missionsCompleted >= 10 || worldsCompleted >= 2) && abandonRate < 0.2 && signals.tier === "forge";
  const sparkStretch = missionsCompleted >= 15 && abandonRate < 0.15;

  if ((readyToStretch || sparkStretch) && (signals.dailyMinutes ?? 60) >= 30) return "stretch";
  return "core";
}

/* ------------------------------------------------------------------ *
 * Templates
 * ------------------------------------------------------------------ */

export interface MissionTemplateV2 {
  id: string;
  kind: MissionKind;
  worldId: string;
  title: string;
  /** Opening prompt handed to the mentor at the Discover beat */
  prompt: string;
  minutes: number;
  xp: number;
  crystals: number;
  badge?: string;
  interests: string[];
  tiers: AgeTierId[];
  /** Seasonal windows only */
  season?: { id: string; label: string; startMonth: number; startDay: number; endMonth: number; endDay: number };
  /** Family missions describe the offline part */
  together?: string;
}

export const DAILY_MISSIONS: MissionTemplateV2[] = [
  {
    id: "daily-playground",
    kind: "daily",
    worldId: "art-studio",
    title: "Invent a Playground Nobody Has Built",
    prompt: "Help me invent a brand new playground with one ride that has never existed.",
    minutes: 15,
    xp: 80,
    crystals: 1,
    badge: "creative-builder",
    interests: ["art", "building", "design"],
    tiers: ["spark", "forge"],
  },
  {
    id: "daily-teach-aya",
    kind: "daily",
    worldId: "ai-explorer",
    title: "Teach Aya Something You Learned",
    prompt: "I want to teach you something I learned. Ask me questions until you really get it.",
    minutes: 12,
    xp: 75,
    crystals: 1,
    badge: "curious-questioner",
    interests: ["technology", "ai", "science"],
    tiers: ["spark", "forge"],
  },
  {
    id: "daily-science-hero",
    kind: "daily",
    worldId: "science-lab",
    title: "Create a Superhero Powered by Real Science",
    prompt: "Help me invent a superhero whose powers follow real science rules.",
    minutes: 18,
    xp: 90,
    crystals: 1,
    badge: "science-explorer",
    interests: ["science", "space", "stories"],
    tiers: ["spark", "forge"],
  },
  {
    id: "daily-improve-yesterday",
    kind: "daily",
    worldId: "code-workshop",
    title: "Improve Yesterday's Invention",
    prompt: "Let's take something I already made and make one part of it clearly better.",
    minutes: 15,
    xp: 85,
    crystals: 1,
    badge: "problem-solver",
    interests: ["coding", "robots", "technology"],
    tiers: ["spark", "forge"],
  },
  {
    id: "daily-kind-machine",
    kind: "daily",
    worldId: "code-workshop",
    title: "Design a Machine That Helps Someone",
    prompt: "Help me design a machine that solves a problem for someone in my family.",
    minutes: 16,
    xp: 85,
    crystals: 1,
    badge: "kindness-champion",
    interests: ["robots", "technology", "helping"],
    tiers: ["spark", "forge"],
  },
  {
    id: "daily-unexpected-ending",
    kind: "daily",
    worldId: "story-tree",
    title: "A Story With an Unexpected Ending",
    prompt: "Let's write a short story where the ending surprises everyone.",
    minutes: 14,
    xp: 80,
    crystals: 1,
    badge: "story-weaver",
    interests: ["stories", "reading", "writing"],
    tiers: ["spark", "forge"],
  },
];

export const WORLD_MISSIONS: MissionTemplateV2[] = [
  {
    id: "world-clean-water",
    kind: "world",
    worldId: "science-lab",
    title: "Design an Experiment to Clean Dirty Water",
    prompt: "Help me design a fair experiment that cleans dirty water using things I can find at home.",
    minutes: 22,
    xp: 120,
    crystals: 2,
    badge: "science-explorer",
    interests: ["science", "nature"],
    tiers: ["spark", "forge"],
  },
  {
    id: "world-byte-robot",
    kind: "world",
    worldId: "code-workshop",
    title: "Help Byte Fix a Broken Robot",
    prompt: "Byte's robot keeps walking in circles. Help me debug the instructions step by step.",
    minutes: 20,
    xp: 115,
    crystals: 2,
    badge: "coding-starter",
    interests: ["coding", "robots"],
    tiers: ["spark", "forge"],
  },
  {
    id: "world-twist-story",
    kind: "world",
    worldId: "story-tree",
    title: "The Story Factory Twist",
    prompt: "Help me build a story in the Story Factory where the hero turns out to be wrong.",
    minutes: 20,
    xp: 115,
    crystals: 2,
    badge: "story-weaver",
    interests: ["stories", "writing"],
    tiers: ["spark", "forge"],
  },
  {
    id: "world-impossible-creature",
    kind: "world",
    worldId: "art-studio",
    title: "Draw the Impossible Creature",
    prompt: "Help me design a creature that could only survive on one very strange planet.",
    minutes: 18,
    xp: 110,
    crystals: 2,
    badge: "creative-builder",
    interests: ["art", "animals", "space"],
    tiers: ["spark", "forge"],
  },
  {
    id: "world-ai-mistake",
    kind: "world",
    worldId: "ai-explorer",
    title: "Catch the AI Making a Mistake",
    prompt: "Let's test whether you can be wrong. Help me design checks and catch a real mistake.",
    minutes: 18,
    xp: 110,
    crystals: 2,
    badge: "curious-questioner",
    interests: ["technology", "ai"],
    tiers: ["spark", "forge"],
  },
  {
    id: "world-street-life",
    kind: "world",
    worldId: "nature-trail",
    title: "The Secret Life of Your Street",
    prompt: "Help me investigate and record the living things right outside my home.",
    minutes: 20,
    xp: 110,
    crystals: 2,
    badge: "planet-friend",
    interests: ["nature", "animals"],
    tiers: ["spark", "forge"],
  },
];

export const WEEKLY_CHALLENGES: MissionTemplateV2[] = [
  {
    id: "weekly-smart-city",
    kind: "weekly",
    worldId: "code-workshop",
    title: "Build a Smart City",
    prompt: "I'm building a smart city this week. Help me plan the districts, the tech and the rules.",
    minutes: 90,
    xp: 400,
    crystals: 5,
    badge: "future-inventor",
    interests: ["coding", "technology", "building"],
    tiers: ["spark", "forge"],
  },
  {
    id: "weekly-meal-plan",
    kind: "weekly",
    worldId: "science-lab",
    title: "Create a Healthy Meal Plan With AI",
    prompt: "Help me build a week of healthy meals my family would actually eat, and explain the science.",
    minutes: 80,
    xp: 380,
    crystals: 5,
    badge: "future-inventor",
    interests: ["science", "health", "cooking"],
    tiers: ["spark", "forge"],
  },
  {
    id: "weekly-kindness-campaign",
    kind: "weekly",
    worldId: "story-tree",
    title: "Design a Kindness Campaign for Your School",
    prompt: "Help me design a kindness campaign for my school — name, poster, message and plan.",
    minutes: 85,
    xp: 390,
    crystals: 5,
    badge: "kindness-champion",
    interests: ["stories", "helping", "art"],
    tiers: ["spark", "forge"],
  },
  {
    id: "weekly-board-game",
    kind: "weekly",
    worldId: "art-studio",
    title: "Invent a New Board Game",
    prompt: "Help me invent a board game with real rules, then playtest it with me.",
    minutes: 90,
    xp: 400,
    crystals: 5,
    badge: "creative-builder",
    interests: ["art", "games", "design"],
    tiers: ["spark", "forge"],
  },
];

export const FAMILY_MISSIONS: MissionTemplateV2[] = [
  {
    id: "family-grandparent-invention",
    kind: "family",
    worldId: "story-tree",
    title: "Interview a Grown-Up About an Invention",
    prompt: "Help me prepare questions to interview someone in my family about an invention they remember.",
    together: "Sit down together and record the interview, then tell Aya what you learned.",
    minutes: 30,
    xp: 150,
    crystals: 3,
    badge: "team-player",
    interests: ["stories", "history"],
    tiers: ["spark", "forge"],
  },
  {
    id: "family-recycling-plan",
    kind: "family",
    worldId: "nature-trail",
    title: "Design a Family Recycling Plan",
    prompt: "Help my family design a recycling plan we can actually stick to.",
    together: "Walk through the house together and decide where each bin goes.",
    minutes: 30,
    xp: 150,
    crystals: 3,
    badge: "planet-friend",
    interests: ["nature", "helping"],
    tiers: ["spark", "forge"],
  },
  {
    id: "family-paper-bridge",
    kind: "family",
    worldId: "science-lab",
    title: "Build a Paper Bridge Together",
    prompt: "Help us build the strongest bridge we can out of paper, and explain why it holds.",
    together: "Build it together with paper and tape, then test it with coins.",
    minutes: 35,
    xp: 160,
    crystals: 3,
    badge: "team-player",
    interests: ["science", "building"],
    tiers: ["spark", "forge"],
  },
  {
    id: "family-bedtime-story",
    kind: "family",
    worldId: "story-tree",
    title: "A Bedtime Story From Family Memories",
    prompt: "Help us turn a real family memory into a bedtime story.",
    together: "Read the finished story out loud together.",
    minutes: 25,
    xp: 140,
    crystals: 3,
    badge: "team-player",
    interests: ["stories", "family"],
    tiers: ["spark", "forge"],
  },
];

export const SEASONAL_MISSIONS: MissionTemplateV2[] = [
  {
    id: "seasonal-earth-day",
    kind: "seasonal",
    worldId: "nature-trail",
    title: "Invent a Way to Reduce Waste",
    prompt: "It's Earth Day. Help me invent something that cuts the waste my family makes.",
    minutes: 25,
    xp: 160,
    crystals: 3,
    badge: "planet-friend",
    interests: ["nature", "helping"],
    tiers: ["spark", "forge"],
    season: { id: "earth-day", label: "Earth Day", startMonth: 4, startDay: 15, endMonth: 4, endDay: 30 },
  },
  {
    id: "seasonal-stem-week",
    kind: "seasonal",
    worldId: "science-lab",
    title: "Build a Simple Machine",
    prompt: "It's STEM Week. Help me build a simple machine that makes one chore easier.",
    minutes: 25,
    xp: 160,
    crystals: 3,
    badge: "science-explorer",
    interests: ["science", "building"],
    tiers: ["spark", "forge"],
    season: { id: "stem-week", label: "STEM Week", startMonth: 11, startDay: 1, endMonth: 11, endDay: 14 },
  },
  {
    id: "seasonal-black-history",
    kind: "seasonal",
    worldId: "story-tree",
    title: "An Inventor's Next Invention",
    prompt: "Teach me about a Black inventor, then help me imagine what they'd invent today.",
    minutes: 25,
    xp: 160,
    crystals: 3,
    badge: "future-inventor",
    interests: ["history", "stories", "science"],
    tiers: ["spark", "forge"],
    season: { id: "black-history-month", label: "Black History Month", startMonth: 2, startDay: 1, endMonth: 2, endDay: 28 },
  },
  {
    id: "seasonal-summer-camp",
    kind: "seasonal",
    worldId: "nature-trail",
    title: "Summer Discovery Challenge",
    prompt: "Give me an outdoor exploration challenge for today, then help me record what I find.",
    minutes: 30,
    xp: 170,
    crystals: 3,
    badge: "science-explorer",
    interests: ["nature", "animals"],
    tiers: ["spark", "forge"],
    season: { id: "summer-camp", label: "Summer Discovery Camp", startMonth: 6, startDay: 15, endMonth: 8, endDay: 31 },
  },
];

export const RECOVERY_MISSION: MissionTemplateV2 = {
  id: "recovery-spark",
  kind: "recovery",
  worldId: "art-studio",
  title: "Spark Recovery: Relight Your Streak",
  prompt: "I missed a day. Give me one small, fun creation I can finish right now to get my spark back.",
  minutes: 8,
  xp: 50,
  crystals: 1,
  badge: "comeback",
  interests: [],
  tiers: ["spark", "forge"],
};

export const ALL_TEMPLATES: MissionTemplateV2[] = [
  ...DAILY_MISSIONS,
  ...WORLD_MISSIONS,
  ...WEEKLY_CHALLENGES,
  ...FAMILY_MISSIONS,
  ...SEASONAL_MISSIONS,
  RECOVERY_MISSION,
];

export function getTemplate(id: string): MissionTemplateV2 | undefined {
  return ALL_TEMPLATES.find((t) => t.id === id);
}

/* ------------------------------------------------------------------ *
 * Selection helpers
 * ------------------------------------------------------------------ */

function hash(seed: string): number {
  let h = 0;
  for (const char of seed) h = (h * 31 + char.charCodeAt(0)) % 1000003;
  return h;
}

export function pickFrom(
  pool: MissionTemplateV2[],
  options: { tier: AgeTierId; interests?: string[] | null; seed: string; excludeIds?: string[] },
): MissionTemplateV2 | undefined {
  const interests = (options.interests ?? []).map((i) => i.toLowerCase());
  const exclude = new Set(options.excludeIds ?? []);

  let candidates = pool.filter((t) => t.tiers.includes(options.tier));
  const fresh = candidates.filter((t) => !exclude.has(t.id));
  if (fresh.length > 0) candidates = fresh;
  if (candidates.length === 0) return undefined;

  const matching = candidates.filter((t) => t.interests.some((i) => interests.includes(i)));
  const finalPool = matching.length > 0 ? matching : candidates;
  return finalPool[hash(options.seed) % finalPool.length]!;
}

/** Seasonal missions currently inside their date window. */
export function activeSeasonalMissions(date: Date = new Date()): MissionTemplateV2[] {
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const value = month * 100 + day;
  return SEASONAL_MISSIONS.filter((t) => {
    if (!t.season) return false;
    const start = t.season.startMonth * 100 + t.season.startDay;
    const end = t.season.endMonth * 100 + t.season.endDay;
    return start <= end ? value >= start && value <= end : value >= start || value <= end;
  });
}

/** ISO date (YYYY-MM-DD) of the Monday that starts this mission week. */
export function weekStartISO(today: string): string {
  const date = new Date(`${today}T00:00:00Z`);
  const day = date.getUTCDay(); // 0 = Sunday
  const diff = day === 0 ? 6 : day - 1;
  date.setUTCDate(date.getUTCDate() - diff);
  return date.toISOString().slice(0, 10);
}

/** Apply difficulty scaling to a template's rewards. */
export function scaleTemplate(template: MissionTemplateV2, difficulty: DifficultyId) {
  const meta = DIFFICULTIES[difficulty];
  return {
    xp: Math.round(template.xp * meta.xpMultiplier),
    minutes: Math.max(5, Math.round(template.minutes * meta.timeMultiplier)),
    crystals: template.crystals,
  };
}
