/**
 * Section 6 — Reward rules.
 *
 * XP, Curiosity Crystals, badges and the cosmetic coin shop. Rewards are for
 * thinking, making, revising and reflecting — never for showing up.
 */

export type XpReason =
  | "mission_completed"
  | "creation_made"
  | "revision_made"
  | "reflection_completed"
  | "mentor_helped"
  | "family_collaboration"
  | "discovery_found";

export interface XpRule {
  reason: XpReason;
  label: string;
  xp: number;
  crystals: number;
}

/** Bonus XP on top of the mission's own reward. */
export const XP_RULES: Record<XpReason, XpRule> = {
  mission_completed: { reason: "mission_completed", label: "Finished a mission", xp: 0, crystals: 0 },
  creation_made: { reason: "creation_made", label: "Made something original", xp: 40, crystals: 1 },
  revision_made: { reason: "revision_made", label: "Improved your own work", xp: 35, crystals: 1 },
  reflection_completed: { reason: "reflection_completed", label: "Reflected on your learning", xp: 25, crystals: 0 },
  mentor_helped: { reason: "mentor_helped", label: "Helped your mentor", xp: 20, crystals: 1 },
  family_collaboration: { reason: "family_collaboration", label: "Built it with your family", xp: 50, crystals: 2 },
  discovery_found: { reason: "discovery_found", label: "Found a hidden discovery", xp: 15, crystals: 1 },
};

/* ------------------------------------------------------------------ *
 * Premium Coins — cosmetics only, never academic advantage
 * ------------------------------------------------------------------ */

export type ShopCategory = "avatar" | "theme" | "portfolio";

export interface ShopItem {
  id: string;
  category: ShopCategory;
  name: string;
  emoji: string;
  description: string;
  coins: number;
}

export const SHOP_CATEGORIES: { id: ShopCategory; label: string; blurb: string }[] = [
  { id: "avatar", label: "Avatar items", blurb: "Style your explorer." },
  { id: "theme", label: "Theme packs", blurb: "Change how your studio looks." },
  { id: "portfolio", label: "Portfolio decorations", blurb: "Dress up your creations." },
];

export const SHOP_ITEMS: ShopItem[] = [
  { id: "avatar-astro-helmet", category: "avatar", name: "Astro Helmet", emoji: "🪐", description: "A helmet built for zero gravity.", coins: 30 },
  { id: "avatar-inventor-goggles", category: "avatar", name: "Inventor Goggles", emoji: "🥽", description: "For very bright ideas.", coins: 25 },
  { id: "avatar-cape", category: "avatar", name: "Idea Cape", emoji: "🦸", description: "Flutters when you invent.", coins: 35 },
  { id: "theme-midnight-lab", category: "theme", name: "Midnight Lab", emoji: "🌌", description: "Deep blues for late-night building.", coins: 50 },
  { id: "theme-sunrise-studio", category: "theme", name: "Sunrise Studio", emoji: "🌅", description: "Warm morning colours.", coins: 50 },
  { id: "theme-forest-workshop", category: "theme", name: "Forest Workshop", emoji: "🌲", description: "Green, calm and focused.", coins: 50 },
  { id: "portfolio-gold-frame", category: "portfolio", name: "Gold Frame", emoji: "🖼️", description: "Frame a creation you're proud of.", coins: 20 },
  { id: "portfolio-star-stickers", category: "portfolio", name: "Star Stickers", emoji: "⭐", description: "Sprinkle stars on your projects.", coins: 15 },
  { id: "portfolio-constellation", category: "portfolio", name: "Constellation Backdrop", emoji: "✨", description: "A night sky behind your work.", coins: 40 },
];

export function getShopItem(id: string): ShopItem | undefined {
  return SHOP_ITEMS.find((i) => i.id === id);
}

/* ------------------------------------------------------------------ *
 * Reflection prompts
 * ------------------------------------------------------------------ */

export const REFLECTION_QUESTIONS = [
  { field: "favorite_part" as const, spark: "What was your favourite part?", forge: "What was the best part of this build?" },
  { field: "would_improve" as const, spark: "What would you make better next time?", forge: "What would you improve in the next version?" },
  { field: "surprised_by" as const, spark: "What surprised you?", forge: "What surprised you or changed your thinking?" },
];

/* ------------------------------------------------------------------ *
 * Celebration triggers
 * ------------------------------------------------------------------ */

export interface CelebrationDef {
  key: string;
  title: string;
  message: string;
}

export const CELEBRATIONS: Record<string, CelebrationDef> = {
  first_mission: { key: "first_mission", title: "Your first mission!", message: "You finished something you started. That's how every inventor begins." },
  first_portfolio: { key: "first_portfolio", title: "First project saved", message: "Your Portfolio has its very first creation in it." },
  xp_100: { key: "xp_100", title: "100 XP", message: "One hundred points of pure thinking and making." },
  level_up: { key: "level_up", title: "New Innovation Level", message: "You've grown into a new level. New things just opened up." },
  weekly_done: { key: "weekly_done", title: "Innovation Challenge complete", message: "You carried a big project all the way to the finish." },
  family_done: { key: "family_done", title: "Family mission complete", message: "You built something together. That counts double." },
  streak_restored: { key: "streak_restored", title: "Spark restored", message: "You came back. That's persistence, and it matters more than perfection." },
};
