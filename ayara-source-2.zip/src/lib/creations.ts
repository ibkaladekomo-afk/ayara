/**
 * The Ayara Universe.
 *
 * Everything a child makes is a *Creation* that can travel between worlds: a
 * robot built in Code Garage can star in a Story Factory story, a plant from
 * Discovery Forest can power an Art Studio piece. Creations carry their own
 * name, traits and history, so mentors can greet them by name and never
 * contradict what came before.
 */

export type CreationKind =
  | "character"
  | "creature"
  | "invention"
  | "place"
  | "story"
  | "specimen"
  | "artwork";

export interface CreationKindMeta {
  id: CreationKind;
  label: string;
  emoji: string;
}

export const CREATION_KINDS: CreationKindMeta[] = [
  { id: "character", label: "Character", emoji: "🧑‍🚀" },
  { id: "creature", label: "Creature", emoji: "🐉" },
  { id: "invention", label: "Invention", emoji: "🤖" },
  { id: "place", label: "Place", emoji: "🏙️" },
  { id: "story", label: "Story", emoji: "📖" },
  { id: "specimen", label: "Specimen", emoji: "🌱" },
  { id: "artwork", label: "Artwork", emoji: "🎨" },
];

export function creationKindMeta(kind: string): CreationKindMeta {
  return CREATION_KINDS.find((k) => k.id === kind) ?? { id: "invention", label: "Creation", emoji: "✨" };
}

/** What a world naturally produces, used when a master project registers a creation. */
export const WORLD_DEFAULT_KIND: Record<string, CreationKind> = {
  "science-lab": "specimen",
  "story-tree": "story",
  "art-studio": "artwork",
  "code-workshop": "invention",
  "ai-explorer": "invention",
  "nature-trail": "specimen",
};

/**
 * The crossover prompt: what this world does with a creation that was born
 * somewhere else. Keyed by world, then by the kind of thing arriving.
 */
const CROSSOVERS: Record<string, Partial<Record<CreationKind, string>> & { default: string }> = {
  "science-lab": {
    default: "Let's run a real experiment on {name}. Help me form a hypothesis and test it.",
    character: "Let's study {name} scientifically — how would they survive in three different environments?",
    creature: "Let's classify {name} like a scientist: habitat, diet, adaptations. Then test one idea.",
    invention: "Let's test whether {name} would actually work. Help me design the experiment.",
    specimen: "Let's take {name} further with a proper experiment.",
  },
  "story-tree": {
    default: "Let's write a story where {name} is the hero.",
    invention: "Let's write a story where {name} is switched on for the very first time.",
    creature: "Let's write the day the world first met {name}.",
    specimen: "Let's write a story about the day someone discovered {name}.",
    artwork: "Let's write the story hidden inside {name}.",
  },
  "art-studio": {
    default: "Let's design and illustrate {name}. Coach me through it.",
    story: "Let's illustrate the biggest moment from {name}.",
    invention: "Let's draw the official blueprint poster for {name}.",
    creature: "Let's draw {name} in its natural habitat.",
  },
  "code-workshop": {
    default: "Let's build a mini-game where {name} is the main character.",
    invention: "Let's write the code that makes {name} actually do something.",
    creature: "Let's code a game where you have to help {name} survive.",
    place: "Let's build a small game set inside {name}.",
  },
  "ai-explorer": {
    default: "Let's investigate what an AI would get right — and wrong — about {name}.",
    invention: "Let's work out which part of {name} should use AI, and which part shouldn't.",
    story: "Let's fact-check the world of {name} and see what's real.",
  },
  "nature-trail": {
    default: "Let's find out where {name} would live in the real natural world.",
    creature: "Let's compare {name} to real animals and see what it borrowed from nature.",
    invention: "Let's find the plant or animal that {name} could copy to work better.",
  },
};

/** The mission prompt used when a child carries a creation into a world. */
export function crossoverPrompt(worldId: string, kind: string, name: string): string {
  const table = CROSSOVERS[worldId];
  const template =
    (table?.[kind as CreationKind] as string | undefined) ?? table?.default ?? "Let's keep building {name} here.";
  return template.replaceAll("{name}", name);
}

/** The invitation shown on a world home screen. */
export function crossoverInvite(worldId: string, kind: string, name: string, tier: "spark" | "forge"): string {
  const line = crossoverPrompt(worldId, kind, name);
  return tier === "spark" ? `Bring ${name} along! ${line}` : `Carry ${name} in — ${line}`;
}

export interface UniverseMilestone {
  id: string;
  label: string;
  detail: string;
  emoji: string;
  reached: (stats: { creations: number; crossovers: number; maxWorlds: number }) => boolean;
}

export const UNIVERSE_MILESTONES: UniverseMilestone[] = [
  {
    id: "first-creation",
    label: "Universe started",
    detail: "You made your first creation.",
    emoji: "🌱",
    reached: (s) => s.creations >= 1,
  },
  {
    id: "first-crossover",
    label: "First crossover",
    detail: "One of your creations travelled to another world.",
    emoji: "🌉",
    reached: (s) => s.crossovers >= 1,
  },
  {
    id: "three-worlds",
    label: "Well travelled",
    detail: "A single creation has appeared in three worlds.",
    emoji: "🧭",
    reached: (s) => s.maxWorlds >= 3,
  },
  {
    id: "ten-creations",
    label: "A real universe",
    detail: "Ten creations now live in your universe.",
    emoji: "🌌",
    reached: (s) => s.creations >= 10,
  },
];

/** XP for taking a creation somewhere new, and the crystal for the first crossover. */
export const CROSSOVER_XP = 40;
export const CROSSOVER_CRYSTALS = 1;

export interface CreationRecord {
  id: string;
  name: string;
  kind: string;
  emoji: string;
  origin_world: string;
  traits: string[];
  summary: string | null;
  created_at: string;
  worlds: string[];
}

/** Compact universe context handed to the mentor so it never contradicts itself. */
export function creationBriefing(creation: {
  name: string;
  kind: string;
  traits: string[];
  summary?: string | null;
  originWorldName: string;
  worldNames: string[];
}): string {
  const parts = [
    `The child has brought a creation of their own into this world: "${creation.name}" (a ${creation.kind}), first made in ${creation.originWorldName}.`,
  ];
  if (creation.traits.length) parts.push(`Known traits: ${creation.traits.join(", ")}.`);
  if (creation.summary) parts.push(`What it is: ${creation.summary}`);
  if (creation.worldNames.length) parts.push(`It has already visited: ${creation.worldNames.join(", ")}.`);
  parts.push(
    "Greet it by name, treat it as real and established, never contradict these facts, and shape this session around developing it further in your world.",
  );
  return parts.join(" ");
}
