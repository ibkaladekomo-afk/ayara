import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const CreateConversationSchema = z.object({
  child_id: z.string().uuid(),
  title: z.string().max(100).optional(),
});

export const listConversations = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("conversations")
      .select("*")
      .eq("parent_id", context.userId)
      .order("updated_at", { ascending: false });

    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => CreateConversationSchema.parse(input))
  .handler(async ({ data, context }) => {
    const insert = {
      child_id: data.child_id,
      title: data.title ?? null,
      parent_id: context.userId,
    };
    const { data: conversation, error } = await context.supabase
      .from("conversations")
      .insert(insert)
      .select()
      .single();

    if (error) throw new Error(error.message);
    return conversation;
  });

export const getConversationWithMessages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: conversation, error: convError } = await context.supabase
      .from("conversations")
      .select("*")
      .eq("id", data.id)
      .eq("parent_id", context.userId)
      .single();

    if (convError) throw new Error(convError.message);

    const { data: messages, error: msgError } = await context.supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", data.id)
      .order("created_at", { ascending: true });

    if (msgError) throw new Error(msgError.message);

    return { conversation, messages: messages ?? [] };
  });
