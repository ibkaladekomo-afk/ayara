import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  requireChildSession,
  requireWorld,
  ensureWorldProgress,
  awardXp,
  grantBadge,
  logChildEvent,
  worldCompletion,
} from "./child-worlds.server";

const WorldInput = z.object({ world_id: z.string().min(1).max(60) });

/** Everything a world home screen renders in one round trip. */
export const getMyWorld = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WorldInput.parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const world = requireWorld(data.world_id);
    const progress = await ensureWorldProgress(ctx, world.id);

    const [discoveries, missions, portfolio, badges] = await Promise.all([
      ctx.supabaseAdmin
        .from("child_discoveries")
        .select("discovery_id, found_at")
        .eq("child_id", ctx.childId)
        .eq("world_id", world.id),
      ctx.supabaseAdmin
        .from("child_missions")
        .select("*")
        .eq("child_id", ctx.childId)
        .eq("world_id", world.id)
        .neq("status", "completed")
        .order("assigned_on", { ascending: false })
        .limit(3),
      ctx.supabaseAdmin
        .from("portfolio_items")
        .select("id, kind, title, created_at")
        .eq("child_id", ctx.childId)
        .eq("world_id", world.id)
        .order("created_at", { ascending: false })
        .limit(4),
      ctx.supabaseAdmin.from("child_badges").select("badge_id").eq("child_id", ctx.childId),
    ]);

    return {
      child: { id: ctx.child.id, name: ctx.child.name, age: ctx.child.age, grade: ctx.child.grade, avatar: ctx.child.avatar },
      worldId: world.id,
      stageIndex: progress?.stage_index ?? 0,
      completedStages: (progress?.completed_stages ?? []) as string[],
      completion: worldCompletion(world, progress?.completed_stages),
      crystals: progress?.crystals ?? 0,
      masterProjectStatus: (progress?.master_project_status ?? "not_started") as string,
      enteredCount: progress?.entered_count ?? 0,
      discoveries: (discoveries.data ?? []).map((d: { discovery_id: string }) => d.discovery_id),
      openMissions: missions.data ?? [],
      portfolio: portfolio.data ?? [],
      badges: (badges.data ?? []).map((b: { badge_id: string }) => b.badge_id),
    };
  });

/** Child walked into a world — used for the welcome animation and analytics. */
export const enterWorld = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WorldInput.parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const world = requireWorld(data.world_id);
    const progress = await ensureWorldProgress(ctx, world.id);

    await ctx.supabaseAdmin
      .from("child_world_progress")
      .update({
        entered_count: (progress?.entered_count ?? 0) + 1,
        last_entered_at: new Date().toISOString(),
      })
      .eq("child_id", ctx.childId)
      .eq("world_id", world.id);

    await ctx.supabaseAdmin
      .from("child_world_unlocks")
      .upsert(
        { child_id: ctx.childId, parent_id: ctx.parentId, world_id: world.id },
        { onConflict: "child_id,world_id", ignoreDuplicates: true },
      );

    await logChildEvent(ctx, "world_entered", { world_id: world.id, visit: (progress?.entered_count ?? 0) + 1 });

    return { firstVisit: (progress?.entered_count ?? 0) === 0 };
  });

export const exitWorld = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WorldInput.extend({ seconds: z.number().int().min(0).max(86_400).optional() }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    await logChildEvent(ctx, "world_exited", { world_id: data.world_id, seconds: data.seconds ?? null });
    return { ok: true };
  });

/** Finish a learning-path stage: award XP and unlock the next stage. */
export const completeStage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WorldInput.extend({ stage_id: z.string().min(1).max(40) }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const world = requireWorld(data.world_id);
    const stage = world.stages.find((s) => s.id === data.stage_id);
    if (!stage) throw new Error("That stage isn't part of this world.");

    const progress = await ensureWorldProgress(ctx, world.id);
    const completed: string[] = (progress?.completed_stages ?? []) as string[];
    if (completed.includes(stage.id)) {
      return { alreadyDone: true, xpAwarded: 0, completion: worldCompletion(world, completed), leveledUp: false, level: null };
    }

    const nextCompleted = [...completed, stage.id];
    const index = world.stages.findIndex((s) => s.id === stage.id);

    await ctx.supabaseAdmin
      .from("child_world_progress")
      .update({
        completed_stages: nextCompleted,
        stage_index: Math.min(index + 1, world.stages.length - 1),
      })
      .eq("child_id", ctx.childId)
      .eq("world_id", world.id);

    const award = await awardXp(ctx, stage.xp);
    await logChildEvent(ctx, "stage_completed", { world_id: world.id, stage_id: stage.id, xp: stage.xp });

    return {
      alreadyDone: false,
      xpAwarded: award.xpAwarded,
      leveledUp: award.leveledUp,
      level: award.level,
      completion: worldCompletion(world, nextCompleted),
    };
  });

/** A hidden discovery was found — never required, always rewarded. */
export const recordDiscovery = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WorldInput.extend({ discovery_id: z.string().min(1).max(60) }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const world = requireWorld(data.world_id);
    const discovery = world.discoveries.find((d) => d.id === data.discovery_id);
    if (!discovery) throw new Error("Nothing hidden there.");

    const { data: existing } = await ctx.supabaseAdmin
      .from("child_discoveries")
      .select("id")
      .eq("child_id", ctx.childId)
      .eq("discovery_id", discovery.id)
      .maybeSingle();

    if (existing) return { alreadyFound: true, crystals: 0, reveal: discovery.reveal };

    await ctx.supabaseAdmin.from("child_discoveries").insert({
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      world_id: world.id,
      discovery_id: discovery.id,
    });

    const progress = await ensureWorldProgress(ctx, world.id);
    await ctx.supabaseAdmin
      .from("child_world_progress")
      .update({ crystals: (progress?.crystals ?? 0) + discovery.crystals })
      .eq("child_id", ctx.childId)
      .eq("world_id", world.id);

    await logChildEvent(ctx, "discovery_found", { world_id: world.id, discovery_id: discovery.id });

    return { alreadyFound: false, crystals: discovery.crystals, reveal: discovery.reveal };
  });

export const startMasterProject = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => WorldInput.parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const world = requireWorld(data.world_id);
    await ensureWorldProgress(ctx, world.id);
    await ctx.supabaseAdmin
      .from("child_world_progress")
      .update({ master_project_status: "in_progress" })
      .eq("child_id", ctx.childId)
      .eq("world_id", world.id);
    await logChildEvent(ctx, "master_project_started", { world_id: world.id });
    return { ok: true };
  });

/** Save the Master Project to the portfolio with a certificate, badge and XP. */
export const submitMasterProject = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    WorldInput.extend({
      title: z.string().min(1).max(120).optional(),
      summary: z.string().min(1).max(4000),
    }).parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const world = requireWorld(data.world_id);
    const project = world.masterProject;
    const progress = await ensureWorldProgress(ctx, world.id);

    if (progress?.master_project_status === "completed") {
      return { alreadyDone: true, xpAwarded: 0, certificate: project.certificate, itemId: progress.master_project_item_id };
    }

    const { data: item, error } = await ctx.supabaseAdmin
      .from("portfolio_items")
      .insert({
        child_id: ctx.childId,
        parent_id: ctx.parentId,
        kind: "master_project",
        title: data.title ?? project.title,
        world_id: world.id,
        content: {
          summary: data.summary,
          certificate: project.certificate,
          mentor: world.character,
          world: world.name,
        },
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);

    const completed: string[] = (progress?.completed_stages ?? []) as string[];
    const nextCompleted = completed.includes("master") ? completed : [...completed, "master"];

    await ctx.supabaseAdmin
      .from("child_world_progress")
      .update({
        master_project_status: "completed",
        master_project_item_id: item.id,
        completed_stages: nextCompleted,
        stage_index: world.stages.length - 1,
      })
      .eq("child_id", ctx.childId)
      .eq("world_id", world.id);

    // Register the finished project as a creation in the child's Ayara Universe.
    let creationId: string | null = null;
    try {
      const { insertCreation } = await import("./child-creations.server");
      const { WORLD_DEFAULT_KIND, creationKindMeta } = await import("./creations");
      const kind = WORLD_DEFAULT_KIND[world.id] ?? "invention";
      creationId = await insertCreation(ctx, {
        name: data.title ?? project.title,
        kind,
        emoji: creationKindMeta(kind).emoji,
        origin_world: world.id,
        summary: data.summary,
        portfolio_item_id: item.id as string,
      });
    } catch {
      creationId = null;
    }

    if (project.badge) await grantBadge(ctx, project.badge);
    const award = await awardXp(ctx, project.xp);
    await logChildEvent(ctx, "master_project_completed", { world_id: world.id, xp: project.xp });

    return {
      alreadyDone: false,
      xpAwarded: award.xpAwarded,
      leveledUp: award.leveledUp,
      level: award.level,
      certificate: project.certificate,
      badge: project.badge ?? null,
      itemId: item.id as string,
      creationId,
      completion: worldCompletion(world, nextCompleted),
    };
  });
