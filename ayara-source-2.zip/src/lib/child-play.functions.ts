import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getRequestHeader } from "@tanstack/react-start/server";

const COOKIE_NAME = "ayara_child_session";

function parseCookie(header: string | null | undefined, name: string): string | null {
  if (!header) return null;
  const match = header.match(new RegExp(`(?:^|;)\\s*${name}=([^;]+)`));
  return match?.[1] ?? null;
}

async function requireChildSession(): Promise<{
  childId: string;
  parentId: string;
  supabaseAdmin: any;
}> {
  const token = parseCookie(getRequestHeader("Cookie"), COOKIE_NAME);
  if (!token) throw new Error("Child login required");

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: session, error: sessionError } = await supabaseAdmin
    .from("child_sessions")
    .select("child_id")
    .eq("token", token)
    .gt("expires_at", new Date().toISOString())
    .single();

  if (sessionError || !session) throw new Error("Child session expired. Please log in again.");

  const { data: child, error: childError } = await supabaseAdmin
    .from("child_profiles")
    .select("id, parent_id")
    .eq("id", session.child_id)
    .single();

  if (childError || !child) throw new Error("Child profile not found");

  return { childId: child.id, parentId: child.parent_id, supabaseAdmin };
}

export const listMyConversations = createServerFn({ method: "GET" })
  .handler(async () => {
    const { childId, supabaseAdmin } = await requireChildSession();
    const { data, error } = await supabaseAdmin
      .from("conversations")
      .select("*")
      .eq("child_id", childId)
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const CreateConversationSchema = z.object({
  child_id: z.string().uuid(),
  title: z.string().max(100).optional(),
});

export const createMyConversation = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => CreateConversationSchema.parse(input))
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    if (data.child_id !== childId) throw new Error("Conversation must be for the logged-in child");

    const { data: conversation, error } = await supabaseAdmin
      .from("conversations")
      .insert({ child_id: childId, parent_id: parentId, title: data.title ?? null })
      .select()
      .single();

    if (error) throw new Error(error.message);
    return conversation;
  });

export const getMyConversationWithMessages = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { childId, supabaseAdmin } = await requireChildSession();

    const { data: conversation, error: convError } = await supabaseAdmin
      .from("conversations")
      .select("*")
      .eq("id", data.id)
      .eq("child_id", childId)
      .single();

    if (convError) throw new Error(convError.message);

    const { data: messages, error: msgError } = await supabaseAdmin
      .from("messages")
      .select("*")
      .eq("conversation_id", data.id)
      .order("created_at", { ascending: true });

    if (msgError) throw new Error(msgError.message);

    return { conversation, messages: messages ?? [] };
  });

const SaveMessageSchema = z.object({
  conversation_id: z.string().uuid(),
  role: z.enum(["user", "assistant", "system"]),
  content: z.string().min(1),
});

export const saveMyMessage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => SaveMessageSchema.parse(input))
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();

    const { data: conversation, error: convError } = await supabaseAdmin
      .from("conversations")
      .select("id")
      .eq("id", data.conversation_id)
      .eq("child_id", childId)
      .single();

    if (convError || !conversation) {
      throw new Error("Conversation not found or access denied");
    }

    const { data: message, error } = await supabaseAdmin
      .from("messages")
      .insert(data)
      .select()
      .single();

    if (error) throw new Error(error.message);

    // Safety screening: anything sensitive the child says raises an alert for
    // the parent. Never blocks the child's own flow.
    let safety: { category: string; severity: string; reason: string } | null = null;
    if (data.role === "user") {
      try {
        const { screenChildMessage, excerptFor } = await import("@/lib/safety-screen.server");
        const match = screenChildMessage(data.content);
        if (match) {
          safety = match;
          await supabaseAdmin.from("safety_alerts").insert({
            parent_id: parentId,
            child_id: childId,
            conversation_id: data.conversation_id,
            category: match.category,
            severity: match.severity,
            excerpt: excerptFor(data.content),
            ayara_response: match.reason,
          });
        }
      } catch {
        // screening must never break the child's mission
      }
    }

    return { ...message, safety };
  });


