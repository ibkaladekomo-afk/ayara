/**
 * Server-only helpers for the child Home Dashboard.
 *
 * Kept out of the `.functions.ts` wrapper so server-function code splitting
 * never strips a runtime sibling.
 */

import { getRequestHeader } from "@tanstack/react-start/server";
import { getLevelInfo, MISSION_TEMPLATES } from "./dashboard-content";

const COOKIE_NAME = "ayara_child_session";

function parseCookie(header: string | null | undefined, name: string): string | null {
  if (!header) return null;
  const match = header.match(new RegExp(`(?:^|;)\\s*${name}=([^;]+)`));
  return match?.[1] ?? null;
}

export interface ChildSessionCtx {
  childId: string;
  parentId: string;
  child: any;
  supabaseAdmin: any;
}

export async function requireChildSession(): Promise<ChildSessionCtx> {
  const token = parseCookie(getRequestHeader("Cookie"), COOKIE_NAME);
  if (!token) throw new Error("Child login required");

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: session, error: sessionError } = await supabaseAdmin
    .from("child_sessions")
    .select("child_id")
    .eq("token", token)
    .gt("expires_at", new Date().toISOString())
    .single();
  if (sessionError || !session) throw new Error("Child session expired. Please log in again.");

  const { data: child, error: childError } = await supabaseAdmin
    .from("child_profiles")
    .select("id, parent_id, name, age, grade, language, interests, avatar, avatar_config")
    .eq("id", session.child_id)
    .single();
  if (childError || !child) throw new Error("Child profile not found");

  return { childId: child.id, parentId: child.parent_id, child, supabaseAdmin };
}

export function todayISO(offsetMinutes = 0): string {
  const now = new Date(Date.now() - offsetMinutes * 60_000);
  return now.toISOString().slice(0, 10);
}

function daysBetween(a: string, b: string): number {
  const ms = Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`);
  return Math.round(ms / 86_400_000);
}

/**
 * Innovation streak with a one-day grace period ("Spark Recovery"): missing a
 * single day doesn't wipe the streak, it offers a comeback instead.
 */
export async function touchStreak(ctx: ChildSessionCtx, today: string) {
  const { supabaseAdmin, childId, parentId } = ctx;

  await supabaseAdmin
    .from("child_progress")
    .upsert({ child_id: childId, parent_id: parentId }, { onConflict: "child_id", ignoreDuplicates: true });

  const { data: progress } = await supabaseAdmin
    .from("child_progress")
    .select("*")
    .eq("child_id", childId)
    .maybeSingle();

  const last: string | null = progress?.last_active_on ?? null;
  let streak: number = progress?.streak_days ?? 0;
  let recovered = false;
  let graceUsedOn: string | null = progress?.grace_used_on ?? null;

  if (!last) {
    streak = 1;
  } else if (last === today) {
    streak = Math.max(1, streak);
  } else {
    const gap = daysBetween(last, today);
    if (gap === 1) {
      streak = streak + 1;
    } else if (gap === 2 && graceUsedOn !== today) {
      // One missed day — keep the streak alive, mark the grace as spent.
      streak = streak + 1;
      graceUsedOn = today;
      recovered = true;
    } else {
      streak = 1;
    }
  }

  const { data: updated } = await supabaseAdmin
    .from("child_progress")
    .update({ streak_days: streak, last_active_on: today, grace_used_on: graceUsedOn })
    .eq("child_id", childId)
    .select()
    .maybeSingle();

  return { progress: updated ?? progress, recovered };
}

/** One assigned mission per child per day, personalised by tier + interests. */
export async function ensureTodayMission(ctx: ChildSessionCtx, today: string) {
  const { ensureDailyMission, difficultyFor } = await import("./missions.server");
  const difficulty = await difficultyFor(ctx);
  return ensureDailyMission(ctx, today, difficulty);
}


export function missionSteps(worldId: string, title: string): string[] {
  return (
    MISSION_TEMPLATES.find((m) => m.worldId === worldId && m.title === title)?.steps ?? [
      "Start",
      "Explore",
      "Create",
      "Share",
    ]
  );
}

export function levelFromXp(xp: number) {
  return getLevelInfo(xp);
}
