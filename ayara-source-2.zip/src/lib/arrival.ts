/**
 * First-run "arrival" — the child's first five minutes in AYARA.
 *
 * Deliberately cinematic and remembered, not an account setup step.
 * Completion is stored per child in this browser; parents can never be
 * locked out of it and children can replay it any time.
 */

const KEY = (childId: string) => `ayara.arrival.${childId}`;

export interface ArrivalRecord {
  completedAt: string;
  /** The child's chosen "why I'm here" — used to warm up the home screen. */
  spark?: string;
}

export function readArrival(childId: string): ArrivalRecord | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(KEY(childId));
    return raw ? (JSON.parse(raw) as ArrivalRecord) : null;
  } catch {
    return null;
  }
}

export function completeArrival(childId: string, spark?: string) {
  if (typeof window === "undefined") return;
  try {
    const record: ArrivalRecord = { completedAt: new Date().toISOString(), ...(spark ? { spark } : {}) };
    window.localStorage.setItem(KEY(childId), JSON.stringify(record));
  } catch {
    // storage blocked — the intro simply plays again next time
  }
}

export function resetArrival(childId: string) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(KEY(childId));
  } catch {
    /* noop */
  }
}

/** The three "sparks" a Spark-tier child picks from. */
export const SPARK_CHOICES = [
  { id: "create", emoji: "🎨", label: "Make things", line: "You're a maker. Let's build wild, beautiful things." },
  { id: "discover", emoji: "🔭", label: "Find things out", line: "You're an explorer. Let's chase the big questions." },
  { id: "build", emoji: "🤖", label: "Build machines", line: "You're an inventor. Let's make things that move and think." },
] as const;

/** Forge-tier focus tracks. */
export const FORGE_TRACKS = [
  { id: "research", label: "Research", line: "Find what's true, then prove it." },
  { id: "engineer", label: "Engineering", line: "Design it, build it, break it, fix it." },
  { id: "design", label: "Design", line: "Make it work — then make it matter." },
  { id: "story", label: "Storytelling", line: "Ideas travel further when they're told well." },
] as const;
