import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getRequestHeader, setResponseHeader } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const COOKIE_NAME = "ayara_child_session";
const SESSION_DAYS = 7;

function parseCookie(header: string | null | undefined, name: string): string | null {
  if (!header) return null;
  const match = header.match(new RegExp(`(?:^|;)\\s*${name}=([^;]+)`));
  return match?.[1] ?? null;
}

const LoginSchema = z.object({
  username: z.string().min(1).max(50).transform((v) => v.trim().toLowerCase()),
  pin: z.string().transform((v) => v.trim()).pipe(z.string().min(4).max(6)),
});

export const loginChild = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => LoginSchema.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { verifyPin } = await import("@/lib/pin.server");

    const { data: child, error } = await supabaseAdmin
      .from("child_profiles")
      .select("*")
      .ilike("username", data.username)
      .maybeSingle();

    if (error || !child) {
      throw new Error("We couldn't find that username. Ask your grown-up to check it.");
    }

    if (!child.pin_hash || !(await verifyPin(data.pin, child.pin_hash))) {
      throw new Error("That PIN doesn't match. Try again.");
    }

    const token = crypto.randomUUID();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + SESSION_DAYS);

    const { error: sessionError } = await supabaseAdmin.from("child_sessions").insert({
      child_id: child.id,
      token,
      expires_at: expiresAt.toISOString(),
    });

    if (sessionError) throw new Error(sessionError.message);

    const maxAge = SESSION_DAYS * 24 * 60 * 60;
    // SameSite=None so the session survives inside cross-site preview iframes.
    const cookie = `${COOKIE_NAME}=${token}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=${maxAge}`;
    setResponseHeader("Set-Cookie", cookie);

    return {
      child: {
        id: child.id,
        name: child.name,
        age: child.age,
        grade: child.grade,
        language: child.language,
        interests: child.interests,
        avatar: child.avatar,
      },
    };
  });

export const logoutChild = createServerFn({ method: "POST" })
  .handler(async () => {
    const token = parseCookie(getRequestHeader("Cookie"), COOKIE_NAME);

    if (token) {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      await supabaseAdmin.from("child_sessions").delete().eq("token", token);
    }

    const cookie = `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=0`;
    setResponseHeader("Set-Cookie", cookie);
    return { ok: true };
  });

export const getChildSession = createServerFn({ method: "GET" })
  .handler(async () => {
    const token = parseCookie(getRequestHeader("Cookie"), COOKIE_NAME);
    if (!token) return null;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: session, error: sessionError } = await supabaseAdmin
      .from("child_sessions")
      .select("child_id")
      .eq("token", token)
      .gt("expires_at", new Date().toISOString())
      .single();

    if (sessionError || !session) return null;

    const { data: child, error: childError } = await supabaseAdmin
      .from("child_profiles")
      .select("*")
      .eq("id", session.child_id)
      .single();

    if (childError || !child) return null;
    return child;
  });

const ResetPinSchema = z.object({
  childId: z.string().uuid(),
  newPin: z.string().min(4).max(6).regex(/^\d+$/),
});

export const resetChildPin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ResetPinSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { hashPin } = await import("@/lib/pin.server");

    const { data: child, error } = await context.supabase
      .from("child_profiles")
      .select("id")
      .eq("id", data.childId)
      .eq("parent_id", context.userId)
      .single();

    if (error || !child) throw new Error("Child not found");

    const { error: updateError } = await supabaseAdmin
      .from("child_profiles")
      .update({ pin_hash: await hashPin(data.newPin) })
      .eq("id", data.childId);

    if (updateError) throw new Error(updateError.message);
    return { ok: true };
  });
