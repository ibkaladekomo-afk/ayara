/**
 * Aya companion server functions for the child app: memory brief, celebration
 * moments, learning analytics events and end-of-session conversation recaps.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { CELEBRATIONS } from "@/lib/aya-persona";

export const getMyAyaMemory = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ world_id: z.string().optional() }).parse(input ?? {}))
  .handler(async ({ data }) => {
    const { requireChildSession } = await import("@/lib/child-session.server");
    const { buildAyaMemory } = await import("@/lib/aya-memory.server");
    const ctx = await requireChildSession();
    return buildAyaMemory(ctx, data.world_id ?? null);
  });

export const logMyLearningEvent = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        event: z.string().min(1).max(60),
        metadata: z.record(z.string(), z.unknown()).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    try {
      const { requireChildSession } = await import("@/lib/child-session.server");
      const { childId, parentId, supabaseAdmin } = await requireChildSession();
      await supabaseAdmin.from("child_events").insert({
        child_id: childId,
        parent_id: parentId,
        event: data.event,
        metadata: data.metadata ?? {},
      });
    } catch {
      // analytics must never break a mission
    }
    return { ok: true };
  });

/**
 * Works out which milestones the child has just reached and claims them.
 * Each key is unique per child, so a moment is only ever celebrated once.
 */
export const claimMyCelebrations = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ world_id: z.string().optional() }).parse(input ?? {}))
  .handler(async ({ data }) => {
    const { requireChildSession } = await import("@/lib/child-session.server");
    const { childId, parentId, supabaseAdmin } = await requireChildSession();

    const [progressRes, portfolioRes, worldRes, messageRes] = await Promise.all([
      supabaseAdmin.from("child_progress").select("streak_days").eq("child_id", childId).maybeSingle(),
      supabaseAdmin.from("portfolio_items").select("id").eq("child_id", childId).limit(1),
      data.world_id
        ? supabaseAdmin
            .from("child_world_progress")
            .select("master_project_status, completed_stages")
            .eq("child_id", childId)
            .eq("world_id", data.world_id)
            .maybeSingle()
        : Promise.resolve({ data: null }),
      supabaseAdmin
        .from("conversations")
        .select("id")
        .eq("child_id", childId)
        .limit(1),
    ]);

    const keys: string[] = [];
    if ((messageRes?.data ?? []).length > 0) keys.push("first_question");
    if ((portfolioRes?.data ?? []).length > 0) keys.push("first_project");

    const streak: number = progressRes?.data?.streak_days ?? 0;
    for (const milestone of [30, 14, 7, 3]) {
      if (streak >= milestone) {
        keys.push(`streak_${milestone}`);
        break;
      }
    }

    const world = worldRes?.data ?? null;
    if (world?.master_project_status === "submitted" || world?.master_project_status === "complete") {
      keys.push("master_project");
      keys.push("world_complete");
    }

    if (keys.length === 0) return { celebrations: [] as { key: string; title: string; message: string }[] };

    const { data: existing } = await supabaseAdmin
      .from("child_celebrations")
      .select("key")
      .eq("child_id", childId)
      .in("key", keys);

    const already = new Set((existing ?? []).map((row: { key: string }) => row.key));
    const fresh = keys.filter((key) => !already.has(key) && CELEBRATIONS[key]);
    if (fresh.length === 0) return { celebrations: [] };

    const rows = fresh.map((key) => ({
      child_id: childId,
      parent_id: parentId,
      key,
      title: CELEBRATIONS[key]!.title,
      message: CELEBRATIONS[key]!.message,
    }));

    await supabaseAdmin.from("child_celebrations").insert(rows);

    return {
      celebrations: fresh.map((key) => ({ key, title: CELEBRATIONS[key]!.title, message: CELEBRATIONS[key]!.message })),
    };
  });

/**
 * End-of-session recap. Parents see this instead of a raw transcript.
 */
export const summarizeMyConversation = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        conversation_id: z.string().uuid(),
        world_id: z.string().optional(),
        minutes: z.number().int().min(0).max(600).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { requireChildSession } = await import("@/lib/child-session.server");
    const { childId, parentId, supabaseAdmin, child } = await requireChildSession();

    const { data: conversation } = await supabaseAdmin
      .from("conversations")
      .select("id")
      .eq("id", data.conversation_id)
      .eq("child_id", childId)
      .maybeSingle();
    if (!conversation) return { ok: false as const };

    const { data: messages } = await supabaseAdmin
      .from("messages")
      .select("role, content")
      .eq("conversation_id", data.conversation_id)
      .order("created_at", { ascending: true })
      .limit(60);

    const list: { role: string; content: string }[] = messages ?? [];
    if (list.length < 2) return { ok: false as const };

    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { ok: false as const };

    const transcript = list.map((m) => `${m.role === "user" ? child.name : "Aya"}: ${m.content}`).join("\n");

    const { createLovableAiGatewayProvider } = await import("@/lib/ai-gateway.server");
    const { streamText } = await import("ai");

    let summary = "";
    let themes: string[] = [];
    let skills: string[] = [];

    try {
      const gateway = createLovableAiGatewayProvider(key);
      const result = streamText({
        model: gateway("google/gemini-3.1-flash-lite"),
        prompt: `A child named ${child.name} just had a learning session with Aya, an AI learning companion.
Write a short recap for the child's parent.

Return ONLY JSON in this exact shape:
{"summary": "2-3 warm sentences about what they explored and how they engaged", "themes": ["short topic", "short topic"], "skills": ["skill practised", "skill practised"]}

Do not quote the child directly and do not include anything sensitive verbatim.

Conversation:
${transcript}`,
      });
      const text = await result.text;
      const json = text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1);
      const parsed = JSON.parse(json) as { summary?: string; themes?: string[]; skills?: string[] };
      summary = (parsed.summary ?? "").trim();
      themes = (parsed.themes ?? []).slice(0, 5).map(String);
      skills = (parsed.skills ?? []).slice(0, 5).map(String);
    } catch {
      summary = "";
    }

    if (!summary) return { ok: false as const };

    await supabaseAdmin.from("conversation_summaries").upsert(
      {
        conversation_id: data.conversation_id,
        child_id: childId,
        parent_id: parentId,
        world_id: data.world_id ?? null,
        summary,
        themes,
        skills,
        message_count: list.length,
        minutes: data.minutes ?? 0,
      },
      { onConflict: "conversation_id" },
    );

    return { ok: true as const };
  });
