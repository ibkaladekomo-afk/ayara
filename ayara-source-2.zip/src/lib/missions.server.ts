/**
 * Section 6 — Mission engine (server only).
 *
 * Assigns the five mission types, adapts difficulty, and funnels every reward
 * through one place so XP, crystals, badges and celebrations stay consistent.
 */

import { getAgeTier } from "./age-tiers";
import { getLevelInfo } from "./dashboard-content";
import {
  ALL_TEMPLATES,
  DAILY_MISSIONS,
  FAMILY_MISSIONS,
  MISSION_BEATS,
  RECOVERY_MISSION,
  WEEKLY_CHALLENGES,
  WORLD_MISSIONS,
  activeSeasonalMissions,
  beatLabels,
  pickDifficulty,
  pickFrom,
  scaleTemplate,
  weekStartISO,
  type DifficultyId,
  type MissionTemplateV2,
} from "./missions/catalog";
import { CELEBRATIONS, XP_RULES, type XpReason } from "./missions/rewards";
/** Kept local (not imported from child-dashboard.server) to avoid a module cycle. */
export interface Ctx {
  childId: string;
  parentId: string;
  child: any;
  supabaseAdmin: any;
}

/* ------------------------------------------------------------------ *
 * Analytics
 * ------------------------------------------------------------------ */

export async function logMissionEvent(ctx: Ctx, event: string, metadata: Record<string, unknown> = {}) {
  try {
    await ctx.supabaseAdmin.from("child_events").insert({
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      event,
      metadata,
    });
  } catch {
    /* analytics must never break the child's flow */
  }
}

/* ------------------------------------------------------------------ *
 * Wallet
 * ------------------------------------------------------------------ */

export async function ensureWallet(ctx: Ctx) {
  const { data: existing } = await ctx.supabaseAdmin
    .from("child_wallets")
    .select("*")
    .eq("child_id", ctx.childId)
    .maybeSingle();
  if (existing) return existing;

  const { data: created } = await ctx.supabaseAdmin
    .from("child_wallets")
    .insert({ child_id: ctx.childId, parent_id: ctx.parentId })
    .select()
    .maybeSingle();

  return created ?? { child_id: ctx.childId, parent_id: ctx.parentId, crystals: 0, coins: 0 };
}

/* ------------------------------------------------------------------ *
 * Difficulty
 * ------------------------------------------------------------------ */

export async function difficultyFor(ctx: Ctx): Promise<DifficultyId> {
  const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });

  const [completed, abandoned, worlds, safety] = await Promise.all([
    ctx.supabaseAdmin
      .from("child_missions")
      .select("id", { count: "exact", head: true })
      .eq("child_id", ctx.childId)
      .eq("status", "completed"),
    ctx.supabaseAdmin
      .from("child_missions")
      .select("id", { count: "exact", head: true })
      .eq("child_id", ctx.childId)
      .eq("status", "abandoned"),
    ctx.supabaseAdmin
      .from("child_world_progress")
      .select("id", { count: "exact", head: true })
      .eq("child_id", ctx.childId)
      .eq("master_project_status", "completed"),
    ctx.supabaseAdmin
      .from("parent_safety_settings")
      .select("daily_minutes")
      .eq("parent_id", ctx.parentId)
      .maybeSingle(),
  ]);

  return pickDifficulty({
    tier: tier.id,
    missionsCompleted: completed.count ?? 0,
    missionsAbandoned: abandoned.count ?? 0,
    worldsCompleted: worlds.count ?? 0,
    dailyMinutes: safety.data?.daily_minutes ?? null,
  });
}

/* ------------------------------------------------------------------ *
 * Assignment
 * ------------------------------------------------------------------ */

interface AssignOptions {
  template: MissionTemplateV2;
  difficulty: DifficultyId;
  assignedOn: string;
  weekOf?: string | null;
  seasonId?: string | null;
  familyRole?: string | null;
  expiresAt?: string | null;
}

async function insertMission(ctx: Ctx, options: AssignOptions) {
  const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });
  const scaled = scaleTemplate(options.template, options.difficulty);
  const steps = beatLabels(tier.id);

  const { data, error } = await ctx.supabaseAdmin
    .from("child_missions")
    .insert({
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      world_id: options.template.worldId,
      title: options.template.title,
      prompt: options.template.prompt,
      kind: options.template.kind,
      template_id: options.template.id,
      difficulty: options.difficulty,
      estimated_minutes: scaled.minutes,
      xp_reward: scaled.xp,
      crystal_reward: scaled.crystals,
      badge_reward: options.template.badge ?? null,
      steps,
      total_steps: steps.length,
      assigned_on: options.assignedOn,
      week_of: options.weekOf ?? null,
      season_id: options.seasonId ?? null,
      family_role: options.familyRole ?? null,
      expires_at: options.expiresAt ?? null,
    })
    .select()
    .single();

  if (error) throw new Error(error.message);
  await logMissionEvent(ctx, "mission_assigned", {
    mission_id: data.id,
    kind: options.template.kind,
    template_id: options.template.id,
    difficulty: options.difficulty,
  });
  return data;
}

async function recentTemplateIds(ctx: Ctx, kind: string, limit = 6): Promise<string[]> {
  const { data } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("template_id")
    .eq("child_id", ctx.childId)
    .eq("kind", kind)
    .order("assigned_on", { ascending: false })
    .limit(limit);
  return (data ?? []).map((r: { template_id: string | null }) => r.template_id).filter(Boolean) as string[];
}

/** Today's short creative challenge. */
export async function ensureDailyMission(ctx: Ctx, today: string, difficulty: DifficultyId) {
  const { data: existing } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("*")
    .eq("child_id", ctx.childId)
    .eq("kind", "daily")
    .eq("assigned_on", today)
    .maybeSingle();
  if (existing) return existing;

  const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });
  const template =
    pickFrom(DAILY_MISSIONS, {
      tier: tier.id,
      interests: ctx.child.interests,
      seed: `${ctx.childId}-${today}`,
      excludeIds: await recentTemplateIds(ctx, "daily", 4),
    }) ?? DAILY_MISSIONS[0]!;

  return insertMission(ctx, { template, difficulty, assignedOn: today });
}

/** Two world missions the child can pick up at any time. */
export async function ensureWorldMissions(ctx: Ctx, today: string, difficulty: DifficultyId) {
  const { data: open } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("*")
    .eq("child_id", ctx.childId)
    .eq("kind", "world")
    .neq("status", "completed")
    .neq("status", "abandoned")
    .order("assigned_on", { ascending: false });

  const existing = open ?? [];
  if (existing.length >= 2) return existing.slice(0, 2);

  const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });
  const created = [...existing];
  const used = [
    ...(await recentTemplateIds(ctx, "world", 8)),
    ...existing.map((m: { template_id: string | null }) => m.template_id ?? ""),
  ];

  for (let i = created.length; i < 2; i++) {
    const template = pickFrom(WORLD_MISSIONS, {
      tier: tier.id,
      interests: ctx.child.interests,
      seed: `${ctx.childId}-world-${today}-${i}`,
      excludeIds: used,
    });
    if (!template) break;
    used.push(template.id);
    created.push(await insertMission(ctx, { template, difficulty, assignedOn: today }));
  }
  return created;
}

/** One multi-day Innovation Challenge per week. */
export async function ensureWeeklyChallenge(ctx: Ctx, today: string, difficulty: DifficultyId) {
  const weekOf = weekStartISO(today);
  const { data: existing } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("*")
    .eq("child_id", ctx.childId)
    .eq("kind", "weekly")
    .eq("week_of", weekOf)
    .maybeSingle();
  if (existing) return existing;

  const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });
  const template =
    pickFrom(WEEKLY_CHALLENGES, {
      tier: tier.id,
      interests: ctx.child.interests,
      seed: `${ctx.childId}-week-${weekOf}`,
      excludeIds: await recentTemplateIds(ctx, "weekly", 3),
    }) ?? WEEKLY_CHALLENGES[0]!;

  const expires = new Date(`${weekOf}T00:00:00Z`);
  expires.setUTCDate(expires.getUTCDate() + 7);

  return insertMission(ctx, {
    template,
    difficulty,
    assignedOn: today,
    weekOf,
    expiresAt: expires.toISOString(),
  });
}

/** Seasonal missions, only inside their window. */
export async function ensureSeasonalMissions(ctx: Ctx, today: string, difficulty: DifficultyId) {
  const active = activeSeasonalMissions(new Date(`${today}T12:00:00Z`));
  if (active.length === 0) return [];

  const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });
  const { data: existing } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("*")
    .eq("child_id", ctx.childId)
    .eq("kind", "seasonal");

  const have = new Map<string, any>();
  for (const row of existing ?? []) have.set(row.template_id ?? "", row);

  const out: any[] = [];
  for (const template of active) {
    if (!template.tiers.includes(tier.id)) continue;
    const already = have.get(template.id);
    if (already) {
      out.push(already);
      continue;
    }
    out.push(
      await insertMission(ctx, {
        template,
        difficulty,
        assignedOn: today,
        seasonId: template.season?.id ?? null,
      }),
    );
  }
  return out;
}

/** Offered only when the streak needs rescuing. */
export async function ensureRecoveryMission(ctx: Ctx, today: string) {
  const { data: existing } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("*")
    .eq("child_id", ctx.childId)
    .eq("kind", "recovery")
    .neq("status", "completed")
    .order("assigned_on", { ascending: false })
    .maybeSingle();
  if (existing) return existing;

  return insertMission(ctx, { template: RECOVERY_MISSION, difficulty: "gentle", assignedOn: today });
}

/** Family missions are assigned by a parent; the child sees whatever is open. */
export async function listFamilyMissionsForChild(ctx: Ctx) {
  const { data } = await ctx.supabaseAdmin
    .from("child_missions")
    .select("*")
    .eq("child_id", ctx.childId)
    .eq("kind", "family")
    .neq("status", "abandoned")
    .order("assigned_on", { ascending: false })
    .limit(4);
  return data ?? [];
}

export function familyTemplates() {
  return FAMILY_MISSIONS;
}

/* ------------------------------------------------------------------ *
 * Rewards funnel
 * ------------------------------------------------------------------ */

export interface RewardResult {
  xpAwarded: number;
  crystalsAwarded: number;
  badges: string[];
  leveledUp: boolean;
  level: ReturnType<typeof getLevelInfo>;
  celebrations: { key: string; title: string; message: string }[];
}

async function pushCelebration(ctx: Ctx, key: string) {
  const def = CELEBRATIONS[key];
  if (!def) return null;
  const { data: existing } = await ctx.supabaseAdmin
    .from("child_celebrations")
    .select("id")
    .eq("child_id", ctx.childId)
    .eq("key", key)
    .maybeSingle();
  if (existing && key !== "level_up") return null;

  await ctx.supabaseAdmin.from("child_celebrations").insert({
    child_id: ctx.childId,
    parent_id: ctx.parentId,
    key,
    title: def.title,
    message: def.message,
  });
  return def;
}

/**
 * The single place XP, crystals and badges are granted. Nothing awards XP for
 * simply opening the app.
 */
export async function awardRewards(
  ctx: Ctx,
  input: {
    xp?: number;
    crystals?: number;
    badges?: (string | null | undefined)[];
    reasons?: XpReason[];
    celebrationKeys?: string[];
  },
): Promise<RewardResult> {
  let xp = input.xp ?? 0;
  let crystals = input.crystals ?? 0;

  for (const reason of input.reasons ?? []) {
    const rule = XP_RULES[reason];
    if (!rule) continue;
    xp += rule.xp;
    crystals += rule.crystals;
  }

  const { data: progress } = await ctx.supabaseAdmin
    .from("child_progress")
    .select("xp")
    .eq("child_id", ctx.childId)
    .maybeSingle();

  const beforeXp = progress?.xp ?? 0;
  const before = getLevelInfo(beforeXp);
  const afterXp = beforeXp + xp;
  const after = getLevelInfo(afterXp);

  if (xp !== 0) {
    await ctx.supabaseAdmin
      .from("child_progress")
      .update({ xp: afterXp, level: after.level })
      .eq("child_id", ctx.childId);
  }

  if (crystals !== 0) {
    const wallet = await ensureWallet(ctx);
    await ctx.supabaseAdmin
      .from("child_wallets")
      .update({ crystals: (wallet.crystals ?? 0) + crystals })
      .eq("child_id", ctx.childId);
  }

  const badges = (input.badges ?? []).filter(Boolean) as string[];
  for (const badge of badges) {
    await ctx.supabaseAdmin
      .from("child_badges")
      .upsert(
        { child_id: ctx.childId, parent_id: ctx.parentId, badge_id: badge },
        { onConflict: "child_id,badge_id", ignoreDuplicates: true },
      );
    await logMissionEvent(ctx, "badge_unlocked", { badge_id: badge });
  }

  const celebrationKeys = [...(input.celebrationKeys ?? [])];
  const leveledUp = after.level > before.level;
  if (leveledUp) {
    celebrationKeys.push("level_up");
    await logMissionEvent(ctx, "innovation_level_reached", { level: after.level, title: after.title });
  }
  if (beforeXp < 100 && afterXp >= 100) celebrationKeys.push("xp_100");

  const celebrations = [];
  for (const key of celebrationKeys) {
    const def = await pushCelebration(ctx, key);
    if (def) celebrations.push(def);
  }

  if (xp > 0) await logMissionEvent(ctx, "xp_earned", { xp, reasons: input.reasons ?? [] });
  if (crystals > 0) await logMissionEvent(ctx, "crystals_earned", { crystals });

  return { xpAwarded: xp, crystalsAwarded: crystals, badges, leveledUp, level: after, celebrations };
}

/* ------------------------------------------------------------------ *
 * Misc
 * ------------------------------------------------------------------ */

export function missionBeatLabels(mission: { steps?: unknown }, tier: "spark" | "forge"): string[] {
  const steps = Array.isArray(mission.steps) ? (mission.steps as string[]) : [];
  return steps.length === MISSION_BEATS.length ? steps : beatLabels(tier);
}

export function templateIdsInCatalog(): string[] {
  return ALL_TEMPLATES.map((t) => t.id);
}
