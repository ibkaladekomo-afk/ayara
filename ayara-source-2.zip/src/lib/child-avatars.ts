import type { AgeTierId } from "@/lib/age-tiers";

export interface ChildAvatarOption {
  id: string;
  label: string;
  emoji: string;
  /** Tailwind classes for the avatar background */
  className: string;
  /** Which age tiers this avatar is offered to */
  tiers: AgeTierId[];
}

const YOUNGER: AgeTierId[] = ["spark"];
const OLDER: AgeTierId[] = ["spark", "forge"];
const ALL: AgeTierId[] = ["spark", "forge"];

export const CHILD_AVATARS: ChildAvatarOption[] = [
  // Playful characters — younger children
  { id: "nova", label: "Scientist", emoji: "🔭", className: "bg-primary/15 text-primary", tiers: ALL },
  { id: "artist", label: "Artist", emoji: "🎨", className: "bg-[oklch(0.78_0.14_35)]/20", tiers: ALL },
  { id: "coder", label: "Coder", emoji: "💻", className: "bg-secondary/20", tiers: ALL },
  { id: "inventor", label: "Inventor", emoji: "🤖", className: "bg-accent/20", tiers: YOUNGER },
  { id: "storyteller", label: "Storyteller", emoji: "📚", className: "bg-[oklch(0.85_0.13_95)]/30", tiers: ALL },
  { id: "explorer", label: "Explorer", emoji: "🚀", className: "bg-primary/25 text-primary", tiers: YOUNGER },
  { id: "naturalist", label: "Naturalist", emoji: "🌱", className: "bg-[oklch(0.78_0.13_150)]/25", tiers: YOUNGER },
  { id: "musician", label: "Musician", emoji: "🎵", className: "bg-secondary/25", tiers: ALL },
  { id: "astronomer", label: "Astronomer", emoji: "🪐", className: "bg-accent/25", tiers: YOUNGER },
  { id: "builder", label: "Builder", emoji: "🧩", className: "bg-muted", tiers: YOUNGER },

  // Maker identities — older students (middle school)
  { id: "engineer", label: "Engineer", emoji: "⚙️", className: "bg-foreground/10 text-foreground", tiers: OLDER },
  { id: "researcher", label: "Researcher", emoji: "🧠", className: "bg-primary/20 text-primary", tiers: OLDER },
  { id: "designer", label: "Designer", emoji: "🖊️", className: "bg-secondary/30", tiers: OLDER },
  { id: "filmmaker", label: "Filmmaker", emoji: "🎬", className: "bg-foreground/10 text-foreground", tiers: OLDER },
  { id: "gamedev", label: "Game dev", emoji: "🎮", className: "bg-accent/30", tiers: OLDER },
  { id: "founder", label: "Founder", emoji: "📈", className: "bg-[oklch(0.78_0.13_150)]/25", tiers: OLDER },
  { id: "athlete", label: "Athlete", emoji: "🏅", className: "bg-[oklch(0.85_0.13_95)]/30", tiers: OLDER },
  { id: "producer", label: "Producer", emoji: "🎧", className: "bg-muted", tiers: OLDER },
  { id: "pilot", label: "Pilot", emoji: "🛰️", className: "bg-primary/15 text-primary", tiers: OLDER },
  { id: "chemist", label: "Chemist", emoji: "🧪", className: "bg-[oklch(0.78_0.14_35)]/20", tiers: OLDER },
];

export const DEFAULT_CHILD_AVATAR = "nova";

export function getChildAvatar(id: string | null | undefined): ChildAvatarOption {
  return CHILD_AVATARS.find((a) => a.id === id) ?? CHILD_AVATARS[0]!;
}

export function avatarsForTier(tier: AgeTierId): ChildAvatarOption[] {
  return CHILD_AVATARS.filter((a) => a.tiers.includes(tier));
}

export function defaultAvatarForTier(tier: AgeTierId): string {
  return avatarsForTier(tier)[0]?.id ?? DEFAULT_CHILD_AVATAR;
}
