import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getChildSession, loginChild, logoutChild } from "@/lib/child-auth.functions";

interface ChildProfile {
  id: string;
  name: string;
  age: number;
  grade: string | null;
  language: string;
  interests: string[] | null;
  avatar: string | null;
}

interface ChildSessionContextValue {
  child: ChildProfile | null;
  isLoading: boolean;
  login: (username: string, pin: string) => Promise<ChildProfile>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const ChildSessionContext = createContext<ChildSessionContextValue | null>(null);

export function ChildSessionProvider({ children }: { children: ReactNode }) {
  const [child, setChild] = useState<ChildProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const getSession = useServerFn(getChildSession);
  const doLogin = useServerFn(loginChild);
  const doLogout = useServerFn(logoutChild);

  const refresh = useCallback(async () => {
    try {
      const session = await getSession();
      setChild(session);
    } catch {
      setChild(null);
    }
  }, [getSession]);

  useEffect(() => {
    refresh().finally(() => setIsLoading(false));
  }, [refresh]);

  const login = useCallback(async (username: string, pin: string) => {
    const result = await doLogin({ data: { username, pin } });
    setChild(result.child);
    return result.child;
  }, [doLogin]);

  const logout = useCallback(async () => {
    await doLogout();
    setChild(null);
  }, [doLogout]);

  return (
    <ChildSessionContext.Provider value={{ child, isLoading, login, logout, refresh }}>
      {children}
    </ChildSessionContext.Provider>
  );
}

export function useChildSession() {
  const value = useContext(ChildSessionContext);
  if (!value) throw new Error("useChildSession must be used within ChildSessionProvider");
  return value;
}
