import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getRequestHeader } from "@tanstack/react-start/server";

const COOKIE_NAME = "ayara_child_session";

function parseCookie(header: string | null | undefined, name: string): string | null {
  if (!header) return null;
  const match = header.match(new RegExp(`(?:^|;)\\s*${name}=([^;]+)`));
  return match?.[1] ?? null;
}

async function requireChildSession(): Promise<{
  childId: string;
  parentId: string;
  supabaseAdmin: any;
}> {
  const token = parseCookie(getRequestHeader("Cookie"), COOKIE_NAME);
  if (!token) throw new Error("Child login required");

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: session, error: sessionError } = await supabaseAdmin
    .from("child_sessions")
    .select("child_id")
    .eq("token", token)
    .gt("expires_at", new Date().toISOString())
    .single();

  if (sessionError || !session) throw new Error("Child session expired. Please log in again.");

  const { data: child, error: childError } = await supabaseAdmin
    .from("child_profiles")
    .select("id, parent_id")
    .eq("id", session.child_id)
    .single();

  if (childError || !child) throw new Error("Child profile not found");

  return { childId: child.id, parentId: child.parent_id, supabaseAdmin };
}

async function ensureRows(childId: string, parentId: string, supabaseAdmin: any) {
  await supabaseAdmin
    .from("child_onboarding")
    .upsert({ child_id: childId, parent_id: parentId }, { onConflict: "child_id", ignoreDuplicates: true });
  await supabaseAdmin
    .from("child_progress")
    .upsert({ child_id: childId, parent_id: parentId }, { onConflict: "child_id", ignoreDuplicates: true });
}

async function logEvent(
  supabaseAdmin: any,
  childId: string,
  parentId: string,
  event: string,
  metadata: Record<string, unknown> = {},
) {
  try {
    await supabaseAdmin.from("child_events").insert({ child_id: childId, parent_id: parentId, event, metadata });
  } catch {
    /* analytics must never break the child's flow */
  }
}

/** Everything the child app needs on load: journey state, progress, unlocks. */
export const getMyJourney = createServerFn({ method: "GET" }).handler(async () => {
  const { childId, parentId, supabaseAdmin } = await requireChildSession();
  await ensureRows(childId, parentId, supabaseAdmin);

  const [onboarding, progress, badges, unlocks, portfolio, profile] = await Promise.all([
    supabaseAdmin.from("child_onboarding").select("*").eq("child_id", childId).maybeSingle(),
    supabaseAdmin.from("child_progress").select("*").eq("child_id", childId).maybeSingle(),
    supabaseAdmin.from("child_badges").select("badge_id, earned_at").eq("child_id", childId),
    supabaseAdmin.from("child_world_unlocks").select("world_id, unlocked_at").eq("child_id", childId),
    supabaseAdmin
      .from("portfolio_items")
      .select("id, kind, title, content, world_id, created_at")
      .eq("child_id", childId)
      .order("created_at", { ascending: false })
      .limit(20),
    supabaseAdmin.from("child_profiles").select("avatar_config, interests").eq("id", childId).maybeSingle(),
  ]);

  return {
    onboarding: onboarding.data ?? null,
    progress: progress.data ?? null,
    badges: badges.data ?? [],
    unlocks: unlocks.data ?? [],
    portfolio: portfolio.data ?? [],
    avatar_config: profile.data?.avatar_config ?? null,
  };
});

export const saveMyStep = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ step: z.string().max(40), quest_state: z.record(z.string(), z.unknown()).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    await ensureRows(childId, parentId, supabaseAdmin);
    const patch: Record<string, unknown> = { current_step: data.step };
    if (data.quest_state) patch['quest_state'] = data.quest_state;
    const { error } = await supabaseAdmin.from("child_onboarding").update(patch).eq("child_id", childId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const saveMyAvatar = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        avatar_config: z.object({
          skin: z.string().max(30),
          hair: z.string().max(30),
          hairColor: z.string().max(30),
          glasses: z.string().max(30),
          outfit: z.string().max(30),
          accessory: z.string().max(30),
        }),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    const { error } = await supabaseAdmin
      .from("child_profiles")
      .update({ avatar_config: data.avatar_config })
      .eq("id", childId);
    if (error) throw new Error(error.message);
    await logEvent(supabaseAdmin, childId, parentId, "avatar_selected");
    return { ok: true };
  });

export const saveMyInterests = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ interests: z.array(z.string().max(40)).max(20) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    const { error } = await supabaseAdmin
      .from("child_profiles")
      .update({ interests: data.interests })
      .eq("id", childId);
    if (error) throw new Error(error.message);
    await logEvent(supabaseAdmin, childId, parentId, "interest_selection_completed", { count: data.interests.length });
    return { ok: true };
  });

export const saveMyPortfolioItem = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        kind: z.string().max(40).default("creation"),
        title: z.string().min(1).max(120),
        content: z.record(z.string(), z.unknown()).default({}),
        world_id: z.string().max(60).nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    const { data: item, error } = await supabaseAdmin
      .from("portfolio_items")
      .insert({
        child_id: childId,
        parent_id: parentId,
        kind: data.kind,
        title: data.title,
        content: data.content,
        world_id: data.world_id ?? null,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    await logEvent(supabaseAdmin, childId, parentId, "first_portfolio_item_created", { kind: data.kind });
    return item;
  });

export const listMyPortfolio = createServerFn({ method: "GET" }).handler(async () => {
  const { childId, supabaseAdmin } = await requireChildSession();
  const { data, error } = await supabaseAdmin
    .from("portfolio_items")
    .select("*")
    .eq("child_id", childId)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
});

export const awardMyBadge = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ badge_id: z.string().max(60), xp: z.number().int().min(0).max(1000).default(0) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    await ensureRows(childId, parentId, supabaseAdmin);

    await supabaseAdmin
      .from("child_badges")
      .upsert(
        { child_id: childId, parent_id: parentId, badge_id: data.badge_id },
        { onConflict: "child_id,badge_id", ignoreDuplicates: true },
      );

    if (data.xp > 0) {
      const { data: progress } = await supabaseAdmin
        .from("child_progress")
        .select("xp")
        .eq("child_id", childId)
        .maybeSingle();
      const xp = (progress?.xp ?? 0) + data.xp;
      await supabaseAdmin
        .from("child_progress")
        .update({
          xp,
          level: Math.max(1, Math.floor(xp / 250) + 1),
          last_active_on: new Date().toISOString().slice(0, 10),
        })
        .eq("child_id", childId);
    }

    await logEvent(supabaseAdmin, childId, parentId, "first_badge_earned", { badge_id: data.badge_id });
    return { ok: true };
  });

export const unlockMyWorld = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ world_id: z.string().max(60) }).parse(input))
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    await supabaseAdmin
      .from("child_world_unlocks")
      .upsert(
        { child_id: childId, parent_id: parentId, world_id: data.world_id },
        { onConflict: "child_id,world_id", ignoreDuplicates: true },
      );
    await logEvent(supabaseAdmin, childId, parentId, "learning_world_unlocked", { world_id: data.world_id });
    return { ok: true };
  });

export const logMyEvent = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ event: z.string().max(60), metadata: z.record(z.string(), z.unknown()).default({}) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { childId, parentId, supabaseAdmin } = await requireChildSession();
    await logEvent(supabaseAdmin, childId, parentId, data.event, data.metadata);
    return { ok: true };
  });

export const completeMyOnboarding = createServerFn({ method: "POST" }).handler(async () => {
  const { childId, parentId, supabaseAdmin } = await requireChildSession();
  await ensureRows(childId, parentId, supabaseAdmin);
  const { error } = await supabaseAdmin
    .from("child_onboarding")
    .update({ current_step: "done", completed_at: new Date().toISOString() })
    .eq("child_id", childId);
  if (error) throw new Error(error.message);
  await logEvent(supabaseAdmin, childId, parentId, "child_onboarding_completed");
  return { ok: true };
});
