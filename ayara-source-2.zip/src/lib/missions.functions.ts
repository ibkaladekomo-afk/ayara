import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requireChildSession, todayISO } from "./child-dashboard.server";
import {
  awardRewards,
  difficultyFor,
  ensureDailyMission,
  ensureRecoveryMission,
  ensureSeasonalMissions,
  ensureWeeklyChallenge,
  ensureWorldMissions,
  ensureWallet,
  familyTemplates,
  listFamilyMissionsForChild,
  logMissionEvent,
} from "./missions.server";
import { getTemplate, scaleTemplate, beatLabels, weekStartISO } from "./missions/catalog";
import { SHOP_ITEMS, getShopItem } from "./missions/rewards";
import { getAgeTier } from "./age-tiers";

/* ================================================================== *
 * Child-facing
 * ================================================================== */

/** Every mission type the child can pick up right now. */
export const getMissionBoard = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ tz_offset_minutes: z.number().int().min(-840).max(840).default(0) }).parse(input ?? {}),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const today = todayISO(data.tz_offset_minutes);
    const difficulty = await difficultyFor(ctx);
    const tier = getAgeTier({ age: ctx.child.age, grade: ctx.child.grade });

    const [daily, world, weekly, seasonal, family, wallet, progress] = await Promise.all([
      ensureDailyMission(ctx, today, difficulty),
      ensureWorldMissions(ctx, today, difficulty),
      ensureWeeklyChallenge(ctx, today, difficulty),
      ensureSeasonalMissions(ctx, today, difficulty),
      listFamilyMissionsForChild(ctx),
      ensureWallet(ctx),
      ctx.supabaseAdmin.from("child_progress").select("*").eq("child_id", ctx.childId).maybeSingle(),
    ]);

    const streakBroken = (progress.data?.streak_days ?? 0) === 0 && Boolean(progress.data?.last_active_on);
    const recovery = streakBroken ? await ensureRecoveryMission(ctx, today) : null;

    return {
      today,
      tier: tier.id,
      difficulty,
      beats: beatLabels(tier.id),
      daily,
      world,
      weekly,
      seasonal,
      family,
      recovery,
      wallet: { crystals: wallet.crystals ?? 0, coins: wallet.coins ?? 0 },
      weekOf: weekStartISO(today),
    };
  });

/** Save the child's reflection answers for a mission. */
export const saveMissionReflection = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        mission_id: z.string().uuid(),
        favorite_part: z.string().max(500).optional(),
        would_improve: z.string().max(500).optional(),
        surprised_by: z.string().max(500).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();

    const { data: existing } = await ctx.supabaseAdmin
      .from("mission_reflections")
      .select("id")
      .eq("mission_id", data.mission_id)
      .eq("child_id", ctx.childId)
      .maybeSingle();
    if (existing) return { ok: true, alreadySaved: true, reward: null };

    await ctx.supabaseAdmin.from("mission_reflections").insert({
      mission_id: data.mission_id,
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      favorite_part: data.favorite_part ?? null,
      would_improve: data.would_improve ?? null,
      surprised_by: data.surprised_by ?? null,
    });

    const reward = await awardRewards(ctx, { reasons: ["reflection_completed"] });
    await logMissionEvent(ctx, "reflection_saved", { mission_id: data.mission_id });
    return { ok: true, alreadySaved: false, reward };
  });

/** Complete any mission type through the shared rewards funnel. */
export const finishMission = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z
      .object({
        mission_id: z.string().uuid(),
        made_creation: z.boolean().default(false),
        revised_work: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();

    const { data: mission } = await ctx.supabaseAdmin
      .from("child_missions")
      .select("*")
      .eq("id", data.mission_id)
      .eq("child_id", ctx.childId)
      .maybeSingle();
    if (!mission) throw new Error("Mission not found");
    if (mission.status === "completed") return { alreadyDone: true, reward: null, mission };

    const isFamily = mission.kind === "family";
    const patch: Record<string, unknown> = {
      progress_step: mission.total_steps,
      child_confirmed_at: new Date().toISOString(),
    };
    // Family missions wait for the grown-up to confirm before rewards land.
    if (!isFamily) {
      patch['status'] = "completed";
      patch['completed_at'] = new Date().toISOString();
    }

    await ctx.supabaseAdmin.from("child_missions").update(patch).eq("id", mission.id);

    if (isFamily) {
      await logMissionEvent(ctx, "family_mission_child_confirmed", { mission_id: mission.id });
      return { alreadyDone: false, awaitingParent: true, reward: null, mission };
    }

    const { count: completedCount } = await ctx.supabaseAdmin
      .from("child_missions")
      .select("id", { count: "exact", head: true })
      .eq("child_id", ctx.childId)
      .eq("status", "completed");

    const celebrationKeys: string[] = [];
    if ((completedCount ?? 0) <= 1) celebrationKeys.push("first_mission");
    if (mission.kind === "weekly") celebrationKeys.push("weekly_done");
    if (mission.kind === "recovery") celebrationKeys.push("streak_restored");

    const reward = await awardRewards(ctx, {
      xp: mission.xp_reward ?? 0,
      crystals: mission.crystal_reward ?? 0,
      badges: [mission.badge_reward],
      reasons: [
        ...(data.made_creation ? (["creation_made"] as const) : []),
        ...(data.revised_work ? (["revision_made"] as const) : []),
      ],
      celebrationKeys,
    });

    if (mission.kind === "recovery") {
      await ctx.supabaseAdmin.from("child_progress").update({ streak_days: 1 }).eq("child_id", ctx.childId);
    }

    await logMissionEvent(ctx, "mission_completed", {
      mission_id: mission.id,
      kind: mission.kind,
      world_id: mission.world_id,
      xp: reward.xpAwarded,
    });

    return { alreadyDone: false, awaitingParent: false, reward, mission };
  });

/** Let a child put a mission down without shame — it just goes back on the board. */
export const abandonMission = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ mission_id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    await ctx.supabaseAdmin
      .from("child_missions")
      .update({ status: "abandoned" })
      .eq("id", data.mission_id)
      .eq("child_id", ctx.childId)
      .neq("status", "completed");
    await logMissionEvent(ctx, "mission_abandoned", { mission_id: data.mission_id });
    return { ok: true };
  });

/* ------------------------------------------------------------------ *
 * Cosmetic shop (Premium Coins — scaffold, no payments)
 * ------------------------------------------------------------------ */

export const getMyShop = createServerFn({ method: "POST" }).handler(async () => {
  const ctx = await requireChildSession();
  const wallet = await ensureWallet(ctx);
  const { data: owned } = await ctx.supabaseAdmin
    .from("child_cosmetics")
    .select("item_id, equipped")
    .eq("child_id", ctx.childId);

  return {
    coins: wallet.coins ?? 0,
    crystals: wallet.crystals ?? 0,
    items: SHOP_ITEMS,
    owned: owned ?? [],
  };
});

export const buyCosmetic = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => z.object({ item_id: z.string().max(80) }).parse(input))
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const item = getShopItem(data.item_id);
    if (!item) throw new Error("That item doesn't exist");

    const wallet = await ensureWallet(ctx);
    const { data: already } = await ctx.supabaseAdmin
      .from("child_cosmetics")
      .select("id")
      .eq("child_id", ctx.childId)
      .eq("item_id", item.id)
      .maybeSingle();
    if (already) return { ok: true, alreadyOwned: true, coins: wallet.coins ?? 0 };

    if ((wallet.coins ?? 0) < item.coins) {
      return { ok: false, alreadyOwned: false, coins: wallet.coins ?? 0, reason: "not_enough_coins" as const };
    }

    await ctx.supabaseAdmin.from("child_cosmetics").insert({
      child_id: ctx.childId,
      parent_id: ctx.parentId,
      item_id: item.id,
      category: item.category,
      coins_spent: item.coins,
    });
    const coins = (wallet.coins ?? 0) - item.coins;
    await ctx.supabaseAdmin.from("child_wallets").update({ coins }).eq("child_id", ctx.childId);
    await logMissionEvent(ctx, "cosmetic_purchased", { item_id: item.id, coins: item.coins });
    return { ok: true, alreadyOwned: false, coins };
  });

export const equipCosmetic = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) =>
    z.object({ item_id: z.string().max(80), equipped: z.boolean() }).parse(input),
  )
  .handler(async ({ data }) => {
    const ctx = await requireChildSession();
    const item = getShopItem(data.item_id);
    if (!item) throw new Error("That item doesn't exist");

    if (data.equipped) {
      await ctx.supabaseAdmin
        .from("child_cosmetics")
        .update({ equipped: false })
        .eq("child_id", ctx.childId)
        .eq("category", item.category);
    }
    await ctx.supabaseAdmin
      .from("child_cosmetics")
      .update({ equipped: data.equipped })
      .eq("child_id", ctx.childId)
      .eq("item_id", item.id);
    return { ok: true };
  });

/* ================================================================== *
 * Parent-facing
 * ================================================================== */

/** Family mission templates a parent can assign. */
export const listFamilyMissionTemplates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async () =>
    familyTemplates().map((t) => ({
      id: t.id,
      title: t.title,
      together: t.together ?? null,
      minutes: t.minutes,
      xp: t.xp,
      worldId: t.worldId,
    })),
  );

/** Missions & Growth panel for the parent dashboard. */
export const getFamilyMissionOverview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const { data: children } = await supabase
      .from("child_profiles")
      .select("id, name, avatar, age, grade")
      .eq("parent_id", userId)
      .order("created_at", { ascending: true });

    const ids = (children ?? []).map((c) => c.id);
    if (ids.length === 0) return { children: [], missions: [], wallets: [], reflections: [] };

    const [missions, wallets, reflections] = await Promise.all([
      supabase
        .from("child_missions")
        .select("id, child_id, title, kind, status, xp_reward, crystal_reward, assigned_on, completed_at, child_confirmed_at, parent_confirmed_at, family_role")
        .in("child_id", ids)
        .order("assigned_on", { ascending: false })
        .limit(60),
      supabase.from("child_wallets").select("child_id, crystals, coins").in("child_id", ids),
      supabase
        .from("mission_reflections")
        .select("id, child_id, mission_id, favorite_part, would_improve, surprised_by, created_at")
        .in("child_id", ids)
        .order("created_at", { ascending: false })
        .limit(20),
    ]);

    return {
      children: children ?? [],
      missions: missions.data ?? [],
      wallets: wallets.data ?? [],
      reflections: reflections.data ?? [],
    };
  });

/** Assign a family mission to one child. */
export const assignFamilyMission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ child_id: z.string().uuid(), template_id: z.string().max(80) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const template = getTemplate(data.template_id);
    if (!template || template.kind !== "family") throw new Error("Unknown family mission");

    const { data: child } = await supabase
      .from("child_profiles")
      .select("id, age, grade")
      .eq("id", data.child_id)
      .eq("parent_id", userId)
      .maybeSingle();
    if (!child) throw new Error("Child not found");

    const tier = getAgeTier({ age: child.age, grade: child.grade });
    const scaled = scaleTemplate(template, "core");
    const steps = beatLabels(tier.id);

    const { error } = await supabase.from("child_missions").insert({
      child_id: child.id,
      parent_id: userId,
      world_id: template.worldId,
      title: template.title,
      prompt: template.prompt,
      kind: "family",
      template_id: template.id,
      difficulty: "core",
      estimated_minutes: scaled.minutes,
      xp_reward: scaled.xp,
      crystal_reward: scaled.crystals,
      badge_reward: template.badge ?? null,
      steps,
      total_steps: steps.length,
      assigned_on: new Date().toISOString().slice(0, 10),
      family_role: template.together ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Parent confirms a family mission — this is what releases the reward. */
export const confirmFamilyMission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ mission_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: mission } = await supabase
      .from("child_missions")
      .select("*")
      .eq("id", data.mission_id)
      .eq("parent_id", userId)
      .maybeSingle();
    if (!mission) throw new Error("Mission not found");
    if (mission.status === "completed") return { ok: true, alreadyDone: true };

    const now = new Date().toISOString();
    await supabase
      .from("child_missions")
      .update({ status: "completed", completed_at: now, parent_confirmed_at: now, progress_step: mission.total_steps })
      .eq("id", mission.id);

    const { data: child } = await supabase
      .from("child_profiles")
      .select("id, parent_id, name, age, grade, interests")
      .eq("id", mission.child_id)
      .single();

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const ctx = { childId: mission.child_id, parentId: userId, child, supabaseAdmin };

    const reward = await awardRewards(ctx, {
      xp: mission.xp_reward ?? 0,
      crystals: mission.crystal_reward ?? 0,
      badges: [mission.badge_reward, "team-player"],
      reasons: ["family_collaboration"],
      celebrationKeys: ["family_done"],
    });

    return { ok: true, alreadyDone: false, reward };
  });

/** Parents can grant Premium Coins directly (payments not wired up yet). */
export const grantPremiumCoins = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ child_id: z.string().uuid(), amount: z.number().int().min(1).max(500), note: z.string().max(120).optional() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: child } = await supabase
      .from("child_profiles")
      .select("id")
      .eq("id", data.child_id)
      .eq("parent_id", userId)
      .maybeSingle();
    if (!child) throw new Error("Child not found");

    await supabase.from("coin_grants").insert({
      child_id: child.id,
      parent_id: userId,
      amount: data.amount,
      note: data.note ?? null,
    });

    const { data: wallet } = await supabase
      .from("child_wallets")
      .select("id, coins")
      .eq("child_id", child.id)
      .maybeSingle();

    if (wallet) {
      await supabase.from("child_wallets").update({ coins: (wallet.coins ?? 0) + data.amount }).eq("id", wallet.id);
    } else {
      await supabase.from("child_wallets").insert({ child_id: child.id, parent_id: userId, coins: data.amount });
    }

    return { ok: true, coins: (wallet?.coins ?? 0) + data.amount };
  });
