import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getChildLearningSummary, clearChildConversationHistory } from "@/lib/learning-summary.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, Loader2, Trash2 } from "lucide-react";

export function LearningSummaryCard({ children }: { children: { id: string; name: string }[] }) {
  const [activeId, setActiveId] = useState<string | null>(children[0]?.id ?? null);
  const queryClient = useQueryClient();
  const fetchSummary = useServerFn(getChildLearningSummary);
  const clearHistory = useServerFn(clearChildConversationHistory);

  const { data, isLoading } = useQuery({
    queryKey: ["learningSummary", activeId],
    enabled: Boolean(activeId),
    queryFn: () => fetchSummary({ data: { child_id: activeId! } }),
  });

  const clear = useMutation({
    mutationFn: () => clearHistory({ data: { child_id: activeId! } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["learningSummary", activeId] }),
  });

  if (children.length === 0) return null;

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <BookOpen className="h-5 w-5 text-primary" />
          Learning summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          You see what your child explored and practised — not every message they typed.
        </p>

        {children.length > 1 && (
          <div className="flex flex-wrap gap-2">
            {children.map((child) => (
              <button
                key={child.id}
                onClick={() => setActiveId(child.id)}
                className={`rounded-full border px-3 py-1.5 text-sm font-semibold transition-colors ${
                  activeId === child.id
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-muted/40 text-muted-foreground hover:bg-muted"
                }`}
              >
                {child.name}
              </button>
            ))}
          </div>
        )}

        {isLoading && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}

        {data && (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: "Questions asked", value: data.questionsAsked },
                { label: "Projects made", value: data.projects },
                { label: "Minutes learning", value: data.minutes },
                { label: "Reflections", value: data.reflections },
              ].map((stat) => (
                <div key={stat.label} className="rounded-2xl bg-muted/40 p-3 text-center">
                  <p className="font-display text-xl text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>

            {data.themes.length > 0 && (
              <div>
                <p className="text-sm font-semibold text-foreground">Themes explored</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {data.themes.map((theme) => (
                    <span key={theme} className="rounded-full bg-secondary/25 px-3 py-1 text-xs text-foreground">
                      {theme}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {data.skills.length > 0 && (
              <div>
                <p className="text-sm font-semibold text-foreground">Skills practised</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {data.skills.map((skill) => (
                    <span key={skill} className="rounded-full bg-primary/10 px-3 py-1 text-xs text-foreground">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {data.summaries.length > 0 ? (
              <ul className="space-y-3">
                {data.summaries.slice(0, 5).map((summary) => (
                  <li key={summary.id} className="rounded-2xl border border-border p-4">
                    <p className="text-sm text-foreground">{summary.summary}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {new Date(summary.created_at).toLocaleDateString()} · {summary.minutes} min
                    </p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">
                Recaps appear here after your child finishes a learning session.
              </p>
            )}

            <Button
              variant="ghost"
              size="sm"
              className="text-destructive"
              disabled={clear.isPending}
              onClick={() => {
                if (window.confirm("Clear all of Aya's saved conversations for this child?")) clear.mutate();
              }}
            >
              {clear.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              Clear Aya's conversation history
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
