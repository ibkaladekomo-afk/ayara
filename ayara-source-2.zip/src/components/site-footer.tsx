import { Link } from "@tanstack/react-router";
import ayaraLogo from "@/assets/ayara-horizontal.png.asset.json";

export function SiteFooter() {
  return (
    <footer className="w-full border-t border-border/50 bg-background py-10">
      <div className="mx-auto max-w-6xl px-4 md:px-6">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <img
            src={ayaraLogo.url}
            alt="Ayara — Growing the Next Generation of Innovators"
            className="h-10 w-auto"
          />

          <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground">
              Home
            </Link>
            <Link to="/about" className="hover:text-foreground">
              About
            </Link>
            <Link to="/safety" className="hover:text-foreground">
              Safety
            </Link>
            <Link to="/auth" search={{ mode: "signin" }} className="hover:text-foreground">
              Start learning

            </Link>
          </div>
        </div>
        <p className="mt-8 text-xs text-muted-foreground">
          © {new Date().getFullYear()} AYARA. Growing the Next Generation of Innovators.
        </p>
      </div>
    </footer>
  );
}
