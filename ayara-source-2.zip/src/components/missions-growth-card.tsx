import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Coins, Gem, CheckCircle2, Target } from "lucide-react";
import {
  assignFamilyMission,
  confirmFamilyMission,
  getFamilyMissionOverview,
  grantPremiumCoins,
  listFamilyMissionTemplates,
} from "@/lib/missions.functions";
import { missionKindMeta } from "@/lib/missions/catalog";

/** Missions & Growth: family missions, rewards and reflections in one place. */
export function MissionsGrowthCard() {
  const queryClient = useQueryClient();
  const [selectedChild, setSelectedChild] = useState<string | null>(null);

  const fetchOverview = useServerFn(getFamilyMissionOverview);
  const fetchTemplates = useServerFn(listFamilyMissionTemplates);
  const assign = useServerFn(assignFamilyMission);
  const confirm = useServerFn(confirmFamilyMission);
  const grant = useServerFn(grantPremiumCoins);

  const overview = useQuery({ queryKey: ["family-missions"], queryFn: () => fetchOverview() });
  const templates = useQuery({ queryKey: ["family-mission-templates"], queryFn: () => fetchTemplates() });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["family-missions"] });

  const assignMutation = useMutation({
    mutationFn: (vars: { child_id: string; template_id: string }) => assign({ data: vars }),
    onSuccess: refresh,
  });
  const confirmMutation = useMutation({
    mutationFn: (missionId: string) => confirm({ data: { mission_id: missionId } }),
    onSuccess: refresh,
  });
  const grantMutation = useMutation({
    mutationFn: (vars: { child_id: string; amount: number }) => grant({ data: vars }),
    onSuccess: refresh,
  });

  const data = overview.data;
  const children = data?.children ?? [];
  const activeChild = selectedChild ?? children[0]?.id ?? null;
  const childMissions = (data?.missions ?? []).filter((m) => m.child_id === activeChild);
  const wallet = (data?.wallets ?? []).find((w) => w.child_id === activeChild);
  const reflections = (data?.reflections ?? []).filter((r) => r.child_id === activeChild).slice(0, 3);
  const awaiting = childMissions.filter(
    (m) => m.kind === "family" && m.status !== "completed" && m.child_confirmed_at,
  );
  const completedCount = childMissions.filter((m) => m.status === "completed").length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" aria-hidden />
          Missions &amp; Growth
        </CardTitle>
      </CardHeader>
      <CardContent>
        {overview.isLoading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="h-5 w-5 animate-spin text-primary" aria-label="Loading" />
          </div>
        ) : children.length === 0 ? (
          <p className="text-sm text-muted-foreground">Add a child to start assigning family missions.</p>
        ) : (
          <div className="space-y-5">
            {children.length > 1 ? (
              <div className="flex flex-wrap gap-2">
                {children.map((child) => (
                  <Button
                    key={child.id}
                    size="sm"
                    variant={child.id === activeChild ? "default" : "outline"}
                    className="min-h-11 rounded-full"
                    onClick={() => setSelectedChild(child.id)}
                  >
                    {child.name}
                  </Button>
                ))}
              </div>
            ) : null}

            <div className="grid gap-2 sm:grid-cols-3">
              <div className="rounded-2xl border border-border p-3">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Missions completed</p>
                <p className="font-display text-xl text-foreground">{completedCount}</p>
              </div>
              <div className="rounded-2xl border border-border p-3">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Curiosity Crystals</p>
                <p className="flex items-center gap-1 font-display text-xl text-foreground">
                  <Gem className="h-4 w-4 text-primary" aria-hidden /> {wallet?.crystals ?? 0}
                </p>
              </div>
              <div className="rounded-2xl border border-border p-3">
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Premium Coins</p>
                <p className="flex items-center gap-1 font-display text-xl text-foreground">
                  <Coins className="h-4 w-4 text-primary" aria-hidden /> {wallet?.coins ?? 0}
                </p>
              </div>
            </div>

            {awaiting.length > 0 ? (
              <div className="rounded-2xl border border-primary/30 bg-primary/5 p-3">
                <p className="text-sm font-semibold text-foreground">Waiting for your confirmation</p>
                <ul className="mt-2 space-y-2">
                  {awaiting.map((mission) => (
                    <li key={mission.id} className="flex flex-wrap items-center gap-2 text-sm">
                      <span className="text-foreground">{mission.title}</span>
                      <Button
                        size="sm"
                        className="ml-auto min-h-11"
                        disabled={confirmMutation.isPending}
                        onClick={() => confirmMutation.mutate(mission.id)}
                      >
                        <CheckCircle2 className="mr-1 h-4 w-4" aria-hidden /> We did it
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <div>
              <p className="text-sm font-semibold text-foreground">Assign a family mission</p>
              <div className="mt-2 grid gap-2">
                {(templates.data ?? []).map((template) => (
                  <div key={template.id} className="flex flex-wrap items-center gap-2 rounded-2xl border border-border p-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-foreground">{template.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {template.minutes} min together · +{template.xp} XP
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="ml-auto min-h-11"
                      disabled={!activeChild || assignMutation.isPending}
                      onClick={() =>
                        activeChild && assignMutation.mutate({ child_id: activeChild, template_id: template.id })
                      }
                    >
                      Assign
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {reflections.length > 0 ? (
              <div>
                <p className="text-sm font-semibold text-foreground">Recent reflections</p>
                <ul className="mt-2 space-y-2 text-sm text-muted-foreground">
                  {reflections.map((reflection) => (
                    <li key={reflection.id} className="rounded-2xl border border-border p-3">
                      {reflection.favorite_part ? <p>“{reflection.favorite_part}”</p> : null}
                      {reflection.would_improve ? (
                        <p className="mt-1">Next time: {reflection.would_improve}</p>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-border p-3">
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground">Premium Coins</p>
                <p className="text-xs text-muted-foreground">
                  Cosmetic only — they never unlock learning. Purchases arrive later; you can gift coins now.
                </p>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="ml-auto min-h-11"
                disabled={!activeChild || grantMutation.isPending}
                onClick={() => activeChild && grantMutation.mutate({ child_id: activeChild, amount: 25 })}
              >
                Gift 25 coins
              </Button>
            </div>

            <p className="text-xs text-muted-foreground">
              Mission types in rotation: {["daily", "world", "weekly", "family", "seasonal"].map((k) => missionKindMeta(k).label).join(" · ")}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
