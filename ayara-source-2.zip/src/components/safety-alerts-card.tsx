import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listSafetyAlerts, markSafetyAlertReviewed } from "@/lib/safety-alerts.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, BellRing, Check, ShieldCheck } from "lucide-react";

const SEVERITY_STYLES: Record<string, { label: string; className: string }> = {
  urgent: { label: "Please read today", className: "bg-destructive/10 text-destructive border-destructive/30" },
  attention: { label: "Worth a look", className: "bg-[oklch(0.85_0.13_95)]/30 text-foreground border-border" },
  notice: { label: "For your info", className: "bg-muted text-muted-foreground border-border" },
};

export function SafetyAlertsCard({ childNames }: { childNames: Record<string, string> }) {
  const queryClient = useQueryClient();
  const fetchAlerts = useServerFn(listSafetyAlerts);
  const markReviewed = useServerFn(markSafetyAlertReviewed);

  const { data: alerts = [] } = useQuery({
    queryKey: ["safetyAlerts"],
    queryFn: fetchAlerts,
  });

  const review = useMutation({
    mutationFn: (id: string) => markReviewed({ data: { id } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["safetyAlerts"] }),
  });

  const open = alerts.filter((a) => !a.reviewed_at);

  return (
    <Card className={open.length > 0 ? "border-destructive/40" : undefined}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          {open.length > 0 ? (
            <BellRing className="h-5 w-5 text-destructive" />
          ) : (
            <ShieldCheck className="h-5 w-5 text-primary" />
          )}
          Safety alerts
          {open.length > 0 && (
            <span className="rounded-full bg-destructive px-2 py-0.5 text-xs font-semibold text-destructive-foreground">
              {open.length}
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {open.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Nothing needs your attention. If a conversation ever touches a sensitive topic, AYARA redirects your child
            to a trusted adult and tells you here.
          </p>
        ) : (
          <ul className="space-y-3">
            {open.map((alert) => {
              const style = SEVERITY_STYLES[alert.severity] ?? SEVERITY_STYLES["notice"]!;
              return (
                <li key={alert.id} className={`rounded-2xl border p-4 ${style.className}`}>
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold">{alert.category}</p>
                      <p className="text-xs opacity-80">
                        {childNames[alert.child_id] ?? "Your child"} · {new Date(alert.created_at).toLocaleString()} ·{" "}
                        {style.label}
                      </p>
                      {alert.ayara_response && <p className="mt-2 text-sm">{alert.ayara_response}</p>}
                      <p className="mt-2 rounded-lg bg-background/70 px-3 py-2 text-sm italic text-foreground">
                        “{alert.excerpt}”
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex justify-end">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={review.isPending}
                      onClick={() => review.mutate(alert.id)}
                    >
                      <Check className="mr-1.5 h-4 w-4" />
                      I've read this
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}
