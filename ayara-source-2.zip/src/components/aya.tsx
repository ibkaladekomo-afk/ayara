import { cn } from "@/lib/utils";
import ayaMascot from "@/assets/aya-mascot.png";

const sizes = {
  sm: "h-16 w-16",
  md: "h-28 w-28",
  lg: "h-40 w-40",
  xl: "h-56 w-56",
} as const;

export function Aya({
  size = "md",
  mood = "idle",
  className,
}: {
  size?: keyof typeof sizes;
  mood?: "idle" | "wave" | "celebrate";
  className?: string;
}) {
  return (
    <img
      src={ayaMascot}
      alt="Aya, the Ayara learning companion"
      width={816}
      height={816}
      loading="lazy"
      className={cn(
        sizes[size],
        "select-none object-contain drop-shadow-[0_12px_28px_rgba(76,124,245,0.28)]",
        mood === "wave" && "motion-safe:animate-[aya-float_4s_ease-in-out_infinite]",
        mood === "celebrate" && "motion-safe:animate-[aya-pop_900ms_ease-out]",
        className,
      )}
    />
  );
}

const LOADING_LINES = [
  "Preparing your family's adventure…",
  "Building your child's learning world…",
  "Almost ready…",
];

export function AyaLoading({ message, className }: { message?: string; className?: string }) {
  const line = message ?? LOADING_LINES[0];
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn("flex flex-col items-center justify-center gap-4 py-16 text-center", className)}
    >
      <Aya size="md" mood="wave" />
      <p className="max-w-xs font-heading text-base font-semibold text-muted-foreground">{line}</p>
    </div>
  );
}
