import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { KeyRound, Loader2 } from "lucide-react";
import { resetChildPin } from "@/lib/child-auth.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export function ResetChildPinDialog({ childId, childName }: { childId: string; childName: string }) {
  const resetPin = useServerFn(resetChildPin);
  const [open, setOpen] = useState(false);
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    if (pin !== confirmPin) {
      setError("The PINs do not match.");
      return;
    }

    setPending(true);
    try {
      await resetPin({ data: { childId, newPin: pin } });
      setPin("");
      setConfirmPin("");
      setOpen(false);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "The PIN could not be reset.");
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="w-full sm:w-auto">
          <KeyRound className="mr-1.5 h-4 w-4" />
          Reset PIN
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Reset {childName}&apos;s PIN</DialogTitle>
          <DialogDescription>Choose a new 4–6 digit PIN. Their username will stay the same.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor={`new-pin-${childId}`}>New PIN</Label>
            <Input
              id={`new-pin-${childId}`}
              type="password"
              inputMode="numeric"
              autoComplete="new-password"
              minLength={4}
              maxLength={6}
              value={pin}
              onChange={(event) => setPin(event.target.value.replace(/\D/g, "").slice(0, 6))}
              required
            />
          </div>
          <div>
            <Label htmlFor={`confirm-pin-${childId}`}>Confirm new PIN</Label>
            <Input
              id={`confirm-pin-${childId}`}
              type="password"
              inputMode="numeric"
              autoComplete="new-password"
              minLength={4}
              maxLength={6}
              value={confirmPin}
              onChange={(event) => setConfirmPin(event.target.value.replace(/\D/g, "").slice(0, 6))}
              required
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" className="w-full" disabled={pending}>
              {pending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save new PIN
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}