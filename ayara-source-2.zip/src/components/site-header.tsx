import { Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import ayaraLogo from "@/assets/ayara-horizontal.png.asset.json";

const navLinks = [
  { to: "/about", label: "About" },
  { to: "/safety", label: "Safety" },

];

export function SiteHeader() {
  const { user, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 md:px-6">
        <Link to="/" className="flex items-center">
          <img
            src={ayaraLogo.url}
            alt="Ayara — Growing the Next Generation of Innovators"
            className="h-9 w-auto md:h-10"
          />
        </Link>


        <nav className="hidden items-center gap-6 md:flex">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              activeProps={{ className: "text-foreground" }}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <>
              <Link to="/dashboard">
                <Button variant="ghost" size="sm">
                  Dashboard
                </Button>
              </Link>
              <Button variant="outline" size="sm" onClick={() => signOut()}>
                Sign out
              </Button>
            </>
          ) : (
            <>
              <Link to="/auth" search={{ mode: "signin" }}>
                <Button variant="ghost" size="sm">
                  Parent sign in
                </Button>
              </Link>
              <Link to="/child-login">
                <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                  Kid login
                </Button>
              </Link>
            </>
          )}
        </div>

        <button
          className="rounded-md p-2 md:hidden"
          onClick={() => setMobileOpen((open) => !open)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-border/50 bg-background px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-3">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="text-base font-medium text-muted-foreground hover:text-foreground"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <hr className="border-border/50" />
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setMobileOpen(false)} className="text-base font-medium">
                  Dashboard
                </Link>
                <button
                  onClick={() => {
                    setMobileOpen(false);
                    void signOut();
                  }}
                  className="text-left text-base font-medium text-muted-foreground"
                >
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link to="/auth" search={{ mode: "signin" }} onClick={() => setMobileOpen(false)} className="text-base font-medium">
                  Parent sign in
                </Link>
                <Link to="/child-login" onClick={() => setMobileOpen(false)} className="text-base font-medium text-primary">
                  Kid login
                </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
