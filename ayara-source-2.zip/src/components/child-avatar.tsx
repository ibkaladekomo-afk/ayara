import { CHILD_AVATARS, avatarsForTier, getChildAvatar } from "@/lib/child-avatars";
import { AGE_TIERS, type AgeTier, type AgeTierId } from "@/lib/age-tiers";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { Check } from "lucide-react";

const sizeClasses = {
  sm: "h-8 w-8 text-base",
  md: "h-10 w-10 text-xl",
  lg: "h-14 w-14 text-2xl",
} as const;

export function TierBadge({ tier, className }: { tier: AgeTier | AgeTierId; className?: string }) {
  const t = typeof tier === "string" ? AGE_TIERS[tier] : tier;
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold",
        t.badgeClass,
        className,
      )}
    >
      {t.label} · {t.gradeRange}
    </span>
  );
}


export function ChildAvatar({
  avatar,
  size = "md",
  className,
}: {
  avatar: string | null | undefined;
  size?: keyof typeof sizeClasses;
  className?: string;
}) {
  const option = getChildAvatar(avatar);
  return (
    <span
      role="img"
      aria-label={option.label}
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-full border border-border/50",
        option.className,
        sizeClasses[size],
        className,
      )}
    >
      {option.emoji}
    </span>
  );
}

export function AvatarPicker({
  value,
  onChange,
  id = "childAvatar",
  tier,
}: {
  value: string;
  onChange: (id: string) => void;
  id?: string;
  /** Limits the character set to ones that suit the child's age tier */
  tier?: AgeTierId;
}) {
  const options = tier ? avatarsForTier(tier) : CHILD_AVATARS;
  return (
    <div>
      <Label htmlFor={id}>{tier === "forge" ? "Profile identity" : "Character"}</Label>
      <div id={id} className="mt-2 grid grid-cols-5 gap-2">
        {options.map((option) => {

          const selected = option.id === value;
          return (
            <button
              key={option.id}
              type="button"
              onClick={() => onChange(option.id)}
              title={option.label}
              aria-label={option.label}
              aria-pressed={selected}
              className={cn(
                "relative flex aspect-square items-center justify-center rounded-xl border text-xl transition-all",
                option.className,
                selected
                  ? "border-primary ring-2 ring-primary/40"
                  : "border-border/50 hover:border-primary/40",
              )}
            >
              {option.emoji}
              {selected && (
                <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Check className="h-3 w-3" />
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
