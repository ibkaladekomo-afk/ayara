import { useEffect, useMemo, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { Loader2, Mic, Send, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Aya } from "@/components/aya";
import { cn } from "@/lib/utils";
import { useReadAloud, useVoiceInput } from "@/lib/use-voice";
import type { AgeTier } from "@/lib/age-tiers";
import { activitiesForGrade, type CreativeActivity } from "@/lib/onboarding-journey";

interface ChildLike {
  id: string;
  name: string;
  age: number;
  grade: string | null;
  language: string;
  interests: string[] | null;
}

function textOf(parts: { type: string; text?: string }[]): string {
  return parts.map((p) => (p.type === "text" ? (p.text ?? "") : "")).join("");
}

/* --------------------------- First conversation -------------------------- */

export function ConversationStep({
  child,
  tier,
  speakIntro,
  onDone,
}: {
  child: ChildLike;
  tier: AgeTier;
  speakIntro?: string;
  onDone: () => void;
}) {
  const isSpark = tier.id === "spark";
  const opener = isSpark
    ? "If you could invent anything in the world, what would it be?"
    : "If you could build one thing that actually helps people, what would it be?";

  const [draft, setDraft] = useState("");
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [exchanges, setExchanges] = useState(0);
  const { speak, stop } = useReadAloud();
  const spokenRef = useRef<string | null>(null);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        body: {
          childProfile: {
            name: child.name,
            age: child.age,
            grade: child.grade ?? undefined,
            language: child.language,
            interests: child.interests ?? [],
          },
          tier: { id: tier.id, label: tier.label, tone: tier.tone, gradeRange: tier.gradeRange },
          worldPrompt:
            "This is the child's very first conversation in Ayara. Celebrate their idea warmly and specifically, add one imaginative detail, then ask exactly one follow-up question. Never ask for personal details. Keep it brief.",
          character: "Aya",
        },
      }),
    [child, tier],
  );

  const { messages, sendMessage, status } = useChat({ id: `onboarding-${child.id}`, transport });
  const busy = status === "submitted" || status === "streaming";

  const voice = useVoiceInput({
    language: child.language,
    onTranscript: (text) => setDraft((d) => (d ? `${d} ${text}` : text)),
    onError: (message) => setVoiceError(message),
  });

  useEffect(() => {
    if (!isSpark) return;
    if (spokenRef.current === "opener") return;
    spokenRef.current = "opener";
    speak(speakIntro ? `${speakIntro} ${opener}` : opener);
    return () => stop();
  }, [isSpark, opener, speakIntro, speak, stop]);

  const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");
  const reply = lastAssistant ? textOf(lastAssistant.parts as { type: string; text?: string }[]) : "";

  useEffect(() => {
    if (!isSpark || !reply || busy) return;
    if (spokenRef.current === reply) return;
    spokenRef.current = reply;
    speak(reply);
  }, [isSpark, reply, busy, speak]);

  const send = () => {
    const text = draft.trim();
    if (!text || busy) return;
    setDraft("");
    setExchanges((n) => n + 1);
    void sendMessage({ text });
  };

  return (
    <div className="space-y-6">
      <div className={cn("flex gap-3", isSpark ? "flex-col items-center text-center" : "items-start")}>
        {isSpark && <Aya size="md" mood="wave" />}
        <p className={cn("rounded-2xl bg-card px-4 py-3 shadow-sm", isSpark ? "text-lg" : "text-base")}>{opener}</p>
      </div>

      <div className="space-y-3">
        {messages.map((message) => {
          const text = textOf(message.parts as { type: string; text?: string }[]);
          if (!text) return null;
          return (
            <div
              key={message.id}
              className={cn(
                "max-w-[85%] rounded-2xl px-4 py-3",
                message.role === "user"
                  ? "ml-auto bg-primary text-primary-foreground"
                  : "bg-card text-foreground shadow-sm",
              )}
            >
              {text}
            </div>
          );
        })}
        {busy && !reply && (
          <p className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Aya is thinking…
          </p>
        )}
      </div>

      <div className="space-y-3">
        <Textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={isSpark ? "Say it or type it here…" : "Type your answer…"}
          rows={isSpark ? 2 : 3}
          className={cn("rounded-2xl", isSpark && "text-lg")}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
        />
        {voiceError && (
          <p role="status" className="text-sm text-muted-foreground">
            {voiceError}
          </p>
        )}
        <div className="flex flex-wrap items-center gap-3">
          <Button
            type="button"
            variant={voice.isRecording ? "destructive" : "outline"}
            className="min-h-12 rounded-full"
            disabled={voice.isTranscribing}
            onClick={() => (voice.isRecording ? void voice.stop() : void voice.start())}
          >
            {voice.isTranscribing ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : voice.isRecording ? (
              <Square className="mr-2 h-4 w-4" />
            ) : (
              <Mic className="mr-2 h-4 w-4" />
            )}
            {voice.isRecording ? "Stop" : voice.isTranscribing ? "Listening…" : "Say it"}
          </Button>
          <Button type="button" className="min-h-12 rounded-full" disabled={!draft.trim() || busy} onClick={send}>
            <Send className="mr-2 h-4 w-4" />
            Send
          </Button>
          {exchanges > 0 && !busy && (
            <Button type="button" variant="ghost" className="ml-auto min-h-12 rounded-full" onClick={onDone}>
              Keep going →
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------- First creation ----------------------------- */

export function CreationStep({
  child,
  tier,
  onSave,
  saving,
}: {
  child: ChildLike;
  tier: AgeTier;
  onSave: (item: { activity: CreativeActivity; text: string; drawing: string | null }) => void;
  saving: boolean;
}) {
  const activities = useMemo(() => activitiesForGrade(child.grade, child.age), [child.grade, child.age]);
  const [activity, setActivity] = useState<CreativeActivity | null>(null);
  const [text, setText] = useState("");
  const [drawing, setDrawing] = useState<string | null>(null);
  const isSpark = tier.id === "spark";

  if (!activity) {
    return (
      <div className="grid gap-3 sm:grid-cols-3">
        {activities.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => setActivity(option)}
            className="flex min-h-32 flex-col justify-between rounded-2xl border-2 border-border/60 bg-card p-4 text-left transition-colors hover:border-primary"
          >
            <span className="font-heading text-base font-semibold text-foreground">{option.title}</span>
            <span className="mt-2 text-sm text-muted-foreground">{option.prompt}</span>
          </button>
        ))}
      </div>
    );
  }

  const canSave = activity.drawing ? Boolean(drawing) : text.trim().length > 0;

  return (
    <div className="space-y-4">
      <p className={cn("text-foreground", isSpark ? "text-lg" : "text-base")}>{activity.prompt}</p>

      {activity.drawing ? (
        <DrawingPad onChange={setDrawing} />
      ) : (
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={activity.placeholder}
          rows={isSpark ? 4 : 7}
          className={cn("rounded-2xl", isSpark && "text-lg")}
        />
      )}

      <div className="flex flex-wrap gap-3">
        <Button variant="ghost" className="min-h-11 rounded-full" onClick={() => setActivity(null)}>
          Pick a different one
        </Button>
        <Button
          className="ml-auto min-h-11 rounded-full px-8"
          disabled={!canSave || saving}
          onClick={() => onSave({ activity, text: text.trim(), drawing })}
        >
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Save to my portfolio
        </Button>
      </div>
    </div>
  );
}

function DrawingPad({ onChange }: { onChange: (dataUrl: string | null) => void }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const [color, setColor] = useState("#8b5cf6");
  const colors = ["#8b5cf6", "#2563eb", "#e11d48", "#16a34a", "#f59e0b", "#1f2937"];

  const point = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const begin = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const ctx = canvasRef.current!.getContext("2d")!;
    const { x, y } = point(e);
    drawingRef.current = true;
    ctx.strokeStyle = color;
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(x, y);
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const move = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return;
    const ctx = canvasRef.current!.getContext("2d")!;
    const { x, y } = point(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const end = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    onChange(canvasRef.current!.toDataURL("image/png"));
  };

  const clear = () => {
    const canvas = canvasRef.current!;
    canvas.getContext("2d")!.clearRect(0, 0, canvas.width, canvas.height);
    onChange(null);
  };

  return (
    <div className="space-y-3">
      <canvas
        ref={canvasRef}
        width={640}
        height={420}
        onPointerDown={begin}
        onPointerMove={move}
        onPointerUp={end}
        onPointerLeave={end}
        aria-label="Drawing area"
        className="w-full touch-none rounded-2xl border-2 border-border bg-card"
      />
      <div className="flex flex-wrap items-center gap-2">
        {colors.map((c) => (
          <button
            key={c}
            type="button"
            aria-label={`Use colour ${c}`}
            aria-pressed={color === c}
            onClick={() => setColor(c)}
            style={{ backgroundColor: c }}
            className={cn("h-11 w-11 rounded-full border-2", color === c ? "border-foreground" : "border-transparent")}
          />
        ))}
        <Button variant="ghost" className="ml-auto min-h-11 rounded-full" onClick={clear}>
          Clear
        </Button>
      </div>
    </div>
  );
}
