import { useEffect, useRef, type ReactNode } from "react";
import { Volume2, VolumeX, Wind } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useReadAloud } from "@/lib/use-voice";
import type { AgeTierId } from "@/lib/age-tiers";

/**
 * Shared frame for every onboarding beat: narrated line with a visible
 * caption, a progress rail, a motion toggle and one clear way forward.
 */
export function StepShell({
  tier,
  title,
  narration,
  progress,
  autoSpeak = true,
  reducedMotion,
  onToggleMotion,
  aside,
  children,
  footer,
}: {
  tier: AgeTierId;
  title: string;
  narration: string;
  progress: number;
  autoSpeak?: boolean;
  reducedMotion: boolean;
  onToggleMotion: (value: boolean) => void;
  aside?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const { speak, speaking, stop } = useReadAloud();
  const spokenRef = useRef<string | null>(null);
  const isSpark = tier === "spark";

  useEffect(() => {
    if (!autoSpeak || !isSpark) return;
    if (spokenRef.current === narration) return;
    spokenRef.current = narration;
    speak(narration);
    return () => stop();
  }, [narration, autoSpeak, isSpark, speak, stop]);

  return (
    <div className="flex min-h-[100dvh] flex-col bg-gradient-to-b from-background via-background to-primary/5">
      <header className="px-4 pt-4">
        <div className="mx-auto flex max-w-3xl items-center gap-3">
          <div
            className="h-2 flex-1 overflow-hidden rounded-full bg-muted"
            role="progressbar"
            aria-valuenow={progress}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Onboarding progress"
          >
            <div
              className={cn("h-full rounded-full bg-primary", !reducedMotion && "transition-all duration-500")}
              style={{ width: `${progress}%` }}
            />
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="min-h-11 min-w-11 rounded-full"
            aria-label={speaking ? "Stop reading aloud" : "Read this aloud"}
            onClick={() => (speaking ? stop() : speak(narration))}
          >
            {speaking ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="min-h-11 min-w-11 rounded-full"
            aria-pressed={reducedMotion}
            aria-label={reducedMotion ? "Turn animation back on" : "Turn animation off"}
            onClick={() => onToggleMotion(!reducedMotion)}
          >
            <Wind className={cn("h-5 w-5", reducedMotion && "text-muted-foreground")} />
          </Button>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-3xl flex-1 flex-col px-4 py-6">
        <h1
          className={cn(
            "font-display text-foreground",
            isSpark ? "text-center text-3xl md:text-4xl" : "text-2xl md:text-3xl",
          )}
        >
          {title}
        </h1>

        <div className={cn("mt-4 flex gap-4", isSpark ? "flex-col items-center text-center" : "items-start")}>
          {aside}
          <p
            className={cn(
              "rounded-2xl bg-card px-4 py-3 text-foreground shadow-sm",
              isSpark ? "text-lg md:text-xl" : "text-base text-muted-foreground",
            )}
          >
            {narration}
          </p>
        </div>

        <div className="mt-8 flex-1">{children}</div>

        {footer && <div className="sticky bottom-0 mt-6 bg-gradient-to-t from-background pt-4">{footer}</div>}
      </main>
    </div>
  );
}
