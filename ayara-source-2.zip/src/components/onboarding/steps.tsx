import { useEffect, useMemo, useState } from "react";
import { Check, Loader2, Lock, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Aya } from "@/components/aya";
import { AvatarBuilder, LayeredAvatar } from "@/components/layered-avatar";
import { cn } from "@/lib/utils";
import type { AgeTierId } from "@/lib/age-tiers";
import { LEARNING_WORLDS } from "@/lib/worlds";
import {
  DEFAULT_AVATAR_CONFIG,
  randomAvatarConfig,
  type AvatarConfig,
} from "@/lib/avatar-builder";
import {
  FIRST_BADGE,
  INTERESTS,
  MENTORS,
  MIN_INTERESTS,
  ONBOARDING_XP,
  QUEST_BEATS,
  QUEST_IDEAS,
  QUEST_PATTERN,
  QUEST_PATTERN_ANSWER,
  QUEST_PATTERN_OPTIONS,
  QUEST_QUESTIONS,
  STARTING_WORLD,
} from "@/lib/onboarding-journey";

/* ------------------------------- Avatar --------------------------------- */

export function AvatarStep({
  initial,
  onDone,
  saving,
}: {
  initial: AvatarConfig | null;
  onDone: (config: AvatarConfig) => void;
  saving: boolean;
}) {
  const [config, setConfig] = useState<AvatarConfig>(initial ?? DEFAULT_AVATAR_CONFIG);

  return (
    <div className="space-y-6">
      <AvatarBuilder config={config} onChange={setConfig} big />
      <div className="flex flex-wrap justify-center gap-3">
        <Button variant="outline" className="min-h-11 rounded-full" onClick={() => setConfig(randomAvatarConfig())}>
          Surprise me
        </Button>
        <Button className="min-h-11 rounded-full px-8" onClick={() => onDone(config)} disabled={saving}>
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          This is me
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------ Interests ------------------------------- */

export function InterestsStep({
  initial,
  onDone,
  saving,
}: {
  initial: string[];
  onDone: (interests: string[]) => void;
  saving: boolean;
}) {
  const [selected, setSelected] = useState<string[]>(initial);
  const toggle = (id: string) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]));
  const enough = selected.length >= MIN_INTERESTS;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {INTERESTS.map((interest) => {
          const on = selected.includes(interest.id);
          return (
            <button
              key={interest.id}
              type="button"
              aria-pressed={on}
              onClick={() => toggle(interest.id)}
              className={cn(
                "flex min-h-16 items-center gap-3 rounded-2xl border-2 px-4 py-3 text-left transition-colors",
                on ? "border-primary bg-primary/10" : "border-border/60 bg-card hover:border-primary/40",
              )}
            >
              <span aria-hidden className="text-2xl">
                {interest.emoji}
              </span>
              <span className="font-heading text-sm font-semibold text-foreground">{interest.label}</span>
              {on && <Check className="ml-auto h-4 w-4 text-primary" />}
            </button>
          );
        })}
      </div>
      <div className="flex flex-col items-center gap-2">
        <p aria-live="polite" className="text-sm text-muted-foreground">
          {enough ? `${selected.length} picked` : `Pick at least ${MIN_INTERESTS} — you can change these later.`}
        </p>
        <Button
          className="min-h-11 rounded-full px-8"
          disabled={!enough || saving}
          onClick={() => onDone(selected)}
        >
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Save my picks
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------- Mentors -------------------------------- */

export function MentorsStep({ tier, onDone }: { tier: AgeTierId; onDone: () => void }) {
  const [index, setIndex] = useState(0);
  const mentor = MENTORS[index]!;
  const last = index === MENTORS.length - 1;

  return (
    <div className="space-y-6">
      <div
        key={mentor.id}
        className={cn(
          "mx-auto flex max-w-md flex-col items-center gap-4 rounded-3xl bg-gradient-to-br p-8 text-center text-primary-foreground motion-safe:animate-scale-in",
          mentor.tile,
        )}
      >
        <span aria-hidden className="text-6xl">
          {mentor.emoji}
        </span>
        <h2 className="font-display text-2xl">{mentor.name}</h2>
        <p className="text-sm opacity-90">{mentor.role}</p>
        <p className="text-lg">{tier === "forge" ? mentor.forgeLine : mentor.sparkLine}</p>
      </div>

      <div className="flex items-center justify-center gap-2" aria-hidden>
        {MENTORS.map((m, i) => (
          <span key={m.id} className={cn("h-2 w-2 rounded-full", i <= index ? "bg-primary" : "bg-muted")} />
        ))}
      </div>

      <div className="flex justify-center gap-3">
        <Button variant="ghost" className="min-h-11 rounded-full" onClick={onDone}>
          Skip
        </Button>
        <Button
          className="min-h-11 rounded-full px-8"
          onClick={() => (last ? onDone() : setIndex((i) => i + 1))}
        >
          {last ? "Nice to meet you all" : "Next"}
        </Button>
      </div>
    </div>
  );
}

/* --------------------------- Curiosity Quest ----------------------------- */

export function QuestStep({
  tier,
  beatIndex,
  onBeatDone,
  onNarration,
}: {
  tier: AgeTierId;
  beatIndex: number;
  onBeatDone: (state: Record<string, unknown>) => void;
  onNarration: (line: string) => void;
}) {
  const beat = QUEST_BEATS[Math.min(beatIndex, QUEST_BEATS.length - 1)]!;
  const line = tier === "forge" ? beat.forgeLine : beat.sparkLine;

  useEffect(() => {
    onNarration(line);
  }, [line, onNarration]);

  return (
    <div className="space-y-6">
      <p className="text-center font-heading text-sm font-semibold uppercase tracking-wide text-muted-foreground">
        Fragment {Math.min(beatIndex + 1, QUEST_BEATS.length)} of {QUEST_BEATS.length}
      </p>
      {beat.id === "tap" && <TapBeat onDone={() => onBeatDone({ tap: true })} />}
      {beat.id === "listen" && <ListenBeat onDone={() => onBeatDone({ listen: true })} />}
      {beat.id === "ask" && <AskBeat onDone={(q) => onBeatDone({ ask: q })} />}
      {beat.id === "choose" && <ChooseBeat onDone={(idea) => onBeatDone({ choose: idea })} />}
      {beat.id === "puzzle" && <PuzzleBeat onDone={() => onBeatDone({ puzzle: true })} />}
    </div>
  );
}

function TapBeat({ onDone }: { onDone: () => void }) {
  const [tapped, setTapped] = useState<number[]>([]);
  const spots = useMemo(
    () => [
      { top: "10%", left: "12%" },
      { top: "44%", left: "70%" },
      { top: "68%", left: "25%" },
    ],
    [],
  );
  const all = tapped.length === spots.length;

  return (
    <div>
      <div className="relative mx-auto h-64 w-full max-w-md overflow-hidden rounded-3xl bg-gradient-to-br from-primary/15 to-secondary/20">
        {spots.map((spot, i) => (
          <button
            key={i}
            type="button"
            aria-label={`Spark fragment ${i + 1}`}
            disabled={tapped.includes(i)}
            onClick={() => setTapped((t) => [...t, i])}
            style={spot}
            className={cn(
              "absolute flex h-14 w-14 items-center justify-center rounded-full text-2xl",
              tapped.includes(i)
                ? "bg-primary/20 opacity-40"
                : "bg-[oklch(0.85_0.13_95)] motion-safe:animate-[pulse_1.6s_ease-in-out_infinite]",
            )}
          >
            ✨
          </button>
        ))}
      </div>
      <div className="mt-6 flex justify-center">
        <Button className="min-h-11 rounded-full px-8" disabled={!all} onClick={onDone}>
          {all ? "All found!" : `${tapped.length} of ${spots.length} found`}
        </Button>
      </div>
    </div>
  );
}

function ListenBeat({ onDone }: { onDone: () => void }) {
  const [played, setPlayed] = useState(false);
  return (
    <div className="flex flex-col items-center gap-6">
      <Aya size="md" mood="wave" />
      <Button
        variant="outline"
        className="min-h-14 rounded-full px-8 text-lg"
        onClick={() => setPlayed(true)}
      >
        🔊 Listen for the Spark
      </Button>
      <p aria-live="polite" className="text-center text-muted-foreground">
        {played ? "There it is — a soft hum, just ahead." : "Press the button to listen."}
      </p>
      <Button className="min-h-11 rounded-full px-8" disabled={!played} onClick={onDone}>
        Follow the sound
      </Button>
    </div>
  );
}

function AskBeat({ onDone }: { onDone: (question: string) => void }) {
  return (
    <div className="mx-auto grid max-w-md gap-3">
      {QUEST_QUESTIONS.map((q) => (
        <button
          key={q}
          type="button"
          onClick={() => onDone(q)}
          className="min-h-14 rounded-2xl border-2 border-border/60 bg-card px-5 py-3 text-left font-heading font-semibold text-foreground transition-colors hover:border-primary"
        >
          {q}
        </button>
      ))}
    </div>
  );
}

function ChooseBeat({ onDone }: { onDone: (idea: string) => void }) {
  return (
    <div className="mx-auto grid max-w-md grid-cols-2 gap-3">
      {QUEST_IDEAS.map((idea) => (
        <button
          key={idea.id}
          type="button"
          onClick={() => onDone(idea.id)}
          className="flex min-h-24 flex-col items-center justify-center gap-2 rounded-2xl border-2 border-border/60 bg-card p-4 text-center transition-colors hover:border-primary"
        >
          <span aria-hidden className="text-3xl">
            {idea.emoji}
          </span>
          <span className="font-heading text-sm font-semibold text-foreground">{idea.label}</span>
        </button>
      ))}
    </div>
  );
}

function PuzzleBeat({ onDone }: { onDone: () => void }) {
  const [wrong, setWrong] = useState(false);
  const [solved, setSolved] = useState(false);

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex items-center gap-3 text-4xl" aria-label="Pattern to complete">
        {QUEST_PATTERN.map((p, i) => (
          <span key={i} aria-hidden>
            {p}
          </span>
        ))}
        <span className="flex h-12 w-12 items-center justify-center rounded-xl border-2 border-dashed border-primary text-lg">
          ?
        </span>
      </div>
      <div className="flex gap-3">
        {QUEST_PATTERN_OPTIONS.map((option) => (
          <button
            key={option}
            type="button"
            aria-label={`Choose ${option}`}
            onClick={() => (option === QUEST_PATTERN_ANSWER ? setSolved(true) : setWrong(true))}
            className="flex h-14 w-14 items-center justify-center rounded-2xl border-2 border-border/60 bg-card text-3xl hover:border-primary"
          >
            {option}
          </button>
        ))}
      </div>
      <p aria-live="polite" className="text-center text-muted-foreground">
        {solved ? "That's it — the Spark is back!" : wrong ? "Not quite. Look at the order again." : ""}
      </p>
      <Button className="min-h-11 rounded-full px-8" disabled={!solved} onClick={onDone}>
        Bring back the Spark
      </Button>
    </div>
  );
}

/* ----------------------------- Celebration ------------------------------ */

export function CelebrationStep({
  name,
  avatar,
  onDone,
}: {
  name: string;
  avatar: AvatarConfig | null;
  onDone: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-6 text-center">
      <div className="relative">
        <LayeredAvatar config={avatar} size="xl" label={`${name}'s character`} />
        <span className="absolute -right-2 -top-2 text-4xl motion-safe:animate-[aya-pop_900ms_ease-out]">🎉</span>
      </div>
      <div className="rounded-3xl bg-gradient-to-br from-primary/15 to-secondary/20 px-8 py-6">
        <p className="font-heading text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Badge unlocked
        </p>
        <p className="mt-2 font-display text-3xl text-foreground">
          {FIRST_BADGE.emoji} {FIRST_BADGE.label}
        </p>
        <p className="mt-2 text-muted-foreground">+{ONBOARDING_XP} XP · Certificate progress started</p>
      </div>
      <Button className="min-h-11 rounded-full px-8" onClick={onDone}>
        See my worlds
      </Button>
    </div>
  );
}

/* ------------------------------ World map -------------------------------- */

export function WorldMapStep({ onDone }: { onDone: () => void }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {LEARNING_WORLDS.map((world) => {
          const unlocked = world.id === STARTING_WORLD;
          return (
            <div
              key={world.id}
              className={cn(
                "flex min-h-32 flex-col justify-between rounded-2xl bg-gradient-to-br p-4 text-primary-foreground",
                world.tile,
                unlocked ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : "opacity-45 grayscale",
              )}
            >
              <span aria-hidden className="text-3xl">
                {unlocked ? world.emoji : ""}
              </span>
              <div>
                <p className="font-heading font-semibold">{world.name}</p>
                <p className="mt-1 flex items-center gap-1 text-xs opacity-90">
                  {unlocked ? (
                    <>
                      <Sparkles className="h-3 w-3" /> Open now
                    </>
                  ) : (
                    <>
                      <Lock className="h-3 w-3" /> Unlocks soon
                    </>
                  )}
                </p>
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex justify-center">
        <Button className="min-h-11 rounded-full px-8" onClick={onDone}>
          Go to my home
        </Button>
      </div>
    </div>
  );
}
