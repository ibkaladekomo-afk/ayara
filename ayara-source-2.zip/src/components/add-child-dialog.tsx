import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { createChildProfile } from "@/lib/child-profiles.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { AvatarPicker, TierBadge } from "@/components/child-avatar";
import { avatarsForTier, defaultAvatarForTier } from "@/lib/child-avatars";
import { GRADE_OPTIONS, getAgeTier } from "@/lib/age-tiers";
import { Loader2, Plus } from "lucide-react";

const selectClass =
  "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

export function AddChildDialog() {
  const queryClient = useQueryClient();
  const addChild = useServerFn(createChildProfile);

  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [pin, setPin] = useState("");
  const [age, setAge] = useState("8");
  const [grade, setGrade] = useState("");
  const [language, setLanguage] = useState<"en" | "es">("en");
  const [interests, setInterests] = useState("");
  const [avatar, setAvatar] = useState(defaultAvatarForTier("spark"));
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const tier = useMemo(() => getAgeTier({ age: Number(age), grade: grade || null }), [age, grade]);

  // Keep the chosen character valid for the tier the parent just selected.
  const validAvatar = avatarsForTier(tier.id).some((a) => a.id === avatar)
    ? avatar
    : defaultAvatarForTier(tier.id);
  if (validAvatar !== avatar) setAvatar(validAvatar);

  const reset = () => {
    setName("");
    setUsername("");
    setPin("");
    setAge("8");
    setGrade("");
    setLanguage("en");
    setInterests("");
    setAvatar(defaultAvatarForTier("spark"));
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setPending(true);
    try {
      await addChild({
        data: {
          name,
          username: username.trim().toLowerCase(),
          pin,
          age: Number(age),
          grade: grade || undefined,
          language,
          avatar,
          interests: interests
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean),
        },
      });
      await queryClient.invalidateQueries({ queryKey: ["childProfiles"] });
      reset();
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to add child profile.");
    } finally {
      setPending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Plus className="mr-1.5 h-4 w-4" />
          Add child
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add a child profile</DialogTitle>
          <DialogDescription>
            AYARA adapts the characters, tone and activities to each child's grade.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="newChildName">Child's first name</Label>
            <Input
              id="newChildName"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Alex"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="newChildUsername">Kid username</Label>
              <Input
                id="newChildUsername"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="alex2026"
                autoCapitalize="none"
                minLength={3}
                required
              />
            </div>
            <div>
              <Label htmlFor="newChildPin">4-digit PIN</Label>
              <Input
                id="newChildPin"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                inputMode="numeric"
                placeholder="1234"
                minLength={4}
                required
              />
            </div>
          </div>
          <p className="-mt-2 text-xs text-muted-foreground">
            Your child signs in at Kid login with this username and PIN — they never need your password.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="newChildAge">Age</Label>
              <Input
                id="newChildAge"
                type="number"
                min={3}
                max={18}
                value={age}
                onChange={(e) => setAge(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="newChildGrade">Grade</Label>
              <select
                id="newChildGrade"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className={selectClass}
              >
                <option value="">Use age</option>
                {GRADE_OPTIONS.map((g) => (
                  <option key={g.value} value={g.value}>
                    {g.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="rounded-xl border border-border/60 bg-muted/30 p-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-semibold text-foreground">Experience level</p>
              <TierBadge tier={tier} />
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{tier.description}</p>
          </div>

          <div>
            <Label htmlFor="newChildLanguage">Language</Label>
            <select
              id="newChildLanguage"
              value={language}
              onChange={(e) => setLanguage(e.target.value as "en" | "es")}
              className={selectClass}
            >
              <option value="en">English</option>
              <option value="es">Español</option>
            </select>
          </div>
          <div>
            <Label htmlFor="newChildInterests">Interests (comma separated)</Label>
            <Input
              id="newChildInterests"
              value={interests}
              onChange={(e) => setInterests(e.target.value)}
              placeholder="robots, drawing, space, animals"
            />
          </div>
          <AvatarPicker value={avatar} onChange={setAvatar} id="newChildAvatar" tier={tier.id} />
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" disabled={pending} className="w-full">
              {pending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Add child
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
