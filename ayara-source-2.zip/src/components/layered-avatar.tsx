import { useId } from "react";
import { cn } from "@/lib/utils";
import {
  ACCESSORIES,
  DEFAULT_AVATAR_CONFIG,
  GLASSES_STYLES,
  HAIR_COLORS,
  HAIR_STYLES,
  OUTFIT_COLORS,
  SKIN_TONES,
  colorOf,
  type AvatarConfig,
} from "@/lib/avatar-builder";

const sizeClasses = {
  sm: "h-8 w-8",
  md: "h-12 w-12",
  lg: "h-20 w-20",
  xl: "h-40 w-40",
} as const;

function Hair({ style, color }: { style: string; color: string }) {
  switch (style) {
    case "buzz":
      return <path d="M28 44c0-13 9-21 22-21s22 8 22 21c-6-8-13-11-22-11s-16 3-22 11z" fill={color} />;
    case "curly":
      return (
        <g fill={color}>
          <circle cx="34" cy="34" r="11" />
          <circle cx="50" cy="27" r="12" />
          <circle cx="66" cy="34" r="11" />
          <circle cx="28" cy="46" r="8" />
          <circle cx="72" cy="46" r="8" />
        </g>
      );
    case "afro":
      return <circle cx="50" cy="38" r="27" fill={color} />;
    case "long":
      return (
        <g fill={color}>
          <path d="M24 46c0-16 11-25 26-25s26 9 26 25v34c-5 2-9-4-9-14V44c-6 6-11 8-17 8s-11-2-17-8v36c0 10-4 16-9 14z" />
        </g>
      );
    case "wavy":
      return (
        <g fill={color}>
          <path d="M25 48c0-17 11-27 25-27s25 10 25 27c-4-3-6-9-7-14-5 7-11 10-18 10s-13-3-18-10c-1 5-3 11-7 14z" />
          <path d="M25 48c3 6 2 14-1 20 6-1 9-6 10-12zM75 48c-3 6-2 14 1 20-6-1-9-6-10-12z" />
        </g>
      );
    case "ponytail":
      return (
        <g fill={color}>
          <path d="M28 45c0-14 10-23 22-23s22 9 22 23c-6-9-13-12-22-12s-16 3-22 12z" />
          <path d="M72 42c8 3 12 11 11 21-1 9-6 14-11 15 4-8 5-16 2-24-1-4-2-8-2-12z" />
        </g>
      );
    case "braids":
      return (
        <g fill={color}>
          <path d="M28 45c0-14 10-23 22-23s22 9 22 23c-6-9-13-12-22-12s-16 3-22 12z" />
          <path d="M27 46c-4 8-4 18-1 27 4-1 6-5 6-10s-1-11-5-17zM73 46c4 8 4 18 1 27-4-1-6-5-6-10s1-11 5-17z" />
        </g>
      );
    case "bun":
      return (
        <g fill={color}>
          <circle cx="50" cy="16" r="9" />
          <path d="M28 45c0-14 10-23 22-23s22 9 22 23c-6-9-13-12-22-12s-16 3-22 12z" />
        </g>
      );
    case "hijab":
      return (
        <g fill={color}>
          <path d="M22 50c0-18 12-30 28-30s28 12 28 30c0 12-4 20-9 25l-6-4c3-6 4-12 4-19 0-13-7-21-17-21s-17 8-17 21c0 7 1 13 4 19l-6 4c-5-5-9-13-9-25z" />
          <path d="M28 66c-3 8-3 16 0 22h44c3-6 3-14 0-22-6 7-13 10-22 10s-16-3-22-10z" />
        </g>
      );
    case "short":
    default:
      return (
        <path
          d="M26 47c0-16 10-26 24-26s24 10 24 26c-3-3-5-8-6-13-6 6-11 8-18 8-6 0-12-2-17-7-1 5-3 9-7 12z"
          fill={color}
        />
      );
  }
}

function Glasses({ style }: { style: string }) {
  if (style === "none") return null;
  const stroke = "#2b2b35";
  if (style === "square") {
    return (
      <g fill="none" stroke={stroke} strokeWidth="2.4">
        <rect x="31" y="45" width="16" height="12" rx="2.5" />
        <rect x="53" y="45" width="16" height="12" rx="2.5" />
        <path d="M47 51h6" />
      </g>
    );
  }
  if (style === "sport") {
    return (
      <g>
        <path d="M29 46h42a3 3 0 0 1 3 3v4a8 8 0 0 1-8 8H34a8 8 0 0 1-8-8v-4a3 3 0 0 1 3-3z" fill="#2b2b35" opacity="0.85" />
      </g>
    );
  }
  return (
    <g fill="none" stroke={stroke} strokeWidth="2.4">
      <circle cx="39" cy="51" r="8" />
      <circle cx="61" cy="51" r="8" />
      <path d="M47 51h6" />
    </g>
  );
}

function Accessory({ style, color }: { style: string; color: string }) {
  switch (style) {
    case "headphones":
      return (
        <g>
          <path d="M26 46a24 24 0 0 1 48 0" fill="none" stroke="#2b2b35" strokeWidth="4" strokeLinecap="round" />
          <rect x="20" y="44" width="10" height="16" rx="5" fill={color} />
          <rect x="70" y="44" width="10" height="16" rx="5" fill={color} />
        </g>
      );
    case "cap":
      return (
        <g>
          <path d="M26 42c0-14 10-22 24-22s24 8 24 22z" fill={color} />
          <path d="M24 42h34c0 4-4 7-12 7H30a6 6 0 0 1-6-6z" fill={color} opacity="0.75" />
        </g>
      );
    case "star":
      return <path d="M72 26l3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z" fill="#f5c243" />;
    case "flower":
      return (
        <g>
          <circle cx="74" cy="34" r="4" fill="#ee7ab0" />
          <circle cx="68" cy="34" r="4" fill="#ee7ab0" />
          <circle cx="71" cy="29" r="4" fill="#ee7ab0" />
          <circle cx="71" cy="39" r="4" fill="#ee7ab0" />
          <circle cx="71" cy="34" r="3" fill="#f5c243" />
        </g>
      );
    default:
      return null;
  }
}

export function LayeredAvatar({
  config,
  size = "md",
  className,
  label,
}: {
  config: AvatarConfig | null | undefined;
  size?: keyof typeof sizeClasses;
  className?: string;
  label?: string;
}) {
  const c = config ?? DEFAULT_AVATAR_CONFIG;
  const clipId = useId();
  const skin = colorOf(SKIN_TONES, c.skin, "#dda36a");
  const hair = colorOf(HAIR_COLORS, c.hairColor, "#5a3620");
  const outfit = colorOf(OUTFIT_COLORS, c.outfit, "#4c7cf5");

  return (
    <svg
      viewBox="0 0 100 100"
      role="img"
      aria-label={label ?? "Your Ayara character"}
      className={cn("shrink-0 rounded-full bg-muted", sizeClasses[size], className)}
    >
      <defs>
        <clipPath id={clipId}>
          <circle cx="50" cy="50" r="50" />
        </clipPath>
      </defs>
      <g clipPath={`url(#${clipId})`}>
        <rect width="100" height="100" fill={outfit} opacity="0.16" />
        {/* shoulders */}
        <path d="M50 74c-16 0-28 9-31 26h62c-3-17-15-26-31-26z" fill={outfit} />
        {/* neck */}
        <rect x="43" y="64" width="14" height="14" rx="6" fill={skin} />
        {/* head */}
        <ellipse cx="50" cy="48" rx="22" ry="24" fill={skin} />
        {/* ears */}
        <circle cx="27" cy="50" r="4.5" fill={skin} />
        <circle cx="73" cy="50" r="4.5" fill={skin} />
        {/* face */}
        <circle cx="42" cy="49" r="2.4" fill="#2b2b35" />
        <circle cx="58" cy="49" r="2.4" fill="#2b2b35" />
        <path d="M43 60c2 3 5 4 7 4s5-1 7-4" fill="none" stroke="#2b2b35" strokeWidth="2.2" strokeLinecap="round" />
        <Hair style={c.hair} color={hair} />
        <Glasses style={c.glasses} />
        <Accessory style={c.accessory} color={outfit} />
      </g>
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Builder                                                              */
/* ------------------------------------------------------------------ */

function SwatchRow({
  legend,
  options,
  value,
  onChange,
  big,
}: {
  legend: string;
  options: { id: string; label: string; color: string }[];
  value: string;
  onChange: (id: string) => void;
  big: boolean;
}) {
  return (
    <fieldset>
      <legend className={cn("mb-2 font-heading font-semibold text-foreground", big ? "text-base" : "text-sm")}>
        {legend}
      </legend>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            aria-label={o.label}
            aria-pressed={value === o.id}
            onClick={() => onChange(o.id)}
            style={{ backgroundColor: o.color }}
            className={cn(
              "rounded-full border-2 transition-transform",
              big ? "h-11 w-11" : "h-11 w-11",
              value === o.id ? "border-primary scale-110 ring-2 ring-primary/40" : "border-border/60 hover:scale-105",
            )}
          />
        ))}
      </div>
    </fieldset>
  );
}

function ChipRow({
  legend,
  options,
  value,
  onChange,
  big,
}: {
  legend: string;
  options: { id: string; label: string }[];
  value: string;
  onChange: (id: string) => void;
  big: boolean;
}) {
  return (
    <fieldset>
      <legend className={cn("mb-2 font-heading font-semibold text-foreground", big ? "text-base" : "text-sm")}>
        {legend}
      </legend>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            aria-pressed={value === o.id}
            onClick={() => onChange(o.id)}
            className={cn(
              "min-h-11 rounded-full border px-4 text-sm font-medium transition-colors",
              value === o.id
                ? "border-primary bg-primary/10 text-primary"
                : "border-border/60 text-foreground hover:border-primary/50",
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

export function AvatarBuilder({
  config,
  onChange,
  big = false,
}: {
  config: AvatarConfig;
  onChange: (next: AvatarConfig) => void;
  big?: boolean;
}) {
  const set = (patch: Partial<AvatarConfig>) => onChange({ ...config, ...patch });

  return (
    <div className="grid gap-6 md:grid-cols-[auto_1fr] md:items-start">
      <div className="mx-auto">
        <LayeredAvatar config={config} size="xl" label="Preview of your character" />
      </div>
      <div className="space-y-5">
        <SwatchRow legend="Skin" options={SKIN_TONES} value={config.skin} onChange={(skin) => set({ skin })} big={big} />
        <ChipRow legend="Hair" options={HAIR_STYLES} value={config.hair} onChange={(hair) => set({ hair })} big={big} />
        <SwatchRow
          legend="Hair color"
          options={HAIR_COLORS}
          value={config.hairColor}
          onChange={(hairColor) => set({ hairColor })}
          big={big}
        />
        <ChipRow
          legend="Glasses"
          options={GLASSES_STYLES}
          value={config.glasses}
          onChange={(glasses) => set({ glasses })}
          big={big}
        />
        <SwatchRow
          legend="Clothes"
          options={OUTFIT_COLORS}
          value={config.outfit}
          onChange={(outfit) => set({ outfit })}
          big={big}
        />
        <ChipRow
          legend="Accessory"
          options={ACCESSORIES}
          value={config.accessory}
          onChange={(accessory) => set({ accessory })}
          big={big}
        />
      </div>
    </div>
  );
}
