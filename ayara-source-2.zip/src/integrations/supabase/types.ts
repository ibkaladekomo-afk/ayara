export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      child_badges: {
        Row: {
          badge_id: string
          child_id: string
          created_at: string
          earned_at: string
          id: string
          parent_id: string
        }
        Insert: {
          badge_id: string
          child_id: string
          created_at?: string
          earned_at?: string
          id?: string
          parent_id: string
        }
        Update: {
          badge_id?: string
          child_id?: string
          created_at?: string
          earned_at?: string
          id?: string
          parent_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_badges_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_badges_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_celebrations: {
        Row: {
          child_id: string
          created_at: string
          id: string
          key: string
          message: string
          parent_id: string
          title: string
        }
        Insert: {
          child_id: string
          created_at?: string
          id?: string
          key: string
          message: string
          parent_id: string
          title: string
        }
        Update: {
          child_id?: string
          created_at?: string
          id?: string
          key?: string
          message?: string
          parent_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_celebrations_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_celebrations_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_cosmetics: {
        Row: {
          category: string
          child_id: string
          coins_spent: number
          created_at: string
          equipped: boolean
          id: string
          item_id: string
          parent_id: string
        }
        Insert: {
          category: string
          child_id: string
          coins_spent?: number
          created_at?: string
          equipped?: boolean
          id?: string
          item_id: string
          parent_id: string
        }
        Update: {
          category?: string
          child_id?: string
          coins_spent?: number
          created_at?: string
          equipped?: boolean
          id?: string
          item_id?: string
          parent_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_cosmetics_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_cosmetics_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_creations: {
        Row: {
          child_id: string
          created_at: string
          emoji: string
          id: string
          kind: string
          name: string
          origin_world: string
          parent_creation_id: string | null
          parent_id: string
          portfolio_item_id: string | null
          summary: string | null
          traits: Json
          updated_at: string
        }
        Insert: {
          child_id: string
          created_at?: string
          emoji?: string
          id?: string
          kind: string
          name: string
          origin_world: string
          parent_creation_id?: string | null
          parent_id: string
          portfolio_item_id?: string | null
          summary?: string | null
          traits?: Json
          updated_at?: string
        }
        Update: {
          child_id?: string
          created_at?: string
          emoji?: string
          id?: string
          kind?: string
          name?: string
          origin_world?: string
          parent_creation_id?: string | null
          parent_id?: string
          portfolio_item_id?: string | null
          summary?: string | null
          traits?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_creations_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_creations_parent_creation_id_fkey"
            columns: ["parent_creation_id"]
            isOneToOne: false
            referencedRelation: "child_creations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_creations_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_creations_portfolio_item_id_fkey"
            columns: ["portfolio_item_id"]
            isOneToOne: false
            referencedRelation: "portfolio_items"
            referencedColumns: ["id"]
          },
        ]
      }
      child_discoveries: {
        Row: {
          child_id: string
          created_at: string
          discovery_id: string
          found_at: string
          id: string
          parent_id: string
          world_id: string
        }
        Insert: {
          child_id: string
          created_at?: string
          discovery_id: string
          found_at?: string
          id?: string
          parent_id: string
          world_id: string
        }
        Update: {
          child_id?: string
          created_at?: string
          discovery_id?: string
          found_at?: string
          id?: string
          parent_id?: string
          world_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_discoveries_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_discoveries_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_events: {
        Row: {
          child_id: string
          created_at: string
          event: string
          id: string
          metadata: Json
          parent_id: string
        }
        Insert: {
          child_id: string
          created_at?: string
          event: string
          id?: string
          metadata?: Json
          parent_id: string
        }
        Update: {
          child_id?: string
          created_at?: string
          event?: string
          id?: string
          metadata?: Json
          parent_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_events_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_events_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_missions: {
        Row: {
          assigned_on: string
          badge_reward: string | null
          child_confirmed_at: string | null
          child_id: string
          completed_at: string | null
          conversation_id: string | null
          created_at: string
          crystal_reward: number
          difficulty: string
          estimated_minutes: number
          expires_at: string | null
          family_role: string | null
          id: string
          kind: string
          last_step_label: string | null
          parent_confirmed_at: string | null
          parent_id: string
          progress_step: number
          prompt: string
          season_id: string | null
          status: string
          steps: Json
          template_id: string | null
          title: string
          total_steps: number
          updated_at: string
          week_of: string | null
          world_id: string
          xp_reward: number
        }
        Insert: {
          assigned_on?: string
          badge_reward?: string | null
          child_confirmed_at?: string | null
          child_id: string
          completed_at?: string | null
          conversation_id?: string | null
          created_at?: string
          crystal_reward?: number
          difficulty?: string
          estimated_minutes?: number
          expires_at?: string | null
          family_role?: string | null
          id?: string
          kind?: string
          last_step_label?: string | null
          parent_confirmed_at?: string | null
          parent_id: string
          progress_step?: number
          prompt: string
          season_id?: string | null
          status?: string
          steps?: Json
          template_id?: string | null
          title: string
          total_steps?: number
          updated_at?: string
          week_of?: string | null
          world_id: string
          xp_reward?: number
        }
        Update: {
          assigned_on?: string
          badge_reward?: string | null
          child_confirmed_at?: string | null
          child_id?: string
          completed_at?: string | null
          conversation_id?: string | null
          created_at?: string
          crystal_reward?: number
          difficulty?: string
          estimated_minutes?: number
          expires_at?: string | null
          family_role?: string | null
          id?: string
          kind?: string
          last_step_label?: string | null
          parent_confirmed_at?: string | null
          parent_id?: string
          progress_step?: number
          prompt?: string
          season_id?: string | null
          status?: string
          steps?: Json
          template_id?: string | null
          title?: string
          total_steps?: number
          updated_at?: string
          week_of?: string | null
          world_id?: string
          xp_reward?: number
        }
        Relationships: [
          {
            foreignKeyName: "child_missions_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_missions_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_missions_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_onboarding: {
        Row: {
          child_id: string
          completed_at: string | null
          created_at: string
          current_step: string
          id: string
          parent_id: string
          quest_state: Json
          started_at: string
          updated_at: string
        }
        Insert: {
          child_id: string
          completed_at?: string | null
          created_at?: string
          current_step?: string
          id?: string
          parent_id: string
          quest_state?: Json
          started_at?: string
          updated_at?: string
        }
        Update: {
          child_id?: string
          completed_at?: string | null
          created_at?: string
          current_step?: string
          id?: string
          parent_id?: string
          quest_state?: Json
          started_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_onboarding_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: true
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_onboarding_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_profiles: {
        Row: {
          age: number
          avatar: string
          avatar_config: Json | null
          created_at: string
          family_id: string | null
          grade: string | null
          id: string
          interests: string[] | null
          language: string
          name: string
          parent_id: string
          pin_hash: string | null
          updated_at: string
          username: string | null
        }
        Insert: {
          age: number
          avatar?: string
          avatar_config?: Json | null
          created_at?: string
          family_id?: string | null
          grade?: string | null
          id?: string
          interests?: string[] | null
          language?: string
          name: string
          parent_id: string
          pin_hash?: string | null
          updated_at?: string
          username?: string | null
        }
        Update: {
          age?: number
          avatar?: string
          avatar_config?: Json | null
          created_at?: string
          family_id?: string | null
          grade?: string | null
          id?: string
          interests?: string[] | null
          language?: string
          name?: string
          parent_id?: string
          pin_hash?: string | null
          updated_at?: string
          username?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "child_profiles_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_profiles_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_progress: {
        Row: {
          child_id: string
          created_at: string
          grace_used_on: string | null
          id: string
          last_active_on: string | null
          level: number
          parent_id: string
          streak_days: number
          updated_at: string
          xp: number
        }
        Insert: {
          child_id: string
          created_at?: string
          grace_used_on?: string | null
          id?: string
          last_active_on?: string | null
          level?: number
          parent_id: string
          streak_days?: number
          updated_at?: string
          xp?: number
        }
        Update: {
          child_id?: string
          created_at?: string
          grace_used_on?: string | null
          id?: string
          last_active_on?: string | null
          level?: number
          parent_id?: string
          streak_days?: number
          updated_at?: string
          xp?: number
        }
        Relationships: [
          {
            foreignKeyName: "child_progress_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: true
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_progress_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_sessions: {
        Row: {
          child_id: string
          created_at: string
          expires_at: string
          id: string
          token: string
          updated_at: string
        }
        Insert: {
          child_id: string
          created_at?: string
          expires_at: string
          id?: string
          token: string
          updated_at?: string
        }
        Update: {
          child_id?: string
          created_at?: string
          expires_at?: string
          id?: string
          token?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_sessions_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_wallets: {
        Row: {
          child_id: string
          coins: number
          created_at: string
          crystals: number
          id: string
          parent_id: string
          updated_at: string
        }
        Insert: {
          child_id: string
          coins?: number
          created_at?: string
          crystals?: number
          id?: string
          parent_id: string
          updated_at?: string
        }
        Update: {
          child_id?: string
          coins?: number
          created_at?: string
          crystals?: number
          id?: string
          parent_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_wallets_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: true
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_wallets_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_world_progress: {
        Row: {
          child_id: string
          completed_stages: string[]
          created_at: string
          crystals: number
          entered_count: number
          id: string
          last_entered_at: string | null
          master_project_item_id: string | null
          master_project_status: string
          parent_id: string
          stage_index: number
          updated_at: string
          world_id: string
        }
        Insert: {
          child_id: string
          completed_stages?: string[]
          created_at?: string
          crystals?: number
          entered_count?: number
          id?: string
          last_entered_at?: string | null
          master_project_item_id?: string | null
          master_project_status?: string
          parent_id: string
          stage_index?: number
          updated_at?: string
          world_id: string
        }
        Update: {
          child_id?: string
          completed_stages?: string[]
          created_at?: string
          crystals?: number
          entered_count?: number
          id?: string
          last_entered_at?: string | null
          master_project_item_id?: string | null
          master_project_status?: string
          parent_id?: string
          stage_index?: number
          updated_at?: string
          world_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_world_progress_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_world_progress_master_project_item_id_fkey"
            columns: ["master_project_item_id"]
            isOneToOne: false
            referencedRelation: "portfolio_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_world_progress_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      child_world_unlocks: {
        Row: {
          child_id: string
          created_at: string
          id: string
          parent_id: string
          unlocked_at: string
          world_id: string
        }
        Insert: {
          child_id: string
          created_at?: string
          id?: string
          parent_id: string
          unlocked_at?: string
          world_id: string
        }
        Update: {
          child_id?: string
          created_at?: string
          id?: string
          parent_id?: string
          unlocked_at?: string
          world_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "child_world_unlocks_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "child_world_unlocks_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      coin_grants: {
        Row: {
          amount: number
          child_id: string
          created_at: string
          id: string
          note: string | null
          parent_id: string
        }
        Insert: {
          amount: number
          child_id: string
          created_at?: string
          id?: string
          note?: string | null
          parent_id: string
        }
        Update: {
          amount?: number
          child_id?: string
          created_at?: string
          id?: string
          note?: string | null
          parent_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "coin_grants_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "coin_grants_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      conversation_summaries: {
        Row: {
          child_id: string
          conversation_id: string
          created_at: string
          id: string
          message_count: number
          minutes: number
          parent_id: string
          skills: string[]
          summary: string
          themes: string[]
          updated_at: string
          world_id: string | null
        }
        Insert: {
          child_id: string
          conversation_id: string
          created_at?: string
          id?: string
          message_count?: number
          minutes?: number
          parent_id: string
          skills?: string[]
          summary: string
          themes?: string[]
          updated_at?: string
          world_id?: string | null
        }
        Update: {
          child_id?: string
          conversation_id?: string
          created_at?: string
          id?: string
          message_count?: number
          minutes?: number
          parent_id?: string
          skills?: string[]
          summary?: string
          themes?: string[]
          updated_at?: string
          world_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "conversation_summaries_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_summaries_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: true
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_summaries_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          child_id: string
          created_at: string
          id: string
          parent_id: string
          title: string | null
          updated_at: string
        }
        Insert: {
          child_id: string
          created_at?: string
          id?: string
          parent_id: string
          title?: string | null
          updated_at?: string
        }
        Update: {
          child_id?: string
          created_at?: string
          id?: string
          parent_id?: string
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversations_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      creation_appearances: {
        Row: {
          child_id: string
          conversation_id: string | null
          created_at: string
          creation_id: string
          id: string
          mission_id: string | null
          parent_id: string
          summary: string | null
          world_id: string
        }
        Insert: {
          child_id: string
          conversation_id?: string | null
          created_at?: string
          creation_id: string
          id?: string
          mission_id?: string | null
          parent_id: string
          summary?: string | null
          world_id: string
        }
        Update: {
          child_id?: string
          conversation_id?: string | null
          created_at?: string
          creation_id?: string
          id?: string
          mission_id?: string | null
          parent_id?: string
          summary?: string | null
          world_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "creation_appearances_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creation_appearances_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creation_appearances_creation_id_fkey"
            columns: ["creation_id"]
            isOneToOne: false
            referencedRelation: "child_creations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creation_appearances_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: false
            referencedRelation: "child_missions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creation_appearances_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      families: {
        Row: {
          children_count: number
          country: string | null
          created_at: string
          id: string
          language: string
          learning_days: string
          learning_goals: string[]
          name: string | null
          notify_achievements: boolean
          notify_learning_reminders: boolean
          notify_product_updates: boolean
          notify_weekly_reports: boolean
          owner_id: string
          plan: string
          plan_interval: string | null
          session_length: string
          timezone: string
          trial_started_at: string | null
          updated_at: string
        }
        Insert: {
          children_count?: number
          country?: string | null
          created_at?: string
          id?: string
          language?: string
          learning_days?: string
          learning_goals?: string[]
          name?: string | null
          notify_achievements?: boolean
          notify_learning_reminders?: boolean
          notify_product_updates?: boolean
          notify_weekly_reports?: boolean
          owner_id: string
          plan?: string
          plan_interval?: string | null
          session_length?: string
          timezone?: string
          trial_started_at?: string | null
          updated_at?: string
        }
        Update: {
          children_count?: number
          country?: string | null
          created_at?: string
          id?: string
          language?: string
          learning_days?: string
          learning_goals?: string[]
          name?: string | null
          notify_achievements?: boolean
          notify_learning_reminders?: boolean
          notify_product_updates?: boolean
          notify_weekly_reports?: boolean
          owner_id?: string
          plan?: string
          plan_interval?: string | null
          session_length?: string
          timezone?: string
          trial_started_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "families_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          role: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          role: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      mission_reflections: {
        Row: {
          child_id: string
          created_at: string
          favorite_part: string | null
          id: string
          mission_id: string
          parent_id: string
          surprised_by: string | null
          would_improve: string | null
        }
        Insert: {
          child_id: string
          created_at?: string
          favorite_part?: string | null
          id?: string
          mission_id: string
          parent_id: string
          surprised_by?: string | null
          would_improve?: string | null
        }
        Update: {
          child_id?: string
          created_at?: string
          favorite_part?: string | null
          id?: string
          mission_id?: string
          parent_id?: string
          surprised_by?: string | null
          would_improve?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "mission_reflections_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mission_reflections_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: true
            referencedRelation: "child_missions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mission_reflections_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      onboarding_events: {
        Row: {
          created_at: string
          event: string
          id: string
          metadata: Json
          parent_id: string
        }
        Insert: {
          created_at?: string
          event: string
          id?: string
          metadata?: Json
          parent_id: string
        }
        Update: {
          created_at?: string
          event?: string
          id?: string
          metadata?: Json
          parent_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "onboarding_events_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      parent_safety_settings: {
        Row: {
          allowed_end_hour: number
          allowed_start_hour: number
          conversation_history_enabled: boolean
          created_at: string
          daily_minutes: number
          id: string
          microphone_enabled: boolean
          notifications_enabled: boolean
          parent_id: string
          portfolio_sharing_enabled: boolean
          report_download_enabled: boolean
          updated_at: string
          voice_chat_enabled: boolean
        }
        Insert: {
          allowed_end_hour?: number
          allowed_start_hour?: number
          conversation_history_enabled?: boolean
          created_at?: string
          daily_minutes?: number
          id?: string
          microphone_enabled?: boolean
          notifications_enabled?: boolean
          parent_id: string
          portfolio_sharing_enabled?: boolean
          report_download_enabled?: boolean
          updated_at?: string
          voice_chat_enabled?: boolean
        }
        Update: {
          allowed_end_hour?: number
          allowed_start_hour?: number
          conversation_history_enabled?: boolean
          created_at?: string
          daily_minutes?: number
          id?: string
          microphone_enabled?: boolean
          notifications_enabled?: boolean
          parent_id?: string
          portfolio_sharing_enabled?: boolean
          report_download_enabled?: boolean
          updated_at?: string
          voice_chat_enabled?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "parent_safety_settings_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      portfolio_items: {
        Row: {
          child_id: string
          content: Json
          created_at: string
          id: string
          kind: string
          parent_id: string
          title: string
          updated_at: string
          world_id: string | null
        }
        Insert: {
          child_id: string
          content?: Json
          created_at?: string
          id?: string
          kind?: string
          parent_id: string
          title: string
          updated_at?: string
          world_id?: string | null
        }
        Update: {
          child_id?: string
          content?: Json
          created_at?: string
          id?: string
          kind?: string
          parent_id?: string
          title?: string
          updated_at?: string
          world_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "portfolio_items_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "portfolio_items_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          country: string | null
          created_at: string
          email: string
          family_id: string | null
          first_name: string | null
          full_name: string | null
          id: string
          language: string
          last_name: string | null
          marketing_opt_in: boolean
          onboarding_completed_at: string | null
          onboarding_step: string
          updated_at: string
        }
        Insert: {
          country?: string | null
          created_at?: string
          email: string
          family_id?: string | null
          first_name?: string | null
          full_name?: string | null
          id: string
          language?: string
          last_name?: string | null
          marketing_opt_in?: boolean
          onboarding_completed_at?: string | null
          onboarding_step?: string
          updated_at?: string
        }
        Update: {
          country?: string | null
          created_at?: string
          email?: string
          family_id?: string | null
          first_name?: string | null
          full_name?: string | null
          id?: string
          language?: string
          last_name?: string | null
          marketing_opt_in?: boolean
          onboarding_completed_at?: string | null
          onboarding_step?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_family_id_fkey"
            columns: ["family_id"]
            isOneToOne: false
            referencedRelation: "families"
            referencedColumns: ["id"]
          },
        ]
      }
      safety_alerts: {
        Row: {
          ayara_response: string | null
          category: string
          child_id: string
          conversation_id: string | null
          created_at: string
          excerpt: string
          id: string
          parent_id: string
          reviewed_at: string | null
          severity: string
        }
        Insert: {
          ayara_response?: string | null
          category: string
          child_id: string
          conversation_id?: string | null
          created_at?: string
          excerpt: string
          id?: string
          parent_id: string
          reviewed_at?: string | null
          severity?: string
        }
        Update: {
          ayara_response?: string | null
          category?: string
          child_id?: string
          conversation_id?: string | null
          created_at?: string
          excerpt?: string
          id?: string
          parent_id?: string
          reviewed_at?: string | null
          severity?: string
        }
        Relationships: [
          {
            foreignKeyName: "safety_alerts_child_id_fkey"
            columns: ["child_id"]
            isOneToOne: false
            referencedRelation: "child_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "safety_alerts_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "safety_alerts_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      waitlist: {
        Row: {
          created_at: string
          email: string
          id: string
          name: string | null
          type: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          name?: string | null
          type: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          name?: string | null
          type?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
