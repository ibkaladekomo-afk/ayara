-- Extend missions for Section 6 mission types
ALTER TABLE public.child_missions
  ADD COLUMN IF NOT EXISTS difficulty text NOT NULL DEFAULT 'core',
  ADD COLUMN IF NOT EXISTS week_of date,
  ADD COLUMN IF NOT EXISTS season_id text,
  ADD COLUMN IF NOT EXISTS family_role text,
  ADD COLUMN IF NOT EXISTS steps jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS crystal_reward integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS child_confirmed_at timestamptz,
  ADD COLUMN IF NOT EXISTS parent_confirmed_at timestamptz,
  ADD COLUMN IF NOT EXISTS template_id text;

CREATE INDEX IF NOT EXISTS child_missions_kind_idx ON public.child_missions (child_id, kind, status);

-- Wallet: earned crystals + parent-granted coins
CREATE TABLE IF NOT EXISTS public.child_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL UNIQUE REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  crystals integer NOT NULL DEFAULT 0,
  coins integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_wallets TO authenticated;
GRANT ALL ON public.child_wallets TO service_role;
ALTER TABLE public.child_wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage their children's wallets"
ON public.child_wallets FOR ALL TO authenticated
USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());
CREATE TRIGGER update_child_wallets_updated_at
BEFORE UPDATE ON public.child_wallets
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Cosmetics unlocked with coins
CREATE TABLE IF NOT EXISTS public.child_cosmetics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  item_id text NOT NULL,
  category text NOT NULL,
  coins_spent integer NOT NULL DEFAULT 0,
  equipped boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (child_id, item_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_cosmetics TO authenticated;
GRANT ALL ON public.child_cosmetics TO service_role;
ALTER TABLE public.child_cosmetics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage their children's cosmetics"
ON public.child_cosmetics FOR ALL TO authenticated
USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());

-- Reflections
CREATE TABLE IF NOT EXISTS public.mission_reflections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mission_id uuid NOT NULL REFERENCES public.child_missions(id) ON DELETE CASCADE,
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  favorite_part text,
  would_improve text,
  surprised_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (mission_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.mission_reflections TO authenticated;
GRANT ALL ON public.mission_reflections TO service_role;
ALTER TABLE public.mission_reflections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents view their children's reflections"
ON public.mission_reflections FOR ALL TO authenticated
USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());

-- Parent coin grants
CREATE TABLE IF NOT EXISTS public.coin_grants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount integer NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.coin_grants TO authenticated;
GRANT ALL ON public.coin_grants TO service_role;
ALTER TABLE public.coin_grants ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage their children's coin grants"
ON public.coin_grants FOR ALL TO authenticated
USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());