-- Profiles table (parent accounts)
CREATE TABLE public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    email text not null,
    full_name text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (id = auth.uid());

CREATE POLICY "Users can insert own profile"
ON public.profiles FOR INSERT
TO authenticated
WITH CHECK (id = auth.uid());

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE
TO authenticated
USING (id = auth.uid());

-- Child profiles
CREATE TABLE public.child_profiles (
    id uuid primary key default gen_random_uuid(),
    parent_id uuid not null references public.profiles(id) on delete cascade,
    name text not null,
    age integer not null,
    grade text,
    language text not null default 'en',
    interests text[] default '{}',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_profiles TO authenticated;
GRANT ALL ON public.child_profiles TO service_role;

ALTER TABLE public.child_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read own children"
ON public.child_profiles FOR SELECT
TO authenticated
USING (parent_id = auth.uid());

CREATE POLICY "Parents can insert own children"
ON public.child_profiles FOR INSERT
TO authenticated
WITH CHECK (parent_id = auth.uid());

CREATE POLICY "Parents can update own children"
ON public.child_profiles FOR UPDATE
TO authenticated
USING (parent_id = auth.uid());

CREATE POLICY "Parents can delete own children"
ON public.child_profiles FOR DELETE
TO authenticated
USING (parent_id = auth.uid());

-- Conversations
CREATE TABLE public.conversations (
    id uuid primary key default gen_random_uuid(),
    child_id uuid not null references public.child_profiles(id) on delete cascade,
    parent_id uuid not null references public.profiles(id) on delete cascade,
    title text,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;

ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read own conversations"
ON public.conversations FOR SELECT
TO authenticated
USING (parent_id = auth.uid());

CREATE POLICY "Parents can insert own conversations"
ON public.conversations FOR INSERT
TO authenticated
WITH CHECK (parent_id = auth.uid());

CREATE POLICY "Parents can update own conversations"
ON public.conversations FOR UPDATE
TO authenticated
USING (parent_id = auth.uid());

CREATE POLICY "Parents can delete own conversations"
ON public.conversations FOR DELETE
TO authenticated
USING (parent_id = auth.uid());

-- Messages
CREATE TABLE public.messages (
    id uuid primary key default gen_random_uuid(),
    conversation_id uuid not null references public.conversations(id) on delete cascade,
    role text not null check (role in ('user', 'assistant', 'system')),
    content text not null,
    created_at timestamptz not null default now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read messages of own conversations"
ON public.messages FOR SELECT
TO authenticated
USING (
    conversation_id IN (
        SELECT id FROM public.conversations WHERE parent_id = auth.uid()
    )
);

CREATE POLICY "Parents can insert messages of own conversations"
ON public.messages FOR INSERT
TO authenticated
WITH CHECK (
    conversation_id IN (
        SELECT id FROM public.conversations WHERE parent_id = auth.uid()
    )
);

-- Waitlist / investor contact
CREATE TABLE public.waitlist (
    id uuid primary key default gen_random_uuid(),
    email text not null unique,
    name text,
    type text not null check (type in ('parent', 'investor')),
    created_at timestamptz not null default now()
);

GRANT SELECT, INSERT ON public.waitlist TO anon;
GRANT SELECT, INSERT ON public.waitlist TO authenticated;
GRANT ALL ON public.waitlist TO service_role;

ALTER TABLE public.waitlist ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can join waitlist"
ON public.waitlist FOR INSERT
TO anon, authenticated
WITH CHECK (true);

CREATE POLICY "Users can see own waitlist entry"
ON public.waitlist FOR SELECT
TO authenticated
USING (email = auth.email());
