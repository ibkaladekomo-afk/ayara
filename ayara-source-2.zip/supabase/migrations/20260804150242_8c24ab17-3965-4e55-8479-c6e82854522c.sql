CREATE TABLE public.child_creations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  kind text NOT NULL,
  emoji text NOT NULL DEFAULT '✨',
  origin_world text NOT NULL,
  traits jsonb NOT NULL DEFAULT '[]'::jsonb,
  summary text,
  portfolio_item_id uuid REFERENCES public.portfolio_items(id) ON DELETE SET NULL,
  parent_creation_id uuid REFERENCES public.child_creations(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_creations TO authenticated;
GRANT ALL ON public.child_creations TO service_role;
ALTER TABLE public.child_creations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage their children's creations"
  ON public.child_creations FOR ALL TO authenticated
  USING (auth.uid() = parent_id) WITH CHECK (auth.uid() = parent_id);

CREATE INDEX idx_child_creations_child ON public.child_creations(child_id, created_at DESC);

CREATE TRIGGER update_child_creations_updated_at
  BEFORE UPDATE ON public.child_creations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.creation_appearances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creation_id uuid NOT NULL REFERENCES public.child_creations(id) ON DELETE CASCADE,
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  world_id text NOT NULL,
  summary text,
  conversation_id uuid REFERENCES public.conversations(id) ON DELETE SET NULL,
  mission_id uuid REFERENCES public.child_missions(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.creation_appearances TO authenticated;
GRANT ALL ON public.creation_appearances TO service_role;
ALTER TABLE public.creation_appearances ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage their children's creation appearances"
  ON public.creation_appearances FOR ALL TO authenticated
  USING (auth.uid() = parent_id) WITH CHECK (auth.uid() = parent_id);

CREATE INDEX idx_creation_appearances_creation ON public.creation_appearances(creation_id, created_at DESC);
CREATE UNIQUE INDEX idx_creation_appearances_unique_world ON public.creation_appearances(creation_id, world_id);