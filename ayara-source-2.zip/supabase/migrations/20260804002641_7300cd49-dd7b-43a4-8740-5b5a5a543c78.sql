CREATE TABLE public.families (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text,
  country text,
  timezone text NOT NULL DEFAULT 'UTC',
  language text NOT NULL DEFAULT 'en',
  children_count integer NOT NULL DEFAULT 1,
  notify_weekly_reports boolean NOT NULL DEFAULT true,
  notify_learning_reminders boolean NOT NULL DEFAULT true,
  notify_achievements boolean NOT NULL DEFAULT true,
  notify_product_updates boolean NOT NULL DEFAULT false,
  learning_goals text[] NOT NULL DEFAULT '{}'::text[],
  session_length text NOT NULL DEFAULT 'no_preference',
  learning_days text NOT NULL DEFAULT 'daily',
  plan text NOT NULL DEFAULT 'free',
  plan_interval text,
  trial_started_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.families TO authenticated;
GRANT ALL ON public.families TO service_role;
ALTER TABLE public.families ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read own family" ON public.families FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "Parents can insert own family" ON public.families FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Parents can update own family" ON public.families FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Parents can delete own family" ON public.families FOR DELETE TO authenticated USING (owner_id = auth.uid());

CREATE UNIQUE INDEX families_owner_id_key ON public.families(owner_id);

CREATE TABLE public.parent_safety_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  daily_minutes integer NOT NULL DEFAULT 30,
  allowed_start_hour integer NOT NULL DEFAULT 7,
  allowed_end_hour integer NOT NULL DEFAULT 20,
  voice_chat_enabled boolean NOT NULL DEFAULT true,
  microphone_enabled boolean NOT NULL DEFAULT true,
  portfolio_sharing_enabled boolean NOT NULL DEFAULT false,
  notifications_enabled boolean NOT NULL DEFAULT true,
  conversation_history_enabled boolean NOT NULL DEFAULT true,
  report_download_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.parent_safety_settings TO authenticated;
GRANT ALL ON public.parent_safety_settings TO service_role;
ALTER TABLE public.parent_safety_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read own safety settings" ON public.parent_safety_settings FOR SELECT TO authenticated USING (parent_id = auth.uid());
CREATE POLICY "Parents can insert own safety settings" ON public.parent_safety_settings FOR INSERT TO authenticated WITH CHECK (parent_id = auth.uid());
CREATE POLICY "Parents can update own safety settings" ON public.parent_safety_settings FOR UPDATE TO authenticated USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());
CREATE POLICY "Parents can delete own safety settings" ON public.parent_safety_settings FOR DELETE TO authenticated USING (parent_id = auth.uid());

CREATE UNIQUE INDEX parent_safety_settings_parent_id_key ON public.parent_safety_settings(parent_id);

CREATE TABLE public.onboarding_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  event text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.onboarding_events TO authenticated;
GRANT ALL ON public.onboarding_events TO service_role;
ALTER TABLE public.onboarding_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read own onboarding events" ON public.onboarding_events FOR SELECT TO authenticated USING (parent_id = auth.uid());
CREATE POLICY "Parents can insert own onboarding events" ON public.onboarding_events FOR INSERT TO authenticated WITH CHECK (parent_id = auth.uid());

CREATE INDEX onboarding_events_parent_id_idx ON public.onboarding_events(parent_id);

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS first_name text,
  ADD COLUMN IF NOT EXISTS last_name text,
  ADD COLUMN IF NOT EXISTS country text,
  ADD COLUMN IF NOT EXISTS language text NOT NULL DEFAULT 'en',
  ADD COLUMN IF NOT EXISTS marketing_opt_in boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS family_id uuid REFERENCES public.families(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS onboarding_step text NOT NULL DEFAULT 'account',
  ADD COLUMN IF NOT EXISTS onboarding_completed_at timestamptz;

ALTER TABLE public.child_profiles
  ADD COLUMN IF NOT EXISTS family_id uuid REFERENCES public.families(id) ON DELETE SET NULL;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_families_updated_at BEFORE UPDATE ON public.families FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_parent_safety_settings_updated_at BEFORE UPDATE ON public.parent_safety_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();