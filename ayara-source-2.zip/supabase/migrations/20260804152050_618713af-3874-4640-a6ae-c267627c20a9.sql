CREATE TABLE public.child_celebrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  child_id UUID NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (child_id, key)
);

GRANT SELECT ON public.child_celebrations TO authenticated;
GRANT ALL ON public.child_celebrations TO service_role;

ALTER TABLE public.child_celebrations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can view their children's celebrations"
ON public.child_celebrations FOR SELECT TO authenticated
USING (parent_id = auth.uid());

CREATE TABLE public.conversation_summaries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  child_id UUID NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  world_id TEXT,
  summary TEXT NOT NULL,
  themes TEXT[] NOT NULL DEFAULT '{}',
  skills TEXT[] NOT NULL DEFAULT '{}',
  message_count INTEGER NOT NULL DEFAULT 0,
  minutes INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (conversation_id)
);

GRANT SELECT, DELETE ON public.conversation_summaries TO authenticated;
GRANT ALL ON public.conversation_summaries TO service_role;

ALTER TABLE public.conversation_summaries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can view their children's summaries"
ON public.conversation_summaries FOR SELECT TO authenticated
USING (parent_id = auth.uid());

CREATE POLICY "Parents can delete their children's summaries"
ON public.conversation_summaries FOR DELETE TO authenticated
USING (parent_id = auth.uid());

CREATE TRIGGER update_conversation_summaries_updated_at
BEFORE UPDATE ON public.conversation_summaries
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();