ALTER TABLE public.child_profiles ADD COLUMN IF NOT EXISTS avatar_config jsonb;

-- ------------------------------------------------------------------
CREATE TABLE public.child_onboarding (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL UNIQUE REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  current_step text NOT NULL DEFAULT 'doorway',
  quest_state jsonb NOT NULL DEFAULT '{}'::jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_onboarding TO authenticated;
GRANT ALL ON public.child_onboarding TO service_role;
ALTER TABLE public.child_onboarding ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage own children onboarding" ON public.child_onboarding
  FOR ALL TO authenticated USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());
CREATE TRIGGER update_child_onboarding_updated_at BEFORE UPDATE ON public.child_onboarding
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ------------------------------------------------------------------
CREATE TABLE public.portfolio_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  kind text NOT NULL DEFAULT 'creation',
  title text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}'::jsonb,
  world_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.portfolio_items TO authenticated;
GRANT ALL ON public.portfolio_items TO service_role;
ALTER TABLE public.portfolio_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage own children portfolio" ON public.portfolio_items
  FOR ALL TO authenticated USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());
CREATE TRIGGER update_portfolio_items_updated_at BEFORE UPDATE ON public.portfolio_items
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX portfolio_items_child_created_idx ON public.portfolio_items (child_id, created_at DESC);

-- ------------------------------------------------------------------
CREATE TABLE public.child_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL UNIQUE REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  xp integer NOT NULL DEFAULT 0,
  level integer NOT NULL DEFAULT 1,
  streak_days integer NOT NULL DEFAULT 0,
  last_active_on date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_progress TO authenticated;
GRANT ALL ON public.child_progress TO service_role;
ALTER TABLE public.child_progress ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage own children progress" ON public.child_progress
  FOR ALL TO authenticated USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());
CREATE TRIGGER update_child_progress_updated_at BEFORE UPDATE ON public.child_progress
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ------------------------------------------------------------------
CREATE TABLE public.child_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  badge_id text NOT NULL,
  earned_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (child_id, badge_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_badges TO authenticated;
GRANT ALL ON public.child_badges TO service_role;
ALTER TABLE public.child_badges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage own children badges" ON public.child_badges
  FOR ALL TO authenticated USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());

-- ------------------------------------------------------------------
CREATE TABLE public.child_world_unlocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  world_id text NOT NULL,
  unlocked_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (child_id, world_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_world_unlocks TO authenticated;
GRANT ALL ON public.child_world_unlocks TO service_role;
ALTER TABLE public.child_world_unlocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents manage own children unlocks" ON public.child_world_unlocks
  FOR ALL TO authenticated USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());

-- ------------------------------------------------------------------
CREATE TABLE public.child_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  event text NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.child_events TO authenticated;
GRANT ALL ON public.child_events TO service_role;
ALTER TABLE public.child_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Parents read own children events" ON public.child_events
  FOR SELECT TO authenticated USING (parent_id = auth.uid());
CREATE INDEX child_events_child_created_idx ON public.child_events (child_id, created_at DESC);