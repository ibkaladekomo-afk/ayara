CREATE TABLE public.child_world_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  world_id text NOT NULL,
  stage_index integer NOT NULL DEFAULT 0,
  completed_stages text[] NOT NULL DEFAULT '{}',
  crystals integer NOT NULL DEFAULT 0,
  master_project_status text NOT NULL DEFAULT 'not_started',
  master_project_item_id uuid REFERENCES public.portfolio_items(id) ON DELETE SET NULL,
  entered_count integer NOT NULL DEFAULT 0,
  last_entered_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (child_id, world_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_world_progress TO authenticated;
GRANT ALL ON public.child_world_progress TO service_role;

ALTER TABLE public.child_world_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents manage their children's world progress"
ON public.child_world_progress FOR ALL TO authenticated
USING (parent_id = auth.uid())
WITH CHECK (parent_id = auth.uid());

CREATE TRIGGER update_child_world_progress_updated_at
BEFORE UPDATE ON public.child_world_progress
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.child_discoveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  world_id text NOT NULL,
  discovery_id text NOT NULL,
  found_at timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (child_id, discovery_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_discoveries TO authenticated;
GRANT ALL ON public.child_discoveries TO service_role;

ALTER TABLE public.child_discoveries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents manage their children's discoveries"
ON public.child_discoveries FOR ALL TO authenticated
USING (parent_id = auth.uid())
WITH CHECK (parent_id = auth.uid());