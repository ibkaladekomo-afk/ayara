CREATE TABLE public.safety_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  conversation_id uuid REFERENCES public.conversations(id) ON DELETE SET NULL,
  category text NOT NULL,
  severity text NOT NULL DEFAULT 'notice',
  excerpt text NOT NULL,
  ayara_response text,
  reviewed_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX safety_alerts_parent_created_idx ON public.safety_alerts (parent_id, created_at DESC);

GRANT SELECT, UPDATE, DELETE ON public.safety_alerts TO authenticated;
GRANT ALL ON public.safety_alerts TO service_role;

ALTER TABLE public.safety_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can read own safety alerts"
  ON public.safety_alerts FOR SELECT TO authenticated
  USING (parent_id = auth.uid());

CREATE POLICY "Parents can update own safety alerts"
  ON public.safety_alerts FOR UPDATE TO authenticated
  USING (parent_id = auth.uid()) WITH CHECK (parent_id = auth.uid());

CREATE POLICY "Parents can delete own safety alerts"
  ON public.safety_alerts FOR DELETE TO authenticated
  USING (parent_id = auth.uid());