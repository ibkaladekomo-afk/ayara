CREATE TABLE public.child_missions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  parent_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  world_id text NOT NULL,
  title text NOT NULL,
  prompt text NOT NULL,
  kind text NOT NULL DEFAULT 'daily',
  estimated_minutes integer NOT NULL DEFAULT 12,
  xp_reward integer NOT NULL DEFAULT 75,
  badge_reward text,
  status text NOT NULL DEFAULT 'assigned',
  progress_step integer NOT NULL DEFAULT 0,
  total_steps integer NOT NULL DEFAULT 4,
  last_step_label text,
  conversation_id uuid REFERENCES public.conversations(id) ON DELETE SET NULL,
  assigned_on date NOT NULL DEFAULT (now() AT TIME ZONE 'utc')::date,
  completed_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX child_missions_child_idx ON public.child_missions (child_id, assigned_on DESC);
CREATE INDEX child_missions_status_idx ON public.child_missions (child_id, status);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_missions TO authenticated;
GRANT ALL ON public.child_missions TO service_role;

ALTER TABLE public.child_missions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents manage their children's missions"
ON public.child_missions FOR ALL
TO authenticated
USING (parent_id = auth.uid())
WITH CHECK (parent_id = auth.uid());

CREATE TRIGGER update_child_missions_updated_at
BEFORE UPDATE ON public.child_missions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.child_progress ADD COLUMN IF NOT EXISTS grace_used_on date;