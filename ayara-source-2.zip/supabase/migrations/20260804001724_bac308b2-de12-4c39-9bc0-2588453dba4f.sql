ALTER TABLE public.child_profiles ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE public.child_profiles ADD COLUMN IF NOT EXISTS pin_hash text;

CREATE UNIQUE INDEX IF NOT EXISTS child_profiles_username_unique
  ON public.child_profiles(username)
  WHERE username IS NOT NULL;

CREATE TABLE public.child_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  child_id uuid NOT NULL REFERENCES public.child_profiles(id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE,
  expires_at timestamp with time zone NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.child_sessions TO authenticated;
GRANT ALL ON public.child_sessions TO service_role;

ALTER TABLE public.child_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Parents can manage their children's sessions"
ON public.child_sessions
FOR ALL
TO authenticated
USING (child_id IN (SELECT id FROM public.child_profiles WHERE parent_id = auth.uid()))
WITH CHECK (child_id IN (SELECT id FROM public.child_profiles WHERE parent_id = auth.uid()));