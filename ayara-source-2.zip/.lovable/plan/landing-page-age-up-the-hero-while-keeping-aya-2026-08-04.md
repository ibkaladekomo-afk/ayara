# Landing page: age-up the hero while keeping Aya

## Goal
Rework the `/` landing page so it feels right for the full Ayara range (grades 2–8), especially the upper end (10–13), without alienating younger children. Keep Aya, keep the warm brand palette, but shift the visual story from "toy room" to "creative studio / maker space."

## What we will change

### 1. Hero visual
- Replace the current `illus-welcome.jpg` hero image.
- New image: an older child (roughly 9–12) actively creating/building with Aya as a guide, or an abstract scene showing projects, code blocks, art tools, and science gear in a clean, modern composition.
- Avoid: very young children, pastel toy shapes, rainbows, overly rounded/cute mascot dominating the frame.
- Keep: Aya visible but as a companion, not the main subject.

### 2. Hero layout and styling
- Reduce the mascot’s visual dominance: keep the small Aya badge/avatar below the hero image, but remove the floating "wave" treatment or make it smaller.
- Use a slightly darker, more saturated hero background treatment (subtle gradient using existing `ayara-navy` / `ayara-violet` / `ayara-blue`) to feel more "studio" than "playroom."
- Tighten vertical rhythm and spacing so the page feels intentional on mobile.

### 3. Copy
Update i18n strings in `src/lib/i18n.tsx`:
- `launch.greeting`: from "Hello, we're so glad you're here." to something active and maker-oriented, e.g. "Learn, build, and create with AI."
- `launch.mission`: from "Ayara is the premium AI learning platform that grows with your child." to something emphasizing guided creation and real projects, e.g. "Ayara helps kids use AI to make things, solve problems, and explore ideas — safely."
- Keep `launch.getStarted`, `launch.haveAccount`, `launch.kidLogin` as-is.

### 4. Feature cards
Keep the three feature cards but rewrite the bodies to emphasize agency and creation:
- "Learning that feels like play" -> focus on missions and real projects.
- "Safety by design" -> keep, but frame as "you're free to explore because it's safe."
- "Parents are partners" -> keep, but frame as "parents see progress without hovering."

### 5. Implementation details
- Edit `src/routes/index.tsx`.
- Edit `src/lib/i18n.tsx` for English and Spanish copy.
- Generate a new hero image and register it as an asset pointer in `src/assets/`.
- No new design tokens needed; use existing brand colors and semantic tokens only.
- Preserve all existing functionality: language picker, CTA links, footer links, SEO head meta.

## Verification
- Preview the page on mobile viewport.
- Confirm the new hero image renders, no placeholder text, and CTAs remain tappable.
- Confirm English/Spanish copy switches correctly.
- Confirm no layout regressions on desktop.
