# Section 2 — Child Onboarding & First Learning Experience

Turn the existing short "arrival" intro into the full first-run journey from the spec, and land it on a real child Home Dashboard. Progress is saved in the database so it follows the child across devices and the parent can see it.

## The journey we're building

```text
Parent taps "Start child experience"
  -> glowing doorway transition + ambient intro
  -> Aya's personalized welcome (spoken if voice is on)
  -> Build your avatar
  -> Choose your interests
  -> Meet the mentors (Dr. Nova, Luna, Byte, Echo)
  -> Curiosity Quest: "The Missing Spark"
  -> First AI conversation ("If you could invent anything...")
  -> First creative activity (grade-appropriate) -> saved to Portfolio
  -> Celebration: confetti, "First Spark" badge, XP
  -> World map: Science Lab unlocked, others softly locked
  -> Home Dashboard
```

Every step is resumable: if the child closes the app mid-way, they come back exactly where they left off. Both tiers get the same journey with different tone, visuals and activities — Spark (grades 2–5) storybook and voice-led, Forge (grades 6–8) studio/mission-brief styled.

## Avatar builder

A layered avatar the child assembles: face shape and skin tone, hairstyle and hair color, glasses/no glasses, outfit color, and one accessory. Rendered as composed SVG layers so it scales anywhere in the app (header, dashboard, portfolio, parent view) with no image uploads. Spark sees big tappable swatches with a live preview; Forge sees a tighter grid. Existing character avatars stay valid so no child loses their current one.

## Interests

The 15 topics from the spec (Space, Animals, Art, Music, Reading, Building, Nature, Sports, Coding, Science, Robots, Stories, History, Math, Helping People), multi-select with a minimum of three, saved to the child's profile and editable later from the dashboard. Interests personalize mission suggestions; they never lock content away.

## Mentors

Mentors introduce themselves one at a time with a short entrance animation and their own line, spoken aloud when voice is enabled. Four mentors, tap-to-continue, skippable. The mentors map onto the existing learning worlds so the same characters greet the child later.

## Curiosity Quest — "The Missing Spark"

A five-beat mini-adventure that teaches the interface without a tutorial: tap the glowing objects, listen to Aya, ask Aya a question, sketch/choose an idea, and solve a short pattern puzzle. Each beat awards a fragment of the Spark; the final beat restores it with a burst of light.

## First AI conversation and first creation

Aya asks "If you could invent anything, what would it be?" The child answers by voice or typing. The reply celebrates the idea, asks exactly one follow-up, and stays short — enforced by the onboarding-specific prompt. The conversation flows into a grade-appropriate creative activity (dream animal / robot name / tiny story for 2–3; invention, comic or mission idea for 4–5; challenge, AI-improved idea or future city for 6–8), which is saved as the child's first Portfolio item.

## Celebration, world map, home

Brief confetti moment, "First Spark" badge, XP awarded, certificate progress started. Then the world map: Science Lab unlocked and glowing, the other five worlds visible but softly locked with Aya explaining they open as the child learns. Finally the Home Dashboard with the six sections: Today's Mission, Continue Learning, My Worlds, Portfolio, Rewards and Ask Aya, with a time-aware personalized greeting.

## Accessibility and resilience

Read-aloud on every screen, captions on narrated lines, large text and 44×44px minimum touch targets throughout, keyboard navigation, and a reduced-motion mode that swaps animations for instant transitions. Progress is written to local storage as the child moves and synced when the connection returns; Aya reassures rather than erroring. If voice recognition fails, retry and typing are offered inline without leaving the step.

## Analytics

Every event in item 17 is recorded (onboarding started, avatar selected, interests completed, mentors viewed, quest completed, first conversation, first portfolio item, first badge, world unlocked, onboarding completed) with timestamps, so duration and drop-off points are measurable. Surfaced later in the parent view.

## Technical notes

Database (new tables, all with grants + RLS scoped to the owning parent, and child-session-scoped writes through server functions):
- `child_onboarding` — one row per child: current step, step timestamps, completion time, avatar config, quest state.
- `portfolio_items` — child_id, kind, title, content (jsonb: text/drawing strokes/choices), world_id, created_at.
- `child_progress` — child_id, xp, level, streak fields.
- `child_badges` — child_id, badge_id, earned_at (unique per child+badge).
- `child_world_unlocks` — child_id, world_id, unlocked_at (Science Lab seeded on onboarding completion).
- `child_events` — analytics events: child_id, event, metadata jsonb, created_at.
- `child_profiles`: add `avatar_config jsonb` for the layered avatar; keep `avatar` for the existing character presets.

Code:
- `src/lib/avatar-builder.ts` + `src/components/layered-avatar.tsx` — layer definitions and SVG renderer.
- `src/lib/onboarding-journey.ts` — step order, per-tier copy, grade-based activity picker, mentor scripts, quest beats.
- `src/lib/child-onboarding.functions.ts` — server functions behind the existing child-session cookie guard (save step, avatar, interests, portfolio item, badge, XP, unlock, event).
- `src/routes/play.arrival.tsx` becomes the journey shell driving step components in `src/components/onboarding/*`; the existing Spark/Forge scene code is reused as the doorway and welcome beats.
- `src/routes/play.index.tsx` becomes the Home Dashboard with the six sections; the current world grid moves into "My Worlds" plus a new locked-state world map.
- New route `src/routes/play.portfolio.tsx` for the portfolio list.
- Onboarding AI turn uses the existing `/api/chat` route with an onboarding system prompt and short-response constraint; existing safety screening stays in place.
- Reduced motion respects `prefers-reduced-motion` plus an in-app toggle stored per child.

Build order: migration first, then avatar builder, then the journey shell and steps, then dashboard and portfolio, then a full end-to-end pass in the preview for both a grade-3 and a grade-7 child.
