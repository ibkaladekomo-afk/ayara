# Rename the Home Dashboard to the Innovation Hub

A language change, not a structural one. The child's main screen becomes the **Innovation Hub** everywhere we describe it — while the bottom navigation label stays **Home** so it remains familiar.

## What changes for children

- The main `/play` screen is titled and referred to as the **Innovation Hub**.
- The browser/page title and share preview text read "Innovation Hub — AYARA" instead of "Your dashboard — AYARA".
- The loading and error messages say "your Innovation Hub" rather than "your dashboard".
- Bottom navigation still says **Home** — unchanged.
- No layout, mission, XP, streak, or badge behaviour changes.

## What changes for us

- Product/design language in the code and docs uses "Innovation Hub" for this screen, so future work inherits the right vocabulary.
- File comments and section headers describing the screen are reworded (for example, `dashboard-content.ts`'s header comment becomes "Content + pure helpers for the child Innovation Hub").
- Spanish copy uses **Centro de Innovación** for the same phrase.

## Technical notes

- Copy edits in `src/routes/play.index.tsx`: route `head()` meta (title, description, og:title, og:description), plus loading/error strings.
- Comment/doc-string rewording in `src/lib/dashboard-content.ts`, `src/lib/child-dashboard.server.ts`, and `src/lib/child-dashboard.functions.ts`.
- Any new user-facing strings go through `src/lib/i18n.tsx` with EN/ES entries.
- Identifiers stay as-is (`getMyDashboard`, `child-dashboard.*`, the `child-dashboard` query key). Renaming server functions, files, and query keys would touch mission start/advance/complete wiring for zero user benefit; the naming shift is about product language, not symbols.
- No database or schema changes.
