# Section 5 — End-to-End Test Plan

Test the Aya AI Companion Experience across all three grade bands and both child/parent surfaces. Fix any regressions found before moving to the next build section.

## 1. Test setup

- Confirm the dev server is healthy and the preview loads.
- Use the existing parent account or create a fresh one.
- Create one test child for each grade band if they do not already exist:
  - Early Spark: grade 2 or 3
  - Middle Spark: grade 4 or 5
  - Forge: grade 6, 7 or 8
- For each child, complete onboarding so they reach the Innovation Hub / world picker.

## 2. Child mission flow — per grade band

For each test child:

1. Open a learning world and start a mission (or a learning-path stage).
2. Verify the mentor greeting matches the child's tier:
   - Early: warm, short, voice-first prompt.
   - Middle: fuller explanation with an analogy.
   - Forge: direct, mentor-led, no cutesy language.
3. Send a few messages and check that Aya follows the teaching framework:
   - Celebrates something specific in the child's message.
   - Asks what they already think/tried.
   - Gives the idea at the right level.
   - Ends with a question or small next step.
4. Tap each mode chip:
   - Ask, Explore, Imagine are always visible.
   - Reflect appears only after at least 6 messages.
   - Confirm the placeholder text changes and the mode is sent with the message.
5. Verify Aya refers back to memory (interests, recent projects, streak, world progress) naturally, not as a list.
6. Check voice input and read-aloud behavior:
   - Early/Middle default to voice-first; mic button is prominent.
   - Forge defaults to typing; voice is available but secondary.

## 3. Safety interception

1. From a child mission, send an urgent-severity message (e.g. self-harm language).
   - Confirm Aya replies with the scripted empathy-first message, not a model-generated response.
   - Confirm the scripted reply is saved to the conversation.
2. Send an attention-severity message (e.g. bullying or personal info).
   - Confirm the conversation continues but Aya gently redirects.
3. Open the parent dashboard.
   - Confirm a safety alert appears in the Safety Alerts card with the correct category and excerpt.

## 4. Celebrations

1. With a child who has never sent a message, send the first question.
   - Confirm the "Your first question!" celebration card appears once.
2. Complete a mission or stage.
   - Confirm the relevant milestone celebration appears (first project, world complete, master project, streak milestone).
3. Return to the same child and repeat the trigger.
   - Confirm the same celebration does not fire again.

## 5. Parent transparency

1. Finish a learning session for each test child by marking a mission or stage complete.
2. In the parent dashboard, open the Learning summary card.
   - Confirm stats populate: questions asked, projects made, minutes learning, reflections.
   - Confirm themes and skills appear as tags.
   - Confirm a short AI-written recap appears (not the full transcript).
3. Tap "Clear Aya's conversation history" for one child and confirm.
   - Verify the child's conversations, messages and summaries are removed.
   - Verify the summary card updates to the empty state.

## 6. Analytics events

1. Run a quick database check for `child_events` rows created during the test session.
2. Confirm the following events were logged with the correct `child_id` and `world_id`:
   - `question_asked`
   - `voice_used` (if voice was used)
   - `reflection_completed` (if Reflect mode was used)

## 7. Regression checks

- World picker loads and worlds open without the "mission couldn't open" error.
- Child login still works with username + PIN.
- Returning child flows (arrival, onboarding resume, dashboard) do not redirect-loop.
- No 500 errors in server function logs during the test flows.

## Expected outcome

All Section 5 features behave correctly across Early Spark, Middle Spark and Forge. Any bugs found are fixed in the same pass and re-verified.