# Plan: Child accounts with username + PIN login

Turn AYARA into a two-role app: parents manage the family account and create child profiles with a username and PIN; children log in separately with those credentials to reach their own learning space.

## What we will build

### 1. Database changes

Update `public.child_profiles` so each child has login credentials:

- `username` — globally unique text handle the child types to log in (e.g. `alex.sunshine`).
- `pin_hash` — secure one-way hash of a parent-set 4–6 digit PIN.
- Enforce uniqueness on `username`.
- Update RLS so the existing parent policies still work and a new child-owned read path is added.

Create `public.child_sessions`:

- `id uuid primary key default gen_random_uuid()`
- `child_id uuid not null references child_profiles(id) on delete cascade`
- `token text not null unique`
- `expires_at timestamptz not null`
- `created_at timestamptz not null default now()`
- `updated_at timestamptz not null default now()`
- Grant `authenticated` and `service_role` access; no anon access.
- RLS: children can read/delete only rows matching their own `child_id`; parents can read/delete sessions for their own children.

### 2. Parent flow updates

**Onboarding child step**
- Add username and PIN fields.
- Validate username is unique and PIN is 4–6 digits.
- Show the username/PIN on completion so the parent can share it with the child.

**Add-child dialog**
- Add the same username and PIN fields.

**Dashboard**
- Display each child’s username and a "Reset PIN" action.
- Remove the current "Open Play" button (children reach play through their own login).

### 3. Child authentication system

**`/child-login` public route**
- Large, friendly form: username + PIN.
- Server function `loginChild` validates credentials against `child_profiles`.
- On success, creates a row in `child_sessions`, sets an `ayara_child_session` httpOnly secure cookie with the token, and redirects to `/play`.
- On failure, shows a child-friendly error without exposing whether the username exists.

**`/child-logout` route/action**
- Clears the session cookie and deletes the `child_sessions` row.

**Child session gate**
- A new lightweight context/provider reads the cookie and exposes the active child profile.
- Play routes move out of `_authenticated/` and use this gate instead of parent auth.

### 4. Child experience routing

Move the play surface to public-but-child-gated routes:

- `/play` — world picker, scoped to the logged-in child.
- `/play/$worldId` — mission/chat, scoped to the logged-in child.

Changes inside the play pages:
- Remove the child-switcher dropdown; the active child comes from the child session.
- Greet the child by name and avatar.
- Create conversations under the active child automatically.

Keep parent-only pages under `_authenticated/`:

- `/dashboard` — family overview.
- `/onboarding` — parent/child setup.

### 5. Home page and navigation

- Replace the main "Start learning" CTA with two clear options: "Parent sign in" and "Child login".
- Update `SiteHeader` to show "Parent" / "Child" entry points when no session is active, and a relevant account menu when one is.

### 6. Security and safety notes

- PINs are hashed, never stored plain.
- Session tokens expire after a configurable period (start with 24 hours, sliding refresh optional).
- Failed login attempts are rate-limited per username.
- Child login does not expose parent account access.
- Parent can reset a child PIN from the dashboard.

## Out of scope for this plan

- Subscription gating or payment flows.
- Parent progress reports beyond the existing conversation list.
- School/teacher multi-classroom accounts.
