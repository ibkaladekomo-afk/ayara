# Section 6 — Missions, Rewards & Innovation System

Turn today's single daily mission into a full mission engine with five mission types, a consistent seven-beat mission journey, and a reward layer that pays out for thinking and making — never for showing up.

## What exists today

- One daily mission per child, picked from 9 templates by tier + interests, with XP and a badge on completion.
- 12 badges, 8 XP level titles (250 XP per level), streak with a one-day grace.
- Curiosity Crystals exist but only from hidden world discoveries.
- Celebrations and reflection prompts exist inside world chat; no coins, no weekly/family/seasonal missions, no reflection capture, no mission browser.

## What gets built

### 1. Mission types
- **Daily** — short, 10–30 min (existing, expanded template library).
- **World** — tied to each Learning World, unlocked by world stage.
- **Weekly Innovation Challenge** — one per week, multi-day, multi-skill, resumable.
- **Family** — parent + child together, full loop: parent assigns or approves from the parent dashboard, child completes offline steps, both confirm, parent sees it in summaries.
- **Seasonal** — date-windowed (Earth Day, STEM Week, Black History Month, Summer Discovery), auto-surfaced only inside their window.

### 2. Mission journey
Every mission runs the same seven beats: Discover → Understand → Create → Improve → Share → Reflect → Celebrate. Beats render tier-appropriately (Spark: voice-first, big taps; Forge: studio/mentor tone) and progress is saved per beat so a child can leave and return.

### 3. Difficulty
A per-mission difficulty score derived from grade tier, missions completed, worlds finished, abandon rate, and parent settings. Templates carry a difficulty band; the picker chooses within the child's current band and nudges up after consistent completions.

### 4. Rewards
- **XP** for completing, creating, revising, reflecting, helping a mentor, and family collaboration — never for logging in.
- **Innovation Levels** renamed to the branded ladder: Spark → Explorer → Creator → Inventor → Innovator → Visionary → Pioneer, each listing what it unlocks.
- **Badges** expanded to the spec list (Curious Questioner, Creative Builder, Science Explorer, Story Weaver, Coding Starter, Problem Solver, Team Player, Kindness Champion, Future Inventor) with earn reasons shown.
- **Curiosity Crystals** extended to missions, projects, habits and mentor help — earned only, never bought.
- **Premium Coins** scaffolded: a balance parents can grant, plus a cosmetic shop (avatar items, theme packs, portfolio decorations). No purchase flow this section; nothing academic is ever behind coins.
- **Portfolio**: every Create/Share beat writes a portfolio item the child can revisit.

### 5. Innovation Streak
Streak advances on a qualifying learning activity (not a login). A missed day triggers a **Spark Recovery Mission** the child can complete to restore the streak.

### 6. Reflection & celebration
Each mission ends with a short reflection (favorite part / what you'd improve / what surprised you), stored and surfaced to parents. Celebrations fire on first mission, first world, first portfolio project, 100 XP, new level, birthday, learning anniversary — brief Aya animation, gentle confetti, respecting reduced motion.

### 7. Parent integration
Parent dashboard gains a Missions & Growth panel: missions completed, skills practiced, new badges, portfolio additions, consistency, family mission assignment and confirmation, plus summary frequency control.

### 8. Accessibility
Read-aloud and voice guidance on every mission beat, captions on audio, adjustable reading level per tier, reduced-motion and high-contrast support, full keyboard navigation.

### 9. Analytics
Log every spec event: mission accepted/completed/abandoned, weekly and family participation, XP, crystals, coins spent, badge unlocked, level reached, portfolio item created, reflection completed, mission duration.

## Technical notes

- **Database**: extend `child_missions` (mission_type, difficulty, week_of, season_id, family_role, reflection, expires_at); new tables for `child_wallets` (crystals, coins), `coin_shop_items` / `child_cosmetics`, `mission_reflections`, and `family_missions` linkage. Each new public table ships GRANTs plus RLS in the same migration.
- **Content**: expand `src/lib/dashboard-content.ts` into a `src/lib/missions/` module — template library per type, difficulty bands, seasonal windows, level ladder, badge catalog.
- **Server**: extend `child-dashboard.server.ts` / `.functions.ts` with `ensureWeeklyChallenge`, `ensureSeasonalMissions`, `assignFamilyMission`, `advanceMissionBeat`, `submitReflection`, `awardRewards` (single funnel for XP/crystals/badges/celebrations), plus parent-side functions for family missions and summaries.
- **UI**: a mission detail route driving the seven beats, a mission board on the Innovation Hub grouping the five types, a rewards screen (level ladder, badges, crystals, coins, cosmetics shop), and the parent Missions & Growth panel.
