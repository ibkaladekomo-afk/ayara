# Ayara — Build Plan (Spec Volumes 1 & 2, Section 1)

## One decision up front

The spec names Flutter + Firebase. This project builds web apps, so Ayara will
be a **mobile-first responsive web app** on the existing stack (TanStack Start +
Lovable Cloud) — installable to a phone home screen and later wrappable for the
App Store. Everything else in the spec maps over unchanged: same roles, same
flows, same safety layer, same data model. Nothing in Volume 1 or 2 depends on
Flutter specifically.

## What this build delivers

Volume 2 Section 1 in full — parent onboarding and authentication, end to end —
plus the Volume 1 foundation it sits on. Child experience, curriculum, and admin
portal follow in later passes against Volumes 3–10.

---

## 1. Foundation

- Design system pass so every screen is "premium in every interaction": brand
  tokens already in place, plus shared page shell, illustration slots, Aya
  animation states, and a loading component that never shows a bare spinner —
  always Aya plus an encouraging line.
- Accessibility baseline applied globally: 44x44 minimum targets, focus rings,
  screen-reader labels, large-text and reduced-motion support, high contrast.
- English/Spanish from the first screen, with a language selector on the
  launch screen and the choice carried through the account.

## 2. Launch experience

- No login screen first. `/` shows the brand welcome: illustration, Aya, warm
  greeting, mission line, **Get Started** / **I already have an account**, and
  footer links for Privacy, Terms, and language.
- Three-screen welcome carousel (welcome, learn/create/imagine, parents stay in
  control) ending in **Create Family Account**.

## 3. Account creation and authentication

- Fields: first name, last name, email, password, confirm, country, language,
  plus terms, privacy, and optional marketing checkboxes.
- Validation exactly as specced: name 2–40 letters, valid unused email, password
  10+ with upper, lower, number and symbol, live strength meter, inline errors
  only — no pop-ups.
- Sign-in methods: email/password, Google, and Apple.
- Every error message is calm and blameless ("We couldn't sign you in. Please
  check your password and try again.").

## 4. Email verification

Confirmation screen after signup with **Open email app**, **Resend**, **Change
email**, and **Skip for now**. Skipping grants limited access: no subscription
purchase and no child activation until verified.

## 5. Family account

Family name, number of children, time zone, country, language, and notification
preferences (weekly reports, learning reminders, achievement alerts, product
updates).

## 6. Subscription

Shown only after the account exists. Free Explorer vs Premium Family, annual
marked Best Value, trial CTA, and a clear skip path to the free tier. Plan
choice is recorded on the family; payment processing is wired in a later pass
so onboarding can be completed and tested now.

## 7. Parent preferences and safety setup

- Learning goals (multi-select), preferred session length, learning days.
- Safety: screen-time limit, allowed learning hours, voice chat, microphone,
  portfolio sharing, notifications, AI conversation history, report download.
  Recommended defaults are pre-filled and one tap accepts them.

## 8. Success and handoff

Aya celebration screen — "Your family is ready!" — leading into child profile
creation (name, avatar, grade 2–8, language, interests, username, PIN), then the
device handoff to the child.

## 9. States, errors, analytics

- Empty/error states for offline, verification pending, and declined payment.
- Analytics events for the full funnel: app opened, welcome completed, account
  started/completed, email verified, subscription viewed/started/skipped, family
  created, safety completed, onboarding completed, time to complete, drop-off
  screen.

---

## Technical notes

New tables in one migration, each scoped so a parent only ever reads their own
family's rows: `families` (name, country, timezone, language, notification and
learning preferences, plan, trial state), `parent_safety_settings`, and
`onboarding_events` for the funnel. Existing `profiles` and `child_profiles`
are extended (first/last name, country, language, family link, grade band 2–8)
rather than replaced, so current accounts survive.

Auth uses Lovable Cloud with email/password plus Google and Apple providers
enabled the same turn the buttons ship. Email verification stays on (no
auto-confirm) since the spec requires it. Onboarding is a resumable multi-step
route — progress is written server-side at each step, so a parent who closes the
tab returns to the step they left. Spanish copy lives in a shared string table
from day one rather than being retrofitted.

## After this

Volume 2's remaining sections and Volumes 3–10 get built in order: child
onboarding and the four Learning Worlds, the AI engine and safety layer, the
parent dashboard and reporting, then gamification and portfolio.
