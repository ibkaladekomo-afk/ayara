# Section 3 — Home Dashboard & Daily Learning Experience

Today `/play` is a plain world picker: greeting + six world tiles. This turns it into the daily hub the spec describes — Today's Mission, Continue Learning, streak, XP, achievements, portfolio, and persistent navigation — in both Spark and Forge flavors.

## What the child will see

**Top bar**
Avatar, learning stage badge (Spark Creator / Forge Innovator), XP for the day, and a notifications bell with positive, actionable messages.

**Aya's greeting**
Rotating, non-repeating greeting picked from time of day, recent activity, streak milestones and last world visited. Spark hears it read aloud automatically; Forge gets a shorter, mentor-toned line.

**Today's Mission (first, always)**
One highlighted mission card: prompt question, estimated time, XP reward, badge it unlocks, and a single big "Start Mission" button. Chosen daily per child from their tier, interests and worlds not yet done.

**Continue Learning**
Cards for unfinished missions with a progress bar, last step, and remaining time — resuming the exact conversation the child left.

**Innovation Streak**
"🔥 12-Day Innovation Streak" with milestone celebration at 3/7/14/30/100 days. Missing a day does not reset to zero — it offers a "Spark Recovery" bonus mission to restore the streak.

**Learning Worlds**
Unlocked worlds first, then locked worlds shown as curiosity previews ("Unlocks after 3 Science missions") rather than dead ends.

**Recent Achievements**
Three most recent badges with date, description and an optional "Share with parent".

**Portfolio preview**
Recent creations (stories, drawings, robot designs, journals) in a horizontal strip, with a link to the full portfolio.

**Smart recommendations**
A short, friendly nudge based on interests and recent activity — "Because you love space…", "Try a coding challenge next." Never more than one at a time.

**Seasonal touch**
A subtle themed banner/accent that changes by date (Back to School, STEM Week, Earth Day, Winter Innovation Festival, heritage months) without altering layout.

**Ask Aya**
Persistent floating button on every child screen, opening a free-form voice/type conversation with Aya at the child's grade level.

**Bottom navigation**
Home · Worlds · Aya · Portfolio · Rewards · Profile, present across all `/play` screens.

## Accessibility

Read-aloud on every text block, reduced-motion support (already in the app), high-contrast-safe brand tokens, large tap targets, keyboard navigation, and status conveyed by icon + text rather than color alone.

## Technical notes

- New `src/routes/play/` layout route holding the top bar, bottom nav and Ask Aya button; existing `/play` becomes `Home` and the world grid moves to `/play/worlds`. New leaf routes: `/play/portfolio`, `/play/rewards`, `/play/profile`, `/play/aya`.
- New `src/lib/child-dashboard.functions.ts` exposing one `getMyDashboard` server function that returns greeting inputs, today's mission, in-progress conversations, XP/level/streak, recent badges, portfolio preview, unlocked/locked worlds and the recommendation — one round trip, loaded through TanStack Query so the screen renders fast.
- Streak, XP and level already live in `child_progress`; badges in `child_badges`; unlocks in `child_world_unlocks`; creations in `portfolio_items`. A migration adds a `child_missions` table (assigned daily mission, status, progress step, xp/badge reward) plus a `grace_used_on` column on `child_progress` for Spark Recovery, and XP-award rules so XP is granted for completed work only — never for opening the app.
- Mission progress is written when a mission step completes, so Continue Learning resumes accurately.
- Greeting variety, seasonal themes and recommendation copy are pure client logic in `src/lib/dashboard-greetings.ts` and `src/lib/seasons.ts`, translated EN/ES.
- Analytics events from §19 are recorded through the existing `logMyEvent` into `child_events`.

## Not in this pass

Offline mode/downloadable lessons, Friends, drawing and file upload in Ask Aya, and widget customization — these need native/offline infrastructure and are listed as future work in the spec.
