# AYARA Investor Pitch Microsite — Build Plan

## Goal
Build a premium, mobile-first investor pitch microsite for AYARA that tells the brand story, captures investor and waitlist interest, and lets visitors experience a real, child-safe AI character conversation after signing in.

## Design Direction
Warm, trustworthy, and premium — not "app for kids" playful, but "parent-confidence" polished. A soft cream-to-lavender gradient palette, rounded friendly shapes, generous whitespace, and subtle motion. Typography pairs a rounded display face for headlines with a clean sans-serif body. Imagery centers on diverse children creating, curious, and collaborating with friendly AI characters.

## What We Will Build

### Public pages
- **Home (`/`)**: Hero with tagline "Growing the Next Generation of Innovators", problem/solution narrative, key differentiators, business model summary, team/vision CTA, and investor/waitlist email capture.
- **About / Vision (`/about`)**: Mission, vision, brand promise, and the "why now" narrative.
- **Safety (`/safety`)**: Child-safety architecture, moderation, parent controls, and trust signals.
- **Investor (`/investor`)**: Traction placeholder, funding vision, market opportunity, and a contact form.
- **Auth (`/auth`)**: Sign up / sign in for parents (email + Google). Protected demo redirects here when unauthenticated.

### Authenticated experience
- **Parent onboarding (`/_authenticated/onboarding`)**: Create a parent profile and one child profile (name, age, grade, language, interests).
- **AI demo (`/_authenticated/demo`)**: A working chat with AYARA's first character (a friendly scientist/inventor). The conversation is age-adapted to the child profile, includes child-safety guardrails via system prompt, and persists messages to the database.
- **Dashboard (`/_authenticated/dashboard`)**: View child profile and a summary of the demo conversation.

### Backend
- Enable Lovable Cloud for authentication and database.
- Database tables: `profiles` (parents), `child_profiles`, `conversations`, `messages`.
- Row-level security so parents only see their own children and conversations.
- AI chat server route at `/api/chat` using Lovable AI Gateway, with a child-safe system prompt and age/grade adaptation.

## Technical Scope
- TanStack Start + Tailwind CSS v4 + shadcn/ui components already in template.
- Add `ai`, `@ai-sdk/react`, `@ai-sdk/openai-compatible` for streaming chat.
- Add `react-markdown` for assistant message rendering.
- Mobile-first responsive design; desktop scales up cleanly.
- SEO meta tags and Open Graph tags for each public route.

## Build Sequence
1. Enable Lovable Cloud and provision auth/database.
2. Create database migrations (profiles, child_profiles, conversations, messages, RLS policies, grants).
3. Set up AI gateway helper and `/api/chat` route with child-safe prompt.
4. Build public marketing pages and shared layout/nav/footer.
5. Build auth flow (`/auth`) and parent onboarding.
6. Build authenticated AI demo and dashboard.
7. Add waitlist/investor email capture via server function.
8. Verify build, responsive layout, and AI chat end-to-end.

## Out of Scope for This Milestone
- Real payments or subscriptions.
- Multiple AI characters / full learning worlds.
- Voice interaction.
- School/classroom plans or admin portals.
- Advanced analytics or weekly parent summaries.

## Open Question
Do you want the AI demo character to be a single "scientist" character, or would you prefer a small team preview (e.g., scientist, artist, storyteller) that the child can switch between? A single character keeps the first milestone focused; a team preview is more impressive for investors but adds scope.
