# Section 5 — Aya AI Companion Experience

Aya already exists as a mentor-aware, tier-aware chat with voice input, read-aloud, safety screening and parent alerts. This section turns her from "a good chat" into a consistent learning companion: a defined teaching method, real memory of the child, richer grade adaptation, explicit safety/homework behaviour, celebration moments, and parent-facing summaries instead of raw transcripts.

## 1. Aya's teaching framework (mentor prompt rewrite)

Rewrite the system prompt used by the mission chat so every reply follows the four stages: celebrate curiosity → guide thinking → teach → extend learning.

Added rules:
- Never hand over an answer when the thinking is the lesson; ask what the child already tried.
- Homework policy: help outline, plan, check and improve — never produce the finished assignment.
- Uncertainty: say plainly when she isn't sure and propose exploring together; never invent facts.
- Personality guardrails: warm, patient, optimistic, curious — no sarcasm, shaming, rushing or arguing.
- Challenge mode: periodically pose a "what if / another solution / how would you improve this" prompt.

## 2. Grade adaptation — three bands instead of two

Today tone splits on Spark vs Forge only. Add a third band inside Spark so grades 2–3 and 4–5 read differently:
- Grades 2–3: very short sentences, simple words, concrete examples, voice-first.
- Grades 4–5: longer explanations, analogies, creative challenges.
- Grades 6–8: reasoning, research, projects, ethics, entrepreneurship (existing Forge tone).

Derived from the child's grade, falling back to age. Tier identity (Spark/Forge) stays as-is for UI.

## 3. Aya's memory

Give Aya a compact, privacy-light memory brief assembled server-side on each mission chat request:
- Favourite subjects / interests
- Current world and learning stage
- Recently completed projects and creations
- Achievements, XP level and streak
- Preferred input (voice or typing)

Only learning-related facts — no personal identifiers beyond first name. Parents get a "Clear Aya's conversation history" control on the child card in the parent dashboard, which deletes stored conversations and messages for that child.

## 4. Interaction modes in the mission screen

Surface the four modes as quick chips above the composer: Ask, Explore, Imagine, Reflect. Choosing one sends an intent hint with the message so Aya frames her reply accordingly. The reflection chip is offered automatically near the end of a session ("What did you learn today? What surprised you?").

## 5. Safety conversation flow

Screening already flags messages and writes parent alerts. Add the child-facing half:
- On an urgent flag, Aya's reply is replaced by an empathetic, scripted response that validates the child and points them to a trusted adult, instead of relying on the model to improvise.
- Attention-level flags let the conversation continue but push a gentle redirect into the prompt.
- Parent notification respects the safety settings the parent chose during onboarding.

## 6. Celebration moments

Meaningful, non-spammy celebrations from Aya for: first question ever, first project, new streak milestone, world completion, master project. Each fires once, is recorded, and shows as a short in-chat celebration card rather than confetti on everything.

## 7. Parent transparency

Parent dashboard gains a per-child "Learning summary" panel:
- Themes explored, projects completed, skills practised, time spent learning
- A short AI-written recap per conversation (generated on session end), not the full transcript
- Safety alerts stay as they are today

Default remains: parents see summaries, not every message.

## 8. Analytics events

A lightweight event log for: questions asked, projects created, voice interactions, conversation length, challenge accepted, reflection completed. Feeds the parent summary panel and future product metrics.

## Technical notes

- Prompt work lands in a new `src/lib/aya-persona.ts` (framework, grade bands, modes, celebration/safety copy) consumed by `src/routes/api/chat.ts`; the route keeps its existing gateway/streaming setup.
- Memory brief built in a new `src/lib/aya-memory.server.ts`, reusing existing dashboard/creations/world-progress helpers; passed into the chat request from the mission screen.
- New tables: `learning_events` (analytics) and `conversation_summaries`, plus a `celebrations` marker table — each with RLS scoped to parent/child and explicit grants.
- Safety interception happens where messages are already screened (`src/lib/child-play.functions.ts` / chat route) so the scripted reply cannot be bypassed by the model.
- Mission screen (`src/routes/play.$worldId.tsx`) gets mode chips, celebration cards and reflection prompt; voice and typing toggle behaviour stays unchanged.
- Conversation recaps generated with a fast Lovable AI model on session end, stored per conversation.
