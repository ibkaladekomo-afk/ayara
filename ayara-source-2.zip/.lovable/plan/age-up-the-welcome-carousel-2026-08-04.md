# Age up the Welcome carousel

The landing page was aged up for 10–13 year olds, but the three-screen Welcome carousel shown right before sign-up still uses the old preschool-style artwork and soft copy. This closes that gap.

## What changes

1. **New artwork** for all three screens, matching the landing page's creative-studio direction: older kids (roughly 9–13) building, prototyping and reviewing work, deeper backgrounds, no toddler-with-blocks imagery. Aya still appears, but as a sleek companion rather than the dominant character.
   - Screen 1: a young innovator with Aya beside a project in progress
   - Screen 2: the four Learning Worlds as a modern constellation/studio map
   - Screen 3: a parent reviewing progress on the dashboard (kept, restyled to match)

2. **Copy pass** on the three screens so the wording reads "build, experiment, create" rather than "play". Same three-beat structure: what Ayara is → how kids learn → how parents stay in control.

3. **Layout polish** so the screen matches the landing page tone: darker gradient panel behind the image, tighter mascot placement, same button styling.

## Technical notes

- New images generated into `src/assets/`, replacing the `illus-welcome` / `illus-worlds` / `illus-parent` imports in `src/routes/welcome.tsx`.
- Copy strings updated in `src/lib/i18n.tsx` for both English and Spanish (`welcome.1.*`, `welcome.2.*`, `welcome.3.*`).
- No routing, auth, or data changes.
