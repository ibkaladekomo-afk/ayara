# Section 4 — Learning Worlds Experience

Turn the six existing worlds into real destinations: each with its own mentor, visual identity, world home screen, learning path, hidden discoveries and a master project that lands in the child's portfolio.

## 1. Worlds get identities

Rebuild the world catalog to match the spec's MVP mentors, keeping all six playable:

| World | Mentor | Focus |
|---|---|---|
| Science Lab | Dr. Nova | Experiments, hypotheses, observation |
| Story Factory (was Story Tree) | Echo | Writing, reading, imagination |
| Art Studio | Luna | Drawing, design, color |
| Code Garage (was Code Workshop) | Byte | Coding, logic, game making |
| AI Research Center (was AI Explorer) | Ayara Guide | AI literacy, fact-checking |
| Discovery Forest (was Nature Trail) | Fern | Nature, animals, the planet |

Each world gains: theme description, palette, ambient motion accents, mentor personality and speaking style, and a short welcome line. Future worlds (Math Galaxy, Language Harbor, Career Studio, Music Studio, Space Station, Global Village) appear as locked "coming soon" cards to inspire exploration.

## 2. Worlds page

The Worlds tab becomes a scrollable set of animated world cards (not a pan/zoom map): unlocked worlds show progress ring and current stage; locked worlds show a teaser and how to unlock. Reduced-motion respected.

## 3. World home screen (new route per world)

Entering a world plays a short welcome animation and mentor introduction, then shows the world home:

- Progress ring (world completion %)
- Current mission and next step
- Mentor message (tier-aware tone)
- Today's challenge
- Recent discoveries
- Achievements earned in this world
- Master Project card
- Exit world

Children always see one clear "what to do next" button.

## 4. Learning path

Each world has a 7-stage path: Introduction → Discovery → Practice → Creation → Reflection → Master Project → Celebration. Stages unlock in order, each backed by a mission (existing mission templates map to Discovery/Practice/Creation; new reflection prompts added). Completing a stage awards XP and advances the ring.

## 5. Hidden discoveries

Each world hides 2–3 optional finds (a secret badge, a bonus experiment, a Curiosity Crystal) revealed by exploring cards or asking the mentor certain kinds of questions. Never required; finding one awards a crystal and a mentor message.

## 6. Master projects

The final stage is a guided creative build (design an experiment, publish a storybook, create a digital gallery, build a mini-game, etc.). Output is saved automatically as a portfolio item with a certificate, and completing it triggers the Celebration stage.

## 7. Mentor AI is world-aware

The chat system prompt gains world context: mentor persona and speaking style, current learning stage, and mission objective, on top of the existing tier and safety rules. Inside Science Lab the AI pushes scientific reasoning; inside Story Factory, narrative craft; and so on.

## 8. Rewards, accessibility, analytics

- Rewards: XP, badges, Curiosity Crystals, portfolio certificates, mentor messages. No loot-box mechanics.
- Accessibility: read-aloud on world text for Spark, captions on mentor messages, reduced-motion fallbacks, large touch targets, color-safe states.
- Analytics: log world entered/exited, stage started/completed, master project started/completed, mentor conversation, hidden discovery found, into the existing child events table.

## Technical notes

- Database: new tables for world progress (`child_world_progress`: world, stage, completion, updated) and discoveries (`child_discoveries`); reuse `child_missions`, `child_world_unlocks`, `portfolio_items`, `child_progress`, `child_events`. All with grants + RLS scoped to the child's parent, matching existing tables.
- Content lives in `src/lib/worlds.ts` (rewritten: mentors, themes, stages, discoveries, master projects) and extends `src/lib/dashboard-content.ts` mission templates with a `stage` field.
- New routes: `src/routes/play.world.$worldId.tsx` (world home + welcome animation). `play.$worldId.tsx` stays the mentor chat/mission screen and gains stage + mentor context.
- New server functions in `src/lib/child-worlds.functions.ts`: `getMyWorld`, `enterWorld`, `completeStage`, `recordDiscovery`, `submitMasterProject` — all behind the existing child-session guard.
- `src/routes/api/chat.ts` takes new `mentor` and `stage` fields in its request body.
- English + Spanish strings added for all new copy.

Out of scope this pass: pan/zoom animated map, offline lesson downloads, seasonal transformations, AR, community showcases.
