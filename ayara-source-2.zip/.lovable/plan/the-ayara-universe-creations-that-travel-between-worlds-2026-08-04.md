# The Ayara Universe — creations that travel between worlds

Today every world saves its own portfolio items and nothing crosses over. This turns those items into **living creations** a child can carry from world to world: a robot from Code Garage becomes a character in Story Factory, a plant from Science Lab becomes the core of an invention in the Art Studio or Code Garage.

Note on naming: the six MVP worlds are Science Lab, Story Factory, Art Studio, Code Garage, AI Research Center and Discovery Forest. "Innovation Lab" work maps to Code Garage / Art Studio until a dedicated world ships.

## 1. Creations, not just portfolio entries

Every meaningful thing a child makes (master projects, first builds, named inventions, characters, specimens) is registered as a **Creation** with:

- a name the child chooses, an emoji/avatar, and a type: character, creature, invention, place, story, specimen, artwork
- the world it was born in, plus traits the mentor extracts from the conversation ("solar-powered", "shy", "lives underwater")
- a lineage: which earlier creations it was built from

Existing portfolio items stay as-is; creations link to them, so nothing already saved is lost.

## 2. Carrying a creation into another world

When a child enters a world, the mentor can offer: *"Want to bring someone with you?"* The child picks from their Creations. The mentor then greets that creation by name and shapes the mission around it:

- Story Factory: write a story starring the Code Garage robot
- Science Lab: run an experiment on the Discovery Forest plant
- Art Studio: illustrate the character from the story
- Code Garage: build a mini-game where the creature is the hero

Each cross-world use adds a new chapter to the creation's history and awards **Universe XP** plus a Curiosity Crystal for the first time a creation crosses worlds.

## 3. The Universe screen

A new tab/screen in the Innovation Hub showing the child's universe:

- A constellation of their creations, grouped by world of origin, with lines drawn between connected ones (robot → story → illustration)
- Tap a creation: its name, story so far, which worlds it has visited, and a "Take it somewhere new" button that deep-links into a world with that creation attached
- Milestones: "Your first crossover", "A creation in 3 worlds", "Your universe has 10 creations"

Spark tier gets the storybook framing ("Your world is growing!") with read-aloud; Forge tier gets a systems/network framing ("Your build graph").

## 4. Mentors know the universe

The chat system prompt gains the carried creation's name, type, traits and history, so mentors reference it naturally and never contradict earlier facts. Mentors also occasionally suggest a crossover the child hasn't tried ("Echo could turn Bolt into a story — want me to send him over?").

## 5. Parent side

The parent dashboard's child card gains a short "Their universe" summary: number of creations, crossovers, and the newest connection — evidence of continuity over time rather than one-off lessons.

## Technical notes

- New tables: `child_creations` (child, parent, name, type, emoji, origin_world, traits jsonb, portfolio_item_id, created_at) and `creation_appearances` (creation, world, mission/conversation, summary, created_at). Both with GRANTs and RLS scoped to the child's parent, matching existing child tables.
- New `src/lib/creations.ts` for types, crossover prompt templates per (creation type × world), and milestone definitions.
- New server functions in `src/lib/child-creations.functions.ts` (+ `.server.ts` helpers, behind the existing child-session guard): `listMyCreations`, `createCreation`, `attachCreationToWorld`, `recordAppearance`, `renameCreation`.
- Master project completion in `src/lib/child-worlds.functions.ts` also registers a Creation and links it to the portfolio item.
- New route `src/routes/play.universe.tsx`; `play.world.$worldId.tsx` gains the "bring a creation" picker; `play.$worldId.tsx` passes the carried creation to `/api/chat`, which adds it to the mentor prompt.
- Analytics events into `child_events`: creation_registered, creation_carried, crossover_completed, universe_milestone.
- English + Spanish strings for all new copy; reduced-motion fallback for the constellation view.

Out of scope this pass: sharing creations between siblings or friends, 3D/AR views, and an editable creation-trait editor (traits come from the mentor conversation).
