# Deploying Ayara (off Lovable)

The app is a TanStack Start + Nitro build that outputs Vercel's Build Output
format. Verified working: `NITRO_PRESET=vercel vite build` → `.vercel/output`.

## 1. Environment variables (set in Vercel → Project → Settings → Environment Variables)

| Variable | Value |
|---|---|
| `SUPABASE_URL` / `VITE_SUPABASE_URL` | from `.env` in the source export |
| `SUPABASE_PROJECT_ID` / `VITE_SUPABASE_PROJECT_ID` | from `.env` |
| `SUPABASE_PUBLISHABLE_KEY` / `VITE_SUPABASE_PUBLISHABLE_KEY` | from `.env` |
| `SUPABASE_SERVICE_ROLE_KEY` | see below — NOT in the export |
| `AI_BASE_URL` | `https://api.anthropic.com/v1` |
| `AI_API_KEY` | your Anthropic key (sk-ant-…) |
| `AI_MODEL` | `claude-haiku-4-5` |
| `MODERATION_MODEL` | `claude-haiku-4-5` |
| `NITRO_PRESET` | `vercel` |

## 2. The service-role key (the one missing piece)

Child login/sessions use a server-side Supabase client that needs
`SUPABASE_SERVICE_ROLE_KEY`. Lovable holds this secret server-side and does
not export it. Two ways to get one:

- **If Lovable exposes your Supabase project** (Lovable Cloud → your project's
  backend/Supabase settings): copy the `service_role` (or `sb_secret_…`) key.
- **Otherwise create your own Supabase project** (supabase.com, free tier):
  run the SQL files in `supabase/migrations/` in order via the SQL editor,
  then use the new project's URL + publishable + service-role keys for ALL
  the variables above. This is the fully-independent path (recommended
  eventually anyway). Fresh DB = re-create parent account + child profile.

## 3. Deploy

Connect this repo to Vercel (Add New → Project → Import this Git repository).
Build command is `vite build` (already set in vercel.json); Vercel injects
`VERCEL=1` and with `NITRO_PRESET=vercel` set, Nitro emits the right output.

Never commit `.env`. Keys go in Vercel's dashboard only.
